import { Bell, Mail, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { toPersianDigits } from "@/lib/persian-utils";

export function StatusBar() {
  // Fetch alerts count
  const { data: alerts } = useQuery({
    queryKey: ["alerts", "open-count"],
    queryFn: async () => {
      const response = await fetch("/api/alerts?status=open&limit=100");
      if (!response.ok) throw new Error("Failed to fetch alerts");
      return response.json();
    },
    refetchInterval: 60000, // Update every minute
  });

  // Fetch unread messages count
  const { data: messages } = useQuery({
    queryKey: ["messages", "unread-count"],
    queryFn: async () => {
      const response = await fetch("/api/conversations");
      if (!response.ok) throw new Error("Failed to fetch conversations");
      const convs = await response.json();
      const unreadCount = convs.reduce((acc: number, conv: any) => acc + (conv.unreadCount || 0), 0);
      return { unreadCount };
    },
    refetchInterval: 30000, // Update every 30 seconds
  });

  // Fetch critical projects
  const { data: projects } = useQuery({
    queryKey: ["projects", "critical"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("Failed to fetch projects");
      const allProjects = await response.json();
      const criticalProjects = allProjects.filter((p: any) => p.progress < 50);
      return { critical: criticalProjects.length, total: allProjects.length };
    },
    refetchInterval: 120000, // Update every 2 minutes
  });

  const openAlertsCount = alerts?.length || 0;
  const criticalAlerts = alerts?.filter((a: any) => a.severity === "critical" || a.severity === "high").length || 0;
  const unreadMessagesCount = messages?.unreadCount || 0;
  const criticalProjectsCount = projects?.critical || 0;

  const hasCritical = criticalAlerts > 0 || criticalProjectsCount > 0;

  return (
    <div className={`
      border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50
      ${hasCritical ? 'border-red-200 dark:border-red-900/50' : 'border-border'}
    `}>
      <div className="flex items-center justify-between px-4 py-2">
        {/* سمت چپ: اعلان‌های مهم */}
        <div className="flex items-center gap-3">
          {/* هشدارهای بحرانی */}
          {criticalAlerts > 0 && (
            <Link href="/alerts">
              <Button 
                variant="ghost" 
                size="sm" 
                className="gap-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 animate-pulse"
              >
                <AlertTriangle className="w-4 h-4" />
                <span className="text-sm font-medium">
                  {toPersianDigits(criticalAlerts.toString())} هشدار بحرانی
                </span>
              </Button>
            </Link>
          )}

          {/* پروژه‌های با پیشرفت کمتر از ۵۰% */}
          {criticalProjectsCount > 0 && (
            <Link href="/projects">
              <Button 
                variant="ghost" 
                size="sm" 
                className="gap-2 text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/20"
              >
                <Clock className="w-4 h-4" />
                <span className="text-sm">
                  {toPersianDigits(criticalProjectsCount.toString())} پروژه نیاز به توجه
                </span>
              </Button>
            </Link>
          )}

          {/* وضعیت خوب */}
          {!hasCritical && (
            <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-sm font-medium">وضعیت عملکرد مناسب</span>
            </div>
          )}
        </div>

        {/* سمت راست: آمار و دسترسی سریع */}
        <div className="flex items-center gap-2">
          {/* هشدارها */}
          <Link href="/alerts">
            <Button variant="ghost" size="sm" className="relative gap-2 hover:bg-red-50 dark:hover:bg-red-950/20">
              <Bell className="w-4 h-4 text-red-600 dark:text-red-400" />
              {openAlertsCount > 0 && (
                <Badge 
                  variant="destructive" 
                  className="px-1.5 py-0 text-xs font-bold min-w-[1.25rem] h-5"
                >
                  {toPersianDigits(openAlertsCount.toString())}
                </Badge>
              )}
              <span className="text-sm hidden sm:inline">هشدارها</span>
            </Button>
          </Link>

          {/* پیام‌ها */}
          <Link href="/messages">
            <Button variant="ghost" size="sm" className="relative gap-2 hover:bg-orange-50 dark:hover:bg-orange-950/20">
              <Mail className="w-4 h-4 text-orange-500 dark:text-orange-400" />
              {unreadMessagesCount > 0 && (
                <Badge 
                  variant="default" 
                  className="px-1.5 py-0 text-xs font-bold min-w-[1.25rem] h-5 bg-orange-500"
                >
                  {toPersianDigits(unreadMessagesCount.toString())}
                </Badge>
              )}
              <span className="text-sm hidden sm:inline">پیام‌ها</span>
            </Button>
          </Link>
        </div>
      </div>

      {/* نوار هشدار چشمک‌زن برای موارد بحرانی */}
      {hasCritical && (
        <div className="h-1 bg-gradient-to-r from-red-500 via-amber-500 to-red-500 animate-pulse" />
      )}
    </div>
  );
}
