import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search } from "lucide-react";
import ProjectCard from "./ProjectCard";
import { useToast } from "@/hooks/use-toast";
import { useProject } from "@/lib/project-context";
import { useLocation } from "wouter";
import type { Project, InsertProject } from "@shared/schema";

export default function ProjectsPage() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { setSelectedProject } = useProject();
  const [, setLocation] = useLocation();

  const [formData, setFormData] = useState<InsertProject>({
    title: "",
    contractNumber: "",
    location: "",
    employer: "",
    amount: "",
    progress: 0,
    status: "active",
    startDate: "",
  });

  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: InsertProject) => {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ایجاد پروژه");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setOpen(false);
      setFormData({
        title: "",
        contractNumber: "",
        location: "",
        employer: "",
        amount: "",
        progress: 0,
        status: "active",
        startDate: "",
      });
      toast({
        title: "موفقیت",
        description: "پروژه جدید با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createProjectMutation.mutate(formData);
  };

  const handleViewDetails = (id: string) => {
    setLocation(`/projects/${id}`);
  };

  const filteredProjects = projects.filter((project) => {
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.contractNumber?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || project.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">پروژه‌ها</h1>
          <p className="text-muted-foreground">مدیریت و پیگیری پروژه‌های در حال اجرا</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-new-project">
              <Plus className="w-4 h-4 ml-2" />
              پروژه جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>ایجاد پروژه جدید</DialogTitle>
              <DialogDescription>
                اطلاعات پروژه جدید را وارد کنید
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان پروژه *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="عنوان پروژه را وارد کنید"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contractNumber">شماره قرارداد</Label>
                  <Input
                    id="contractNumber"
                    value={formData.contractNumber || ""}
                    onChange={(e) => setFormData({ ...formData, contractNumber: e.target.value })}
                    placeholder="شماره قرارداد"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">محل اجرا</Label>
                  <Input
                    id="location"
                    value={formData.location || ""}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="محل اجرای پروژه"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="employer">کارفرما</Label>
                  <Input
                    id="employer"
                    value={formData.employer || ""}
                    onChange={(e) => setFormData({ ...formData, employer: e.target.value })}
                    placeholder="نام کارفرما"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">مبلغ قرارداد (ریال)</Label>
                  <Input
                    id="amount"
                    value={formData.amount || ""}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="مبلغ قرارداد"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="startDate">تاریخ شروع</Label>
                  <Input
                    id="startDate"
                    value={formData.startDate || ""}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    placeholder="1402/01/01"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="progress">پیشرفت (%)</Label>
                  <Input
                    id="progress"
                    type="number"
                    min="0"
                    max="100"
                    value={formData.progress || 0}
                    onChange={(e) => setFormData({ ...formData, progress: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">وضعیت</Label>
                  <Select
                    value={formData.status || "active"}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">در حال اجرا</SelectItem>
                      <SelectItem value="completed">تکمیل شده</SelectItem>
                      <SelectItem value="pending">در انتظار</SelectItem>
                      <SelectItem value="suspended">متوقف شده</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  انصراف
                </Button>
                <Button type="submit" disabled={createProjectMutation.isPending}>
                  {createProjectMutation.isPending ? "در حال ذخیره..." : "ذخیره پروژه"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجو در پروژه‌ها..."
            className="pr-10"
            data-testid="input-search-projects"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-48" data-testid="select-filter">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه پروژه‌ها</SelectItem>
            <SelectItem value="active">در حال اجرا</SelectItem>
            <SelectItem value="completed">تکمیل شده</SelectItem>
            <SelectItem value="pending">در انتظار</SelectItem>
            <SelectItem value="suspended">متوقف شده</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                  <Skeleton className="h-6 w-16" />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                  <Skeleton className="h-4 w-4/6" />
                </div>
                <div className="space-y-2">
                  <Skeleton className="h-2 w-full rounded-full" />
                  <Skeleton className="h-4 w-20" />
                </div>
                <div className="flex gap-2 pt-2">
                  <Skeleton className="h-9 flex-1" />
                  <Skeleton className="h-9 w-9" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <p className="text-sm text-muted-foreground">
            {filteredProjects.length} پروژه
          </p>
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredProjects.map((project) => (
              <ProjectCard
                key={project.id}
                id={project.id}
                title={project.title}
                contractNumber={project.contractNumber || ""}
                location={project.location || ""}
                employer={project.employer || ""}
                amount={project.amount || "0"}
                progress={project.progress || 0}
                status={(project.status as "active" | "completed" | "pending" | "suspended") || "active"}
                startDate={project.startDate || ""}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
