import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";
import { 
  DollarSign, 
  TrendingUp, 
  FolderKanban, 
  AlertTriangle, 
  CheckCircle, 
  FileText,
  Calculator,
  Wallet
} from "lucide-react";
import type { Project, Alert, Task } from "@shared/schema";
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Area,
  AreaChart
} from "recharts";

type FinancialStats = {
  totalContractAmount: number;
  totalStatements: number;
  totalAdjustments: number;
  totalBitumenDiffs: number;
  totalFinancialProgress: number;
  financialProgressPercentage: number;
  monthlyProgress: { month: string; amount: number }[];
  projectCount: number;
  statementCount: number;
  adjustmentCount: number;
  bitumenDiffCount: number;
};

export default function ManagementDashboard() {
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: alerts = [], isLoading: isLoadingAlerts } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });

  const { data: tasks = [], isLoading: isLoadingTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: financialStats, isLoading: isLoadingFinancialStats } = useQuery<FinancialStats>({
    queryKey: ["/api/dashboard/financial-stats"],
  });

  const isLoading = isLoadingProjects || isLoadingAlerts || isLoadingTasks || isLoadingFinancialStats;

  const activeProjects = projects.filter(p => p.status === "در حال اجرا").length;
  const completedProjects = projects.filter(p => p.status === "تکمیل شده").length;
  const averageProgress = projects.length > 0
    ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
    : 0;

  const openAlerts = alerts.filter(a => a.status === "باز").length;
  const completedTasks = tasks.filter(t => t.isCompleted).length;
  const totalTasks = tasks.length;

  const projectProgressData = projects
    .slice(0, 8)
    .map(p => ({
      name: p.title.length > 25 ? p.title.substring(0, 25) + "..." : p.title,
      progress: p.progress || 0,
      financial: financialStats ? (financialStats.totalFinancialProgress / financialStats.totalContractAmount * 100) : 0
    }));

  const statusDistribution = [
    { name: "در حال اجرا", value: activeProjects, color: "#10b981" },
    { name: "تکمیل شده", value: completedProjects, color: "#3b82f6" },
    { name: "معلق", value: projects.filter(p => p.status === "معلق").length, color: "#f59e0b" },
  ].filter(s => s.value > 0);

  const financialBreakdown = financialStats ? [
    { name: "صورت‌وضعیت‌ها", value: financialStats.totalStatements, color: "#22c55e" },
    { name: "تعدیل‌ها", value: financialStats.totalAdjustments, color: "#3b82f6" },
    { name: "مابه‌التفاوت قیر", value: Math.abs(financialStats.totalBitumenDiffs), color: "#a855f7" },
  ].filter(s => s.value > 0) : [];

  const monthlyProgressData = financialStats?.monthlyProgress.map(mp => ({
    month: mp.month.substring(5, 7),  // Extract month (MM)
    amount: mp.amount / 1000000000, // Convert to billions
  })) || [];

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6" dir="rtl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">داشبورد مدیریتی</h1>
            <p className="text-muted-foreground mt-1">نمای کامل وضعیت پروژه‌ها و عملکرد مالی</p>
          </div>
        </div>

        {/* Financial KPIs Skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="border-r-4 border-r-gray-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-5 w-5 rounded" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-24 mb-1" />
                <Skeleton className="h-3 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Project KPIs Skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="border-r-4 border-r-gray-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="h-4 w-4 rounded" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-20 mb-1" />
                <Skeleton className="h-3 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(2)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-48 mb-2" />
                <Skeleton className="h-4 w-64" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[300px] w-full" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* More Charts Skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(2)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-40 mb-2" />
                <Skeleton className="h-4 w-56" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[300px] w-full" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Table Skeleton */}
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-44 mb-2" />
            <Skeleton className="h-4 w-64" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-4 flex-1" />
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-4 w-16" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">داشبورد مدیریتی</h1>
          <p className="text-muted-foreground mt-1">نمای کامل وضعیت پروژه‌ها و عملکرد مالی</p>
        </div>
      </div>

      {/* Financial KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-r-4 border-r-emerald-500 bg-gradient-to-br from-emerald-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">مبلغ کل قراردادها</CardTitle>
            <DollarSign className="h-5 w-5 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">
              {financialStats ? formatCurrency((financialStats.totalContractAmount / 1000000000).toFixed(1)) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">میلیارد ریال</p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-blue-500 bg-gradient-to-br from-blue-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">پیشرفت ریالی</CardTitle>
            <Wallet className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {financialStats ? formatCurrency((financialStats.totalFinancialProgress / 1000000000).toFixed(1)) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${toPersianDigits(financialStats.financialProgressPercentage.toFixed(1))}٪ از کل` : "میلیارد ریال"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-purple-500 bg-gradient-to-br from-purple-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">صورت‌وضعیت‌ها</CardTitle>
            <FileText className="h-5 w-5 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {financialStats ? toPersianDigits(financialStats.statementCount.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${formatCurrency((financialStats.totalStatements / 1000000000).toFixed(1))} میلیارد` : "تایید شده"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-orange-500 bg-gradient-to-br from-orange-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">تعدیل‌ها</CardTitle>
            <Calculator className="h-5 w-5 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {financialStats ? toPersianDigits(financialStats.adjustmentCount.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${formatCurrency((financialStats.totalAdjustments / 1000000000).toFixed(1))} میلیارد` : "تایید شده"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-pink-500 bg-gradient-to-br from-pink-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">مابه‌التفاوت قیر</CardTitle>
            <TrendingUp className="h-5 w-5 text-pink-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pink-600">
              {financialStats ? toPersianDigits(financialStats.bitumenDiffCount.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${formatCurrency((financialStats.totalBitumenDiffs / 1000000000).toFixed(1))} میلیارد` : "تایید شده"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Project KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-r-4 border-r-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">کل پروژه‌ها</CardTitle>
            <FolderKanban className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(projects.length.toString())}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {toPersianDigits(activeProjects.toString())} پروژه فعال
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">میانگین پیشرفت</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(averageProgress.toString())}%</div>
            <p className="text-xs text-muted-foreground mt-1">از کل پروژه‌ها</p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">هشدارهای باز</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(openAlerts.toString())}</div>
            <p className="text-xs text-muted-foreground mt-1">نیاز به بررسی</p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">وظایف</CardTitle>
            <CheckCircle className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {toPersianDigits(completedTasks.toString())}/{toPersianDigits(totalTasks.toString())}
            </div>
            <p className="text-xs text-muted-foreground mt-1">انجام شده</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Financial Progress */}
        <Card>
          <CardHeader>
            <CardTitle>روند پیشرفت مالی ماهانه</CardTitle>
            <p className="text-sm text-muted-foreground">صورت‌وضعیت‌های 6 ماه اخیر (میلیارد ریال)</p>
          </CardHeader>
          <CardContent>
            {monthlyProgressData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={monthlyProgressData}>
                  <defs>
                    <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => [formatCurrency(value.toFixed(1)) + " میلیارد", "مبلغ"]}
                    labelFormatter={(label) => `ماه ${toPersianDigits(label)}`}
                  />
                  <Area type="monotone" dataKey="amount" stroke="#3b82f6" fillOpacity={1} fill="url(#colorAmount)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                داده‌ای برای نمایش وجود ندارد
              </div>
            )}
          </CardContent>
        </Card>

        {/* Financial Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>ترکیب پیشرفت مالی</CardTitle>
            <p className="text-sm text-muted-foreground">توزیع صورت‌وضعیت‌ها، تعدیل‌ها و مابه‌التفاوت‌ها</p>
          </CardHeader>
          <CardContent>
            {financialBreakdown.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={financialBreakdown}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${formatCurrency((value / 1000000000).toFixed(1))} میلیارد`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {financialBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => formatCurrency((value / 1000000000).toFixed(2)) + " میلیارد ریال"}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                داده‌ای برای نمایش وجود ندارد
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Project Progress */}
        <Card>
          <CardHeader>
            <CardTitle>پیشرفت پروژه‌ها</CardTitle>
            <p className="text-sm text-muted-foreground">درصد پیشرفت فیزیکی پروژه‌های فعال</p>
          </CardHeader>
          <CardContent>
            {projectProgressData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={projectProgressData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" domain={[0, 100]} />
                  <YAxis type="category" dataKey="name" width={150} />
                  <Tooltip />
                  <Bar dataKey="progress" fill="#3b82f6" name="درصد پیشرفت" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                هیچ پروژه‌ای یافت نشد
              </div>
            )}
          </CardContent>
        </Card>

        {/* Project Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>توزیع وضعیت پروژه‌ها</CardTitle>
            <p className="text-sm text-muted-foreground">طبقه‌بندی پروژه‌ها بر اساس وضعیت</p>
          </CardHeader>
          <CardContent>
            {statusDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${toPersianDigits(value.toString())}`}
                    outerRadius={90}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                هیچ پروژه‌ای یافت نشد
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Projects Table */}
      <Card>
        <CardHeader>
          <CardTitle>پروژه‌های در حال اجرا</CardTitle>
          <p className="text-sm text-muted-foreground">نمای کلی پروژه‌های فعال و وضعیت آنها</p>
        </CardHeader>
        <CardContent>
          {projects.filter(p => p.status === "در حال اجرا").length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-right p-2 font-semibold">نام پروژه</th>
                    <th className="text-right p-2 font-semibold">پیمانکار</th>
                    <th className="text-right p-2 font-semibold">مبلغ (میلیارد)</th>
                    <th className="text-right p-2 font-semibold">پیشرفت</th>
                    <th className="text-right p-2 font-semibold">وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  {projects.filter(p => p.status === "در حال اجرا").slice(0, 10).map((project) => (
                    <tr key={project.id} className="border-b hover:bg-muted/50 transition-colors">
                      <td className="p-2">{project.title}</td>
                      <td className="p-2">{project.contractor || "—"}</td>
                      <td className="p-2">
                        {formatCurrency((parseFloat(project.amount?.replace(/,/g, "") || "0") / 1000000000).toFixed(1))}
                      </td>
                      <td className="p-2">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                            <div 
                              className="bg-green-500 h-2 rounded-full transition-all" 
                              style={{ width: `${project.progress || 0}%` }}
                            />
                          </div>
                          <span className="text-sm font-medium">{toPersianDigits((project.progress || 0).toString())}%</span>
                        </div>
                      </td>
                      <td className="p-2">
                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          {project.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              هیچ پروژه فعالی یافت نشد
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
