import { db } from "./db";
import { projects } from "@shared/schema";

const projectsData = [
  {
    title: "بهسازی، لکه گیری و روکش آسفالت راه روستایی آشتجین، کنشکین، قلات واقع در شهرستان تاکستان",
    contractNumber: "۱۵/۷۰۸۶",
    contractDate: "۱۴۰۰/۰۲/۲۷",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۷۶٬۹۸۰٬۰۳۳٬۱۴۹",
    progress: 87,
    status: "active"
  },
  {
    title: "زیرسازی و آسفالت راه های روستایی شهرستان بوئین زهرا",
    contractNumber: "۱۵/۴۵۴۰",
    contractDate: "۱۴۰۱/۰۲/۰۸",
    contractor: "بهینه مطبوع کاوش کار",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۳۲۳٬۷۱۳٬۷۲۴٬۹۵۵",
    progress: 78,
    status: "active"
  },
  {
    title: "لکه گیری و بهسازی محورهای شهرستان های قزوین، تاکستان، آوج و محور دانسفهان، شامی شاب و ابهر",
    contractNumber: "۱۵/۲۶۹۲۸",
    contractDate: "۱۴۰۰/۰۶/۳۰",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۲۳۹٬۱۷۴٬۲۳۰٬۳۲۱",
    progress: 100,
    status: "completed"
  },
  {
    title: "بهسازی لکه گیری و روکش آسفالت محور قدیم قزوین-رشت",
    contractNumber: "۱۵/۴۵۰۲۵",
    contractDate: "۱۴۰۱/۰۹/۲۸",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۱٬۰۰۵٬۰۳۱٬۵۰۷٬۶۳۵",
    progress: 100,
    status: "completed"
  },
  {
    title: "بهسازی، لکه گیری و روکش آسفالت محور قزوین- تاکستان- آوج",
    contractNumber: "۱۵/۴۵۱۵۰",
    contractDate: "۱۴۰۱/۰۹/۲۹",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۵۰۷٬۸۹۳٬۸۷۸٬۶۲۰",
    progress: 100,
    status: "completed"
  },
  {
    title: "بهسازی و آسفالت محورهای بشر- دولت آباد و آبترش- نیکوئیه- ضیا آباد",
    contractNumber: "۱۵/۴۵۶۲۴",
    contractDate: "۱۴۰۱/۱۰/۰۱",
    contractor: "بهینه مطبوع کاوش کار",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۴۲۴٬۶۰۴٬۷۳۹٬۵۲۱",
    progress: 90,
    status: "active"
  },
  {
    title: "بهسازی محور اک- شامی شاپ و ساماندهی ورودی روستای اک و احداث زیرگذر قرقسین",
    contractNumber: "۲۸۰۱۶",
    contractDate: "۱۴۰۱/۰۸/۰۸",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راه و شهرسازی استان قزوین",
    amount: "۶۷۹٬۱۵۳٬۰۹۲٬۲۴۲",
    progress: 63,
    status: "active"
  },
  {
    title: "بهسازی و روکش آسفالت راه های روستایی شهرستان تاکستان",
    contractNumber: "۱۵/۳۱۳۸",
    contractDate: "۱۴۰۲/۰۱/۲۸",
    contractor: "خاک پی دنا",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۶۷۹٬۲۱۴٬۹۷۶٬۴۶۵",
    progress: 49,
    status: "active"
  },
  {
    title: "بهسازی روکش آسفالت آزادراه قزوین کرج و کنارگذر قزوین زنجان",
    contractNumber: "۱۵/۹۴۵۷",
    contractDate: "۱۴۰۳/۰۳/۰۱",
    contractor: "بهینه مطبوع کاوش کار",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    amount: "۴۴۷٬۳۹۷٬۷۶۷٬۸۴۱",
    progress: 62,
    status: "active"
  }
];

async function importProjects() {
  try {
    console.log('🚀 شروع وارد کردن پروژه‌ها...');
    
    const existingProjects = await db.select().from(projects);
    console.log(`📊 تعداد پروژه‌های موجود: ${existingProjects.length}`);

    let addedCount = 0;
    let skippedCount = 0;

    for (const project of projectsData) {
      const existing = existingProjects.find(p => p.contractNumber === project.contractNumber);
      
      if (existing) {
        console.log(`⚠️  پروژه با شماره قرارداد ${project.contractNumber} از قبل وجود دارد - رد شد`);
        skippedCount++;
        continue;
      }

      await db.insert(projects).values(project);
      console.log(`✅ پروژه "${project.title.substring(0, 50)}..." اضافه شد`);
      addedCount++;
    }

    const finalCount = await db.select().from(projects);
    console.log(`\n📊 خلاصه:`);
    console.log(`   ✅ پروژه‌های جدید اضافه شده: ${addedCount}`);
    console.log(`   ⚠️  پروژه‌های تکراری رد شده: ${skippedCount}`);
    console.log(`   📁 کل پروژه‌های سیستم: ${finalCount.length}`);
    console.log('🎉 عملیات با موفقیت انجام شد!');
    
  } catch (error) {
    console.error('❌ خطا در وارد کردن پروژه‌ها:', error);
    throw error;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  importProjects()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export { importProjects };
