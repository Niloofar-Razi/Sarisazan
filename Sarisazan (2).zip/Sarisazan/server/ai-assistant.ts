import { db } from "./db";
import { projects, alerts, tenders, statements } from "@shared/schema";
import { eq, or, like, sql as sqlOperator } from "drizzle-orm";

interface AssistantContext {
  projects: any[];
  alerts: any[];
  tenders: any[];
  statements: any[];
}

async function getProjectContext(projectId?: string): Promise<AssistantContext> {
  const context: AssistantContext = {
    projects: [],
    alerts: [],
    tenders: [],
    statements: []
  };

  if (projectId) {
    const project = await db.select().from(projects).where(eq(projects.id, projectId));
    context.projects = project;
    
    const projectAlerts = await db.select().from(alerts).where(eq(alerts.projectId, projectId));
    context.alerts = projectAlerts;

    const allTenders = await db.select().from(tenders);
    context.tenders = allTenders;

    const projectStatements = await db.select().from(statements).where(eq(statements.projectId, projectId));
    context.statements = projectStatements;
  } else {
    context.projects = await db.select().from(projects);
    context.alerts = await db.select().from(alerts);
    context.tenders = await db.select().from(tenders);
    context.statements = await db.select().from(statements);
  }

  return context;
}

// تابع کمکی برای تشخیص کلمات کلیدی در متن فارسی
function containsKeywords(text: string, keywords: string[]): boolean {
  const lowerText = text.toLowerCase();
  return keywords.some(keyword => lowerText.includes(keyword.toLowerCase()));
}

// تابع کمکی برای نرمال‌سازی متن فارسی
function normalizeText(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[؟!,،.\?\:\;«»\(\)]/g, ' ')  // حذف علائم نگارشی
    .split(/\s+/)  // جدا کردن با فاصله
    .filter(word => word.length > 1)  // حذف کلمات یک حرفی
    .filter(word => !['در', 'به', 'از', 'با', 'که', 'این', 'آن', 'و', 'یا'].includes(word)); // حذف حروف اضافه
}

// تابع کمکی برای جستجوی پروژه‌ها بر اساس تطابق توکن
function searchProjects(query: string, projects: any[]): any[] {
  const queryTokens = normalizeText(query);
  
  return projects.filter(p => {
    const titleTokens = normalizeText(p.title || '');
    const contractTokens = normalizeText(p.contractNumber || '');
    const locationTokens = normalizeText(p.location || '');
    
    // چک کردن تطابق توکن‌ها
    const hasCommonWithTitle = queryTokens.some(qt => titleTokens.some(tt => tt.includes(qt) || qt.includes(tt)));
    const hasCommonWithContract = queryTokens.some(qt => contractTokens.some(ct => ct.includes(qt) || qt.includes(ct)));
    const hasCommonWithLocation = queryTokens.some(qt => locationTokens.some(lt => lt.includes(qt) || qt.includes(lt)));
    
    return hasCommonWithTitle || hasCommonWithContract || hasCommonWithLocation;
  });
}

// تابع اصلی دستیار رایگان
export async function chatWithAssistant(message: string, projectId?: string): Promise<string> {
  try {
    const context = await getProjectContext(projectId);
    const lowerMessage = message.toLowerCase();

    // پاسخ به سوالات مربوط به تعداد پروژه‌ها
    if (containsKeywords(lowerMessage, ['چند پروژه', 'تعداد پروژه', 'چندتا پروژه', 'چقدر پروژه'])) {
      const totalProjects = context.projects.length;
      const activeProjects = context.projects.filter(p => p.status === 'active').length;
      const completedProjects = context.projects.filter(p => p.status === 'completed').length;
      
      return `📊 **اطلاعات پروژه‌ها:**
      
• مجموع پروژه‌ها: ${totalProjects} پروژه
• پروژه‌های فعال: ${activeProjects} پروژه
• پروژه‌های تکمیل شده: ${completedProjects} پروژه
• پروژه‌های در حال برنامه‌ریزی: ${context.projects.filter(p => p.status === 'planning').length} پروژه`;
    }

    // پاسخ به سوالات مربوط به هشدارها
    if (containsKeywords(lowerMessage, ['هشدار', 'اخطار', 'alert', 'چند هشدار', 'تعداد هشدار'])) {
      const openAlerts = context.alerts.filter(a => a.status === 'open');
      const criticalAlerts = openAlerts.filter(a => a.severity === 'critical');
      const warningAlerts = openAlerts.filter(a => a.severity === 'warning');
      
      if (openAlerts.length === 0) {
        return '✅ هیچ هشدار بازی در سیستم وجود ندارد.';
      }
      
      let response = `🔔 **هشدارهای باز:**\n\n• مجموع هشدارها: ${openAlerts.length}\n`;
      
      if (criticalAlerts.length > 0) {
        response += `• هشدارهای بحرانی: ${criticalAlerts.length}\n`;
      }
      if (warningAlerts.length > 0) {
        response += `• هشدارهای هشدار: ${warningAlerts.length}\n`;
      }
      
      response += '\n**آخرین هشدارها:**\n';
      openAlerts.slice(0, 3).forEach((alert, i) => {
        response += `\n${i + 1}. ${alert.title} (${alert.severity === 'critical' ? '🔴 بحرانی' : alert.severity === 'warning' ? '🟡 هشدار' : '🔵 اطلاعات'})`;
      });
      
      return response;
    }

    // پاسخ به سوالات مربوط به مناقصه‌ها
    if (containsKeywords(lowerMessage, ['مناقصه', 'tender', 'چند مناقصه', 'تعداد مناقصه'])) {
      const totalTenders = context.tenders.length;
      const openTenders = context.tenders.filter(t => t.status === 'open').length;
      
      return `📋 **اطلاعات مناقصه‌ها:**
      
• مجموع مناقصه‌ها: ${totalTenders}
• مناقصه‌های باز: ${openTenders}
• مناقصه‌های بسته: ${context.tenders.filter(t => t.status === 'closed').length}`;
    }

    // پاسخ به سوالات مربوط به صورت‌وضعیت‌ها
    if (containsKeywords(lowerMessage, ['صورت وضعیت', 'صورت‌وضعیت', 'وضعیت', 'statement'])) {
      const totalStatements = context.statements.length;
      const approvedStatements = context.statements.filter(s => s.status === 'تأیید شده').length;
      
      return `📝 **اطلاعات صورت‌وضعیت‌ها:**
      
• مجموع صورت‌وضعیت‌ها: ${totalStatements}
• تأیید شده: ${approvedStatements}
• در انتظار: ${context.statements.filter(s => s.status === 'در انتظار').length}`;
    }

    // جستجوی پروژه بر اساس نام یا شماره قرارداد
    if (containsKeywords(lowerMessage, ['پروژه', 'قرارداد', 'project'])) {
      // ساده‌سازی: از تمام متن پیام برای جستجو استفاده می‌کنیم
      const foundProjects = searchProjects(message, context.projects);
      
      if (foundProjects.length > 0) {
        let response = `🔍 **پروژه‌های یافت شده:**\n\n`;
        foundProjects.slice(0, 5).forEach((project, i) => {
          response += `${i + 1}. **${project.title}**\n`;
          response += `   • شماره قرارداد: ${project.contractNumber || 'ندارد'}\n`;
          response += `   • وضعیت: ${project.status === 'active' ? 'فعال' : project.status === 'completed' ? 'تکمیل شده' : 'برنامه‌ریزی'}\n`;
          response += `   • پیشرفت: ${project.progress || 0}%\n\n`;
        });
        return response;
      } else {
        // اگر پروژه‌ای پیدا نشد، اطلاعات کلی بده
        if (context.projects.length > 0) {
          return `🔍 پروژه مورد نظر یافت نشد.\n\n**پروژه‌های موجود:**\n${context.projects.slice(0, 5).map((p, i) => `${i + 1}. ${p.title}`).join('\n')}\n\nاز نوار جستجو برای یافتن پروژه استفاده کنید.`;
        } else {
          return '📂 هیچ پروژه‌ای در سیستم ثبت نشده است.';
        }
      }
    }

    // پاسخ به سوالات مربوط به پیشرفت
    if (containsKeywords(lowerMessage, ['پیشرفت', 'درصد', 'progress'])) {
      if (context.projects.length === 0) {
        return '📈 هیچ پروژه‌ای در سیستم یافت نشد.';
      }
      
      const avgProgress = context.projects.reduce((sum, p) => sum + (p.progress || 0), 0) / context.projects.length;
      const maxProgress = Math.max(...context.projects.map(p => p.progress || 0));
      const minProgress = Math.min(...context.projects.map(p => p.progress || 0));
      
      return `📈 **وضعیت پیشرفت پروژه‌ها:**
      
• میانگین پیشرفت کلی: ${avgProgress.toFixed(1)}%
• بالاترین پیشرفت: ${maxProgress}%
• پایین‌ترین پیشرفت: ${minProgress}%`;
    }

    // پاسخ به سوالات کلی
    if (containsKeywords(lowerMessage, ['سلام', 'hi', 'hello', 'درود'])) {
      return `سلام! 👋

من دستیار سیستم مدیریت پروژه هستم. می‌توانم به شما در موارد زیر کمک کنم:

🔹 اطلاعات پروژه‌ها
🔹 وضعیت هشدارها
🔹 مناقصه‌ها
🔹 صورت‌وضعیت‌ها
🔹 جستجوی پروژه‌ها

سوال خود را بپرسید!`;
    }

    // پاسخ پیش‌فرض
    return `متوجه سوال شما نشدم. لطفاً یکی از موارد زیر را بپرسید:

• تعداد پروژه‌ها چقدر است؟
• چند هشدار باز داریم؟
• وضعیت مناقصه‌ها چطور است؟
• پیشرفت پروژه‌ها چقدر است؟
• پروژه [نام پروژه] کجاست؟

یا می‌توانید از نوار جستجو برای یافتن پروژه‌ها استفاده کنید.`;
  } catch (error: any) {
    console.error("خطا در دستیار:", error);
    return "متأسفانه در پردازش درخواست شما خطایی رخ داد. لطفاً دوباره تلاش کنید.";
  }
}
