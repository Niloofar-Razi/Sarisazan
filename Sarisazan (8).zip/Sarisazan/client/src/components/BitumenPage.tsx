import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Download, Edit, Trash2, FileText } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns-jalali";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";
import { useToast } from "@/hooks/use-toast";
import { useProject } from "@/lib/project-context";

interface Project {
  id: string;
  title: string;
  contractNumber: string;
}

interface BitumenRecord {
  id: string;
  projectId: string;
  invoiceNumber: string;
  invoiceDate: string;
  quantity: string;
  billNumber: string;
  supplier: string;
  transportContractor: string;
  guaranteeType: string;
  invoices: string;
  type: string;
  unitPrice: string;
  totalAmount: string;
  hasInvoice: boolean;
  hasBill: boolean;
  hasWaybill: boolean;
  bitumenEntry: string;
  bitumenDeduction: string;
  bitumenUsed: string;
  notes: string;
}

export default function BitumenPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { selectedProject: contextProject } = useProject();
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSupplier, setFilterSupplier] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<BitumenRecord | null>(null);

  useEffect(() => {
    if (contextProject?.id) {
      setSelectedProject(contextProject.id);
    }
  }, [contextProject]);
  
  const initialFormData = {
    invoiceNumber: "",
    invoiceDate: format(new Date(), "yyyy/MM/dd"),
    quantity: "",
    billNumber: "",
    supplier: "",
    transportContractor: "",
    guaranteeType: "",
    invoices: "",
    type: "PG64-22",
    unitPrice: "",
    totalAmount: "",
    hasInvoice: false,
    hasBill: false,
    hasWaybill: false,
    bitumenEntry: "",
    bitumenDeduction: "",
    bitumenUsed: "",
    notes: "",
  };
  
  const [formData, setFormData] = useState(initialFormData);

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const { data: bitumenRecords = [] } = useQuery<BitumenRecord[]>({
    queryKey: ["/api/bitumen", selectedProject],
    queryFn: async () => {
      const response = await fetch(`/api/bitumen?projectId=${selectedProject}`);
      if (!response.ok) throw new Error("خطا در دریافت اطلاعات");
      return response.json();
    },
    enabled: !!selectedProject,
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/bitumen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, projectId: selectedProject }),
      });
      if (!response.ok) throw new Error("خطا در ثبت رکورد");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen", selectedProject] });
      setIsAddDialogOpen(false);
      resetForm();
      toast({ title: "رکورد با موفقیت ثبت شد" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const response = await fetch(`/api/bitumen/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ویرایش رکورد");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen", selectedProject] });
      setIsEditDialogOpen(false);
      setEditingRecord(null);
      resetForm();
      toast({ title: "رکورد با موفقیت ویرایش شد" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/bitumen/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("خطا در حذف رکورد");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen", selectedProject] });
      toast({ title: "رکورد با موفقیت حذف شد" });
    },
  });

  const resetForm = () => {
    setFormData(initialFormData);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRecord) {
      updateMutation.mutate({ id: editingRecord.id, data: formData });
    }
  };

  const handleEdit = (record: BitumenRecord) => {
    setEditingRecord(record);
    setFormData({
      invoiceNumber: record.invoiceNumber || "",
      invoiceDate: record.invoiceDate || "",
      quantity: record.quantity || "",
      billNumber: record.billNumber || "",
      supplier: record.supplier || "",
      transportContractor: record.transportContractor || "",
      guaranteeType: record.guaranteeType || "",
      invoices: record.invoices || "",
      type: record.type || "PG64-22",
      unitPrice: record.unitPrice || "",
      totalAmount: record.totalAmount || "",
      hasInvoice: record.hasInvoice || false,
      hasBill: record.hasBill || false,
      hasWaybill: record.hasWaybill || false,
      bitumenEntry: record.bitumenEntry || "",
      bitumenDeduction: record.bitumenDeduction || "",
      bitumenUsed: record.bitumenUsed || "",
      notes: record.notes || "",
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("آیا از حذف این رکورد مطمئن هستید؟")) {
      deleteMutation.mutate(id);
    }
  };

  const filteredRecords = useMemo(
    () => bitumenRecords.filter((record) => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = 
        (record.invoiceNumber || "").toLowerCase().includes(searchLower) ||
        (record.supplier || "").toLowerCase().includes(searchLower) ||
        (record.billNumber || "").toLowerCase().includes(searchLower);
      const matchesSupplier = filterSupplier === "all" || (record.supplier || "") === filterSupplier;
      const matchesType = filterType === "all" || (record.type || "") === filterType;
      return matchesSearch && matchesSupplier && matchesType;
    }),
    [bitumenRecords, searchTerm, filterSupplier, filterType]
  );

  const totals = useMemo(
    () => filteredRecords.reduce(
      (acc, record) => ({
        quantity: acc.quantity + (parseFloat(record.quantity) || 0),
        amount: acc.amount + (parseFloat(record.totalAmount) || 0),
      }),
      { quantity: 0, amount: 0 }
    ),
    [filteredRecords]
  );

  const exportToCSV = () => {
    const headers = [
      "شماره حواله",
      "تاریخ",
      "مقدار",
      "شماره صورتحساب",
      "تأمین‌کننده",
      "پیمانکار حمل",
      "نوع تضمین",
      "فاکتورها",
      "نوع",
      "قیمت واحد",
      "مبلغ کل",
      "حواله",
      "فاکتور",
      "بارنامه",
      "ورود قیر",
      "کسر قیر",
      "قیر مصرفی",
      "توضیحات"
    ];
    
    const rows = filteredRecords.map(record => [
      record.invoiceNumber || "-",
      record.invoiceDate || "-",
      record.quantity || "-",
      record.billNumber || "-",
      record.supplier || "-",
      record.transportContractor || "-",
      record.guaranteeType || "-",
      record.invoices || "-",
      record.type || "-",
      record.unitPrice || "-",
      record.totalAmount || "-",
      record.hasInvoice ? "دارد" : "ندارد",
      record.hasBill ? "دارد" : "ندارد",
      record.hasWaybill ? "دارد" : "ندارد",
      record.bitumenEntry || "-",
      record.bitumenDeduction || "-",
      record.bitumenUsed || "-",
      record.notes || "-"
    ]);

    const csvContent = [headers, ...rows]
      .map(row => row.join(","))
      .join("\n");

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `bitumen_records_${selectedProject}_${Date.now()}.csv`;
    link.click();
  };

  const suppliers = useMemo(
    () => Array.from(new Set(bitumenRecords.map(r => r.supplier).filter(Boolean))),
    [bitumenRecords]
  );
  
  const types = useMemo(
    () => Array.from(new Set(bitumenRecords.map(r => r.type).filter(Boolean))),
    [bitumenRecords]
  );

  const FormFields = () => (
    <>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>شماره حواله</Label>
          <Input
            value={formData.invoiceNumber}
            onChange={(e) => setFormData({ ...formData, invoiceNumber: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>تاریخ حواله</Label>
          <Input
            value={formData.invoiceDate}
            onChange={(e) => setFormData({ ...formData, invoiceDate: e.target.value })}
            placeholder="1403/07/15"
          />
        </div>
        <div className="space-y-2">
          <Label>مقدار (تن)</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.quantity}
            onChange={(e) => {
              const quantity = e.target.value;
              const unitPrice = formData.unitPrice;
              const totalAmount = quantity && unitPrice ? (parseFloat(quantity) * parseFloat(unitPrice)).toString() : "";
              setFormData({ ...formData, quantity, totalAmount });
            }}
          />
        </div>
        <div className="space-y-2">
          <Label>شماره صورتحساب</Label>
          <Input
            value={formData.billNumber}
            onChange={(e) => setFormData({ ...formData, billNumber: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>تأمین‌کننده</Label>
          <Input
            value={formData.supplier}
            onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>پیمانکار حمل</Label>
          <Input
            value={formData.transportContractor}
            onChange={(e) => setFormData({ ...formData, transportContractor: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>نوع تضمین</Label>
          <Input
            value={formData.guaranteeType}
            onChange={(e) => setFormData({ ...formData, guaranteeType: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>فاکتورها (جدا شده با کاما)</Label>
          <Textarea
            value={formData.invoices}
            onChange={(e) => setFormData({ ...formData, invoices: e.target.value })}
            placeholder="شماره فاکتور 1, شماره فاکتور 2, ..."
            rows={2}
          />
        </div>
        <div className="space-y-2">
          <Label>نوع قیر</Label>
          <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="PG64-22">PG64-22</SelectItem>
              <SelectItem value="PG64-16">PG64-16</SelectItem>
              <SelectItem value="PG58-22">PG58-22</SelectItem>
              <SelectItem value="60/70">60/70</SelectItem>
              <SelectItem value="85/100">85/100</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>قیمت واحد (ریال)</Label>
          <Input
            type="number"
            value={formData.unitPrice}
            onChange={(e) => {
              const unitPrice = e.target.value;
              const quantity = formData.quantity;
              const totalAmount = quantity && unitPrice ? (parseFloat(quantity) * parseFloat(unitPrice)).toString() : "";
              setFormData({ ...formData, unitPrice, totalAmount });
            }}
          />
        </div>
        <div className="space-y-2">
          <Label>مبلغ کل (ریال)</Label>
          <Input
            type="number"
            value={formData.totalAmount}
            onChange={(e) => setFormData({ ...formData, totalAmount: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>ورود قیر (تن)</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.bitumenEntry}
            onChange={(e) => setFormData({ ...formData, bitumenEntry: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>کسر قیر (تن)</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.bitumenDeduction}
            onChange={(e) => setFormData({ ...formData, bitumenDeduction: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>قیر مصرفی (تن)</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.bitumenUsed}
            onChange={(e) => setFormData({ ...formData, bitumenUsed: e.target.value })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>وضعیت اسناد</Label>
        <div className="flex gap-4">
          <div className="flex items-center space-x-2 space-x-reverse">
            <Checkbox
              id="hasInvoice"
              checked={formData.hasInvoice}
              onCheckedChange={(checked) => setFormData({ ...formData, hasInvoice: checked as boolean })}
            />
            <Label htmlFor="hasInvoice" className="cursor-pointer">حواله</Label>
          </div>
          <div className="flex items-center space-x-2 space-x-reverse">
            <Checkbox
              id="hasBill"
              checked={formData.hasBill}
              onCheckedChange={(checked) => setFormData({ ...formData, hasBill: checked as boolean })}
            />
            <Label htmlFor="hasBill" className="cursor-pointer">فاکتور</Label>
          </div>
          <div className="flex items-center space-x-2 space-x-reverse">
            <Checkbox
              id="hasWaybill"
              checked={formData.hasWaybill}
              onCheckedChange={(checked) => setFormData({ ...formData, hasWaybill: checked as boolean })}
            />
            <Label htmlFor="hasWaybill" className="cursor-pointer">بارنامه</Label>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label>توضیحات</Label>
        <Textarea
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          rows={3}
        />
      </div>
    </>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">مدیریت قیر</h1>
          <p className="text-muted-foreground">ثبت و پیگیری حواله‌ها و مصرف قیر پروژه‌ها</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <Select value={selectedProject} onValueChange={setSelectedProject}>
          <SelectTrigger className="w-full md:w-64">
            <SelectValue placeholder="انتخاب پروژه" />
          </SelectTrigger>
          <SelectContent>
            {projects.map((project) => (
              <SelectItem key={project.id} value={project.id}>
                {project.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {selectedProject && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 ml-2" />
                افزودن ردیف قیر
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>افزودن ردیف جدید قیر</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <FormFields />
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    انصراف
                  </Button>
                  <Button type="submit">ثبت</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {selectedProject && (
        <>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="جستجو در رکوردها..."
                className="pr-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterSupplier} onValueChange={setFilterSupplier}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="تأمین‌کننده" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه تأمین‌کنندگان</SelectItem>
                {suppliers.map((supplier) => (
                  <SelectItem key={supplier} value={supplier}>{supplier}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="نوع قیر" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه انواع</SelectItem>
                {types.map((type) => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={exportToCSV}>
              <Download className="w-4 h-4 ml-2" />
              خروجی CSV
            </Button>
          </div>

          <div className="border rounded-lg p-4 bg-muted/30">
            <div className="flex justify-between items-center">
              <div>
                <span className="text-sm text-muted-foreground">جمع مقدار: </span>
                <span className="font-bold">{toPersianDigits(totals.quantity.toFixed(2))} تن</span>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">جمع مبلغ: </span>
                <span className="font-bold">{formatCurrency(totals.amount)} ریال</span>
              </div>
            </div>
          </div>

          <div className="border rounded-lg overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>شماره حواله</TableHead>
                  <TableHead>تاریخ</TableHead>
                  <TableHead>مقدار (تن)</TableHead>
                  <TableHead>تأمین‌کننده</TableHead>
                  <TableHead>پیمانکار حمل</TableHead>
                  <TableHead>نوع تضمین</TableHead>
                  <TableHead>نوع قیر</TableHead>
                  <TableHead>قیمت واحد</TableHead>
                  <TableHead>مبلغ کل</TableHead>
                  <TableHead>اسناد</TableHead>
                  <TableHead>ورود</TableHead>
                  <TableHead>کسر</TableHead>
                  <TableHead>مصرفی</TableHead>
                  <TableHead>توضیحات</TableHead>
                  <TableHead>عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecords.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={15} className="text-center text-muted-foreground py-8">
                      هیچ رکوردی یافت نشد
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.invoiceNumber || "-"}</TableCell>
                      <TableCell>{toPersianDigits(record.invoiceDate || "-")}</TableCell>
                      <TableCell>{toPersianDigits(record.quantity || "-")}</TableCell>
                      <TableCell>{record.supplier || "-"}</TableCell>
                      <TableCell>{record.transportContractor || "-"}</TableCell>
                      <TableCell>{record.guaranteeType || "-"}</TableCell>
                      <TableCell>{record.type || "-"}</TableCell>
                      <TableCell>{record.unitPrice ? formatCurrency(parseFloat(record.unitPrice)) : "-"}</TableCell>
                      <TableCell>{record.totalAmount ? formatCurrency(parseFloat(record.totalAmount)) : "-"}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {record.hasInvoice && <FileText className="w-4 h-4 text-green-600" />}
                          {record.hasBill && <FileText className="w-4 h-4 text-blue-600" />}
                          {record.hasWaybill && <FileText className="w-4 h-4 text-orange-600" />}
                        </div>
                      </TableCell>
                      <TableCell>{toPersianDigits(record.bitumenEntry || "-")}</TableCell>
                      <TableCell>{toPersianDigits(record.bitumenDeduction || "-")}</TableCell>
                      <TableCell>{toPersianDigits(record.bitumenUsed || "-")}</TableCell>
                      <TableCell className="max-w-xs truncate">{record.notes || "-"}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(record)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(record.id)}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </>
      )}

      {!selectedProject && (
        <div className="text-center text-muted-foreground py-12">
          لطفاً یک پروژه را انتخاب کنید
        </div>
      )}

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>ویرایش رکورد قیر</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <FormFields />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                انصراف
              </Button>
              <Button type="submit">ذخیره تغییرات</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
