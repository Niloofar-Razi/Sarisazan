import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toPersianDigits } from "@/lib/persian-utils";
import { useLocation } from "wouter";
import type { Project, Task } from "@shared/schema";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line
} from "recharts";
import { 
  FolderKanban, TrendingUp, Activity, CheckCircle2, 
  ChevronLeft, Eye
} from "lucide-react";

interface Alert {
  id: string;
  title: string;
  description?: string;
  severity: string;
  status: string;
}

export default function ProfessionalDashboard() {
  const [, setLocation] = useLocation();

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const response = await fetch("/api/tasks");
      if (!response.ok) throw new Error("خطا در دریافت وظایف");
      return response.json();
    },
  });

  const { data: alerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    queryFn: async () => {
      const response = await fetch("/api/alerts");
      if (!response.ok) throw new Error("خطا در دریافت هشدارها");
      return response.json();
    },
  });

  const metrics = useMemo(() => {
    const activeProjects = projects.filter(p => p.status === 'active').length;
    const totalProjects = projects.length;
    const openTasks = tasks.filter(t => !t.isCompleted).length;
    
    const avgProgress = projects.length > 0
      ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
      : 0;

    const recentProjects = projects.slice(0, 5);
    const progressTrend = recentProjects.map((p, i) => ({
      index: i + 1,
      value: p.progress || 0
    }));

    const taskTrend = [
      { month: 'فروردین', tasks: 12 },
      { month: 'اردیبهشت', tasks: 15 },
      { month: 'خرداد', tasks: 10 },
      { month: 'تیر', tasks: 13 },
      { month: 'مرداد', tasks: openTasks }
    ];

    return { activeProjects, totalProjects, openTasks, avgProgress, progressTrend, taskTrend };
  }, [projects, tasks]);

  const chartData = useMemo(() => {
    const progressRanges = [
      { range: '۰٪', count: projects.filter(p => (p.progress || 0) === 0).length },
      { range: '۱-۲۵٪', count: projects.filter(p => (p.progress || 0) > 0 && (p.progress || 0) <= 25).length },
      { range: '۲۶-۵۰٪', count: projects.filter(p => (p.progress || 0) > 25 && (p.progress || 0) <= 50).length },
      { range: '۵۱-۷۵٪', count: projects.filter(p => (p.progress || 0) > 50 && (p.progress || 0) <= 75).length },
      { range: '۷۶-۹۹٪', count: projects.filter(p => (p.progress || 0) > 75 && (p.progress || 0) < 100).length },
      { range: '۱۰۰٪', count: projects.filter(p => (p.progress || 0) >= 100).length }
    ];

    const contractorDistribution: { [key: string]: number } = {};
    projects.forEach(p => {
      if (p.contractor) {
        contractorDistribution[p.contractor] = (contractorDistribution[p.contractor] || 0) + 1;
      }
    });

    const contractorData = Object.entries(contractorDistribution)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 4);

    const recentPerformance = projects
      .filter(p => p.status === 'active')
      .slice(0, 8)
      .map(p => ({
        name: p.title?.substring(0, 20) + '...' || 'پروژه',
        progress: p.progress || 0
      }));

    return { progressRanges, contractorData, recentPerformance };
  }, [projects]);

  const CONTRACTOR_COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];
  const PROGRESS_COLORS = ['#10b981', '#3b82f6'];

  return (
    <div className="space-y-6 p-6 bg-gray-50 dark:bg-gray-950">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">داشبورد پروژه‌ها</h1>
          <p className="text-muted-foreground">نمای کلی عملکرد و وضعیت</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-950/30 dark:to-emerald-900/20 border-green-200 dark:border-green-800 overflow-hidden">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center">
              <p className="text-sm text-green-700 dark:text-green-400 mb-2">میانگین پیشرفت</p>
              <div className="relative w-32 h-32 mb-2">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="currentColor"
                    strokeWidth="12"
                    fill="none"
                    className="text-green-200 dark:text-green-900/40"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="currentColor"
                    strokeWidth="12"
                    fill="none"
                    strokeDasharray={`${2 * Math.PI * 56}`}
                    strokeDashoffset={`${2 * Math.PI * 56 * (1 - metrics.avgProgress / 100)}`}
                    className="text-green-600 dark:text-green-400"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl font-bold text-green-900 dark:text-green-100">
                    {toPersianDigits(`${metrics.avgProgress}٪`)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-amber-100 dark:from-orange-950/30 dark:to-amber-900/20 border-orange-200 dark:border-orange-800">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-orange-700 dark:text-orange-400 mb-1">پروژه‌های فعال</p>
                <h3 className="text-5xl font-bold text-orange-900 dark:text-orange-100">
                  {toPersianDigits(metrics.activeProjects.toString())}
                </h3>
              </div>
            </div>
            <div className="h-16">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={metrics.progressTrend}>
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#f97316" 
                    strokeWidth={3}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-rose-100 dark:from-red-950/30 dark:to-rose-900/20 border-red-200 dark:border-red-800">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-red-700 dark:text-red-400 mb-1">وظایف باز</p>
                <h3 className="text-5xl font-bold text-red-900 dark:text-red-100">
                  {toPersianDigits(metrics.openTasks.toString())}
                </h3>
                <p className="text-xs text-red-600 dark:text-red-500 mt-1">نیازمند بررسی</p>
              </div>
            </div>
            <div className="h-16">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={metrics.taskTrend}>
                  <Line 
                    type="monotone" 
                    dataKey="tasks" 
                    stroke="#ef4444" 
                    strokeWidth={3}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-cyan-100 dark:from-blue-950/30 dark:to-cyan-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="pt-6">
            <div>
              <p className="text-sm text-blue-700 dark:text-blue-400 mb-2">عملکرد میانگین</p>
              <h3 className="text-4xl font-bold text-blue-900 dark:text-blue-100 mb-1">
                {toPersianDigits(`${Math.min(metrics.avgProgress, 100)}٪`)}
              </h3>
              <p className="text-xs text-blue-600 dark:text-blue-500 mb-4">پیشرفت کلی</p>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-blue-200 dark:bg-blue-900/40 rounded-full h-2">
                    <div 
                      className="h-full bg-gradient-to-r from-red-500 to-blue-600 rounded-full transition-all"
                      style={{ width: `${metrics.avgProgress}%` }}
                    />
                  </div>
                </div>
                <div className="flex justify-between text-xs text-blue-600 dark:text-blue-500">
                  <span>{toPersianDigits('۰٪')}</span>
                  <span>{toPersianDigits('۵۰٪')}</span>
                  <span>{toPersianDigits('۱۰۰٪')}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>توزیع پیشرفت پروژه‌ها</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData.progressRanges} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="range" type="category" width={60} />
                <Tooltip />
                <Bar dataKey="count" fill="#10b981" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>توزیع پیمانکاران</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={chartData.contractorData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    dataKey="count"
                    label={({ name, count }) => count > 0 ? toPersianDigits(count.toString()) : ''}
                    labelLine={true}
                  >
                    {chartData.contractorData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={CONTRACTOR_COLORS[index % CONTRACTOR_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: any) => toPersianDigits(value.toString())}
                    labelFormatter={(label) => label}
                  />
                  <Legend 
                    verticalAlign="bottom"
                    height={36}
                    formatter={(value) => value}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-4 w-full space-y-2">
                {chartData.contractorData.map((item, index) => (
                  <div key={index} className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent/50 transition-colors">
                    <div 
                      className="w-4 h-4 rounded-full flex-shrink-0" 
                      style={{ backgroundColor: CONTRACTOR_COLORS[index % CONTRACTOR_COLORS.length] }}
                    />
                    <span className="text-sm flex-1 font-medium">{item.name}</span>
                    <Badge variant="secondary" className="font-bold">
                      {toPersianDigits(item.count.toString())} پروژه
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>عملکرد اخیر</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData.recentPerformance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="name" 
                  angle={-45} 
                  textAnchor="end" 
                  height={100}
                  interval={0}
                  tick={{ fontSize: 10 }}
                />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Bar dataKey="progress" fill="#3b82f6" radius={[4, 4, 0, 0]}>
                  {chartData.recentPerformance.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.progress > 75 ? '#10b981' : entry.progress > 50 ? '#3b82f6' : entry.progress > 25 ? '#f59e0b' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>پروژه‌های اخیر</CardTitle>
          <Button variant="ghost" size="sm" onClick={() => setLocation('/projects')}>
            مشاهده همه
            <ChevronLeft className="w-4 h-4 mr-1" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {projects.slice(0, 5).map((project) => (
              <div 
                key={project.id}
                className="flex items-start gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors cursor-pointer"
                onClick={() => setLocation(`/projects/${project.id}`)}
              >
                <div className="flex-1">
                  <div className="flex items-start gap-2">
                    <h4 className="font-semibold text-base flex-1">{project.title}</h4>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                    <div>
                      <span className="font-medium">پیمانکار:</span> {project.contractor || '-'}
                    </div>
                    <div>
                      <span className="font-medium">شماره قرارداد:</span> {toPersianDigits(project.contractNumber || '-')}
                    </div>
                  </div>
                  <div className="mt-3 flex items-center gap-3">
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div 
                        className="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full transition-all"
                        style={{ width: `${Math.min(project.progress || 0, 100)}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium min-w-[3rem] text-right">
                      {toPersianDigits(`${project.progress || 0}٪`)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
