# Overview

This is a comprehensive construction project management system called "سریع‌سازان البرز" (Sarisazan Alborz). The application is designed specifically for Persian/Farsi-speaking users in the construction industry, providing tools for project tracking, material management (specifically bitumen), tender management, alerts, reporting, internal messaging, and an AI assistant powered by Grok API for answering questions about construction contract terms (شرایط عمومی پیمان).

The system is built as a full-stack monorepo application with a React frontend, Express.js backend, and PostgreSQL database, featuring comprehensive authentication, role-based access control, and extensive data management capabilities.

# Recent Changes

**October 27, 2025 - Professional Dashboard & Sample Projects** - Major dashboard redesign with real data:
- Created new `ProfessionalDashboard` component with modern, professional design inspired by provided mockup
- Added 4 professional metric cards:
  - میانگین پیشرفت (Average Progress) - Large circular progress indicator with green gradient
  - پروژه‌های فعال (Active Projects) - Number display with trend line chart in orange/amber gradient
  - وظایف باز (Open Tasks) - Count with trend visualization in red/rose gradient
  - عملکرد میانگین (Average Performance) - Percentage with horizontal progress bar in blue/cyan gradient
- Implemented 3 analytical charts:
  - توزیع پیشرفت پروژه‌ها (Progress Distribution) - Horizontal bar chart showing project progress ranges
  - توزیع پیمانکاران (Contractor Distribution) - Donut chart showing project count per contractor
  - عملکرد اخیر (Recent Performance) - Vertical bar chart with color-coded performance by project
- Added "پروژه‌های اخیر" (Recent Projects) section with expandable cards showing full project details
- Projects display with clickable eye icon to view full details
- Seeded database with 13 real sample projects from provided data (via `server/seed-projects.ts`)
- Updated `/dashboard` route to use `ProfessionalDashboard` component
- All charts and metrics use Persian/Farsi text and Persian numerals
- Auto-alert system generated 3 alerts for projects with progress below 50%
- Updated seed script with actual project data including contract numbers, dates, contractors, and employers

**October 27, 2025 - Fresh GitHub Import to Replit** - Successfully set up the project in Replit environment:
- Extracted project from Sarisazan.zip archive
- Moved all files from subdirectory to root directory for proper structure
- Installed Python 3.11 (required for zip extraction utilities)
- Installed all npm dependencies (496 packages)
- Connected to PostgreSQL database (already provisioned in Replit environment)
- Pushed database schema using Drizzle Kit (34 permissions, 6 default roles created)
- Configured development workflow "Server" running on port 5000
- Set up VM deployment configuration (build: npm run build, run: npm start)
- Default admin user auto-created on first server start (username: admin, password: admin123)
- Application verified working with login page displaying correctly
- Frontend properly configured with host: 0.0.0.0, allowedHosts: true for Replit proxy
- Note: XAI_API_KEY is optional - AI assistant requires this key to function, but the rest of the application works without it

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Language and Localization
- **Full Persian/Farsi Interface**: All UI elements, content, and data display in Farsi with RTL (Right-to-Left) layout support
- **Jalali Calendar System**: All dates use the Persian calendar for display and input
- **Iranian Rial Currency**: Financial data formatted with Iranian Rial (ریال)
- **Persian Number Conversion**: Utility functions (`toPersianDigits`) convert Western numerals to Persian numerals throughout the UI

## Frontend Architecture
- **Framework**: React 18 with TypeScript, Vite as build tool
- **State Management**: TanStack Query (React Query) for server state, React Context for global state (project selection)
- **UI Components**: Radix UI primitives with shadcn/ui design system
- **Styling**: Tailwind CSS with custom RTL-optimized configuration, theme support (light/dark modes)
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Charts**: Recharts library for dashboard data visualization

## Backend Architecture
- **Server Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints organized in a single routes file
- **Session Management**: Express sessions with PostgreSQL storage (connect-pg-simple)
- **File Handling**: Multer middleware for multipart form data and file uploads
- **Authentication**: bcrypt.js for password hashing, session-based authentication
- **Scheduled Tasks**: Auto-alert scheduler runs hourly to check tender deadlines and project milestones

## Database Architecture
- **Database**: PostgreSQL (Neon serverless or standard PostgreSQL)
- **ORM**: Drizzle ORM with schema-first approach
- **Schema Location**: Shared schema definition in `shared/schema.ts`
- **Migration Strategy**: Drizzle Kit for schema migrations
- **Key Tables**: users, roles, permissions, role_permissions, projects, user_projects, bitumen_records, statements, adjustments, bitumen_differences, tenders, alerts, alert_recipients, alert_comments, sheets, sheet_files, tasks, task_files, conversations, conversation_members, messages, message_files, message_reads, reports, execution_reports, calendar_notes, sticky_notes, note_items, daily_notes, follow_up_tasks, letters, letter_recipients, user_preferences

## AI Assistant System
- **Primary AI**: Grok API (xAI) using grok-2-1212 model for Persian-language responses
- **Knowledge Base**: Preprocessed legal documents (شرایط عمومی پیمان) for construction contract terms
- **Multi-Source Query**: System classifies queries and routes to appropriate source:
  - Database queries for project/operational data
  - Legal document queries for contract terms
  - General queries to Grok API
- **Local Search**: Previously used Fuse.js for local fuzzy search (may be deprecated based on user notes requesting external search)
- **Response Caching**: 7-day cache for API responses to reduce costs and latency
- **Context-Aware**: Can reference specific projects and provide relevant answers

## File Management
- **Storage**: Local filesystem storage in `uploads/` directory
- **File Types**: Support for PDFs, images, documents
- **Cleanup Service**: Automated cleanup of temporary files older than 24 hours
- **Organization**: Files organized by entity type (sheets, tasks, messages, etc.)

## Authentication & Authorization
- **Role-Based Access Control (RBAC)**: Granular permissions system with roles and permission mappings
- **Default Roles**: Admin, Manager, User, Viewer
- **Permission Categories**: Projects, Reports, Bitumen, Sheets, Tenders, Alerts, Users, Roles, Messages
- **User Management**: Full CRUD operations, password reset functionality, force password reset option
- **Session Security**: Server-side session management with PostgreSQL backing

## Key Features Architecture

### Project Management
- CRUD operations for construction projects
- Progress tracking with percentage completion
- Project-specific material (bitumen) records
- User assignment to projects via junction table
- Project filtering and global search functionality

### Material Management (Bitumen)
- Project-scoped bitumen records
- Invoice tracking with multiple invoice support
- Supplier and transport contractor management
- Guarantee type tracking
- Document flags (invoice, bill, waybill)
- Entry/deduction/usage tracking
- CSV export capability

### Progress Statements System
- Three-tab interface: Statements, Adjustments, Bitumen Differences
- Financial calculations for work periods
- Index-based adjustments
- Status workflow (pending, approved, paid)
- File attachment support
- Soft delete functionality

### Tender Management
- Comprehensive tender tracking (title, city, amount, dates)
- Deadline monitoring with automated alerts
- Multi-company participation tracking
- Status workflow
- SLA-based sorting (prioritizes approaching deadlines)

### Alert System
- Multi-severity alerts (low, medium, high, critical)
- Alert recipients with user assignment
- Comment threads on alerts
- Status tracking (open, acknowledged, resolved, closed)
- Entity linking (projects, tenders)
- Personal vs. project-scoped alerts
- CSV export
- Automated alert generation for tender deadlines

### Internal Messaging
- Three conversation types: Direct, Group, Project-specific
- File attachment support
- Read/unread tracking per user
- Member management for conversations
- Message search functionality

### Lab Sheets Management
- Multiple sheet types (quality control, material tests, soil tests, etc.)
- File attachments
- Status workflow (pending, approved, rejected)
- Project association
- Advanced filtering
- CSV export

### Task Management
- Task assignment to users
- Project linking
- Priority levels (low, medium, high, urgent)
- Reminder functionality with date/time
- File attachments
- Confirmation workflow
- Completion tracking

### Calendar System
- Jalali calendar display
- Daily notes (CRUD operations)
- Task reminder badges on calendar dates
- Visual indicators for dates with content

### Reporting
- Daily activity reports
- Execution progress reports with:
  - Weather conditions
  - Temperature tracking
  - Machinery usage logs
  - Material consumption
  - Labor tracking
  - Work description
  - Photo attachments

### Dashboard
- Real-time KPIs from database
- Open alerts tab
- Data analysis tab with charts (Recharts)
- Project progress visualization
- Status distribution

## Project Structure
```
/client           # Frontend React application
  /src
    /components   # React components
    /lib         # Utilities, context providers
    /pages       # Page components
/server          # Backend Express application
  /routes.ts     # API route definitions
  /db.ts         # Database connection
  /agent-service.ts    # AI assistant service
  /multi-source-agent.ts  # Query routing logic
  /storage.ts    # Storage abstractions
/shared          # Shared types and schema
  /schema.ts     # Drizzle schema definitions
/migrations      # Database migrations
```

## Design System
- **Color Palette**: Vibrant, balanced colors with WCAG AA compliance (4.5:1 contrast ratio)
- **Page-Specific Themes**: Distinct color themes for different sections (dashboard, projects, tasks, etc.)
- **Typography**: Vazirmatn font family for Persian text, JetBrains Mono for numbers/data
- **Spacing**: Tailwind standard spacing scale (4, 6, 8, 12)
- **Components**: Consistent use of shadcn/ui components with RTL support

# External Dependencies

## Core Infrastructure
- **Database**: PostgreSQL (via Neon serverless or standard connection)
- **AI Service**: Grok API (xAI) - grok-2-1212 model for Persian language processing

## Authentication & Security
- **Password Hashing**: bcryptjs
- **Session Storage**: connect-pg-simple (PostgreSQL-backed sessions)

## File Processing
- **File Uploads**: multer
- **File Compression**: adm-zip

## Frontend Libraries
- **UI Components**: Radix UI primitives (@radix-ui/react-*)
- **Styling**: Tailwind CSS with autoprefixer
- **State Management**: TanStack Query (@tanstack/react-query)
- **Form Validation**: React Hook Form, Zod, @hookform/resolvers
- **Date Handling**: date-fns-jalali, jalaali-js
- **Charts**: recharts
- **Icons**: lucide-react
- **Utilities**: clsx, class-variance-authority

## Backend Libraries
- **ORM**: Drizzle ORM (drizzle-orm, drizzle-kit)
- **Database Driver**: @neondatabase/serverless, pg (node-postgres)
- **AI Integration**: openai package (configured for xAI endpoint)
- **Search**: fuse.js (for local fuzzy search - may be deprecated)

## Development Tools
- **Build Tool**: Vite with React plugin
- **TypeScript**: Full TypeScript support across stack
- **Linting**: ESBuild for production builds
- **Dev Enhancements**: Replit-specific plugins for error overlay, dev banner

## Note on Future Changes
Based on user notes in attached assets, there are plans to:
- Remove local search (Fuse.js) in favor of external search engines (Elasticsearch or SQL-based)
- Upgrade to Grok 4 for enhanced AI reasoning
- Implement automated file cleanup after processing
- Optimize database structure for scalability