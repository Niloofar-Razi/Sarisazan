# Overview

"سریع‌سازان البرز" (Sarisazan Alborz) is a comprehensive construction project management system tailored for Persian/Farsi-speaking users. It offers tools for project tracking, bitumen material management, tender management, alerts, reporting, internal messaging, and an AI assistant for construction contract queries. The system aims to streamline construction project workflows, improve efficiency, and provide robust data management. It's built as a full-stack monorepo with React, Express.js, and PostgreSQL, featuring strong authentication and role-based access control.

# Recent Changes

**October 29, 2025 - GitHub Import Successfully Set Up**:
- ✅ Extracted project from GitHub import archive to root directory
- ✅ Installed Node.js 20 (v20.19.3) with npm 10.8.2
- ✅ Installed all npm dependencies (496 packages)
- ✅ Connected to Replit-managed PostgreSQL database
- ✅ Pushed database schema using Drizzle Kit (34 permissions, 6 roles)
- ✅ Created default admin user (username: admin, password: admin123)
- ✅ **Imported 12 construction projects with sample data:**
  - 9 basic construction projects (road improvement, asphalt work)
  - 3 detailed sample projects with full data
  - 14 progress statements (صورت وضعیت)
  - 14 adjustments (تعدیل)
  - 2 bitumen difference records (مابه‌التفاوت قیر)
- ✅ Configured dev workflow "Server" on port 5000 with Vite HMR
- ✅ Configured deployment settings (autoscale deployment with build/start)
- ✅ Verified application running - Persian/Farsi login page displaying correctly
- ✅ Auto-alert system initialized (checks every 60 minutes)
- ✅ File cleanup service initialized (runs every 24 hours)
- ✅ Vite configuration properly set for Replit proxy (allowedHosts: true, HMR on port 443)
- ⚠️ XAI_API_KEY environment variable needed for AI assistant feature (optional)

**Previous Development Work**:
- ✅ Fixed UsersPage query parameter handling - now correctly fetches users with filters
- ✅ Added professional loading skeletons to UsersPage, ProjectsPage, and ManagementDashboard
- ✅ Created auto-import projects API endpoint (/api/admin/import-projects) for development
- ✅ Cleaned up unnecessary text files from attached_assets directory
- ✅ Verified bitumen differences section exists in management dashboard with full data
- ✅ Confirmed AI agent has 7-day response caching for performance
- ✅ Verified messaging system supports 1-on-1 and group conversations with files
- ✅ All core features are functional and production-ready

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Language and Localization
- **Full Persian/Farsi Interface**: RTL layout, Farsi UI and data display.
- **Jalali Calendar System**: All dates use the Persian calendar.
- **Iranian Rial Currency**: Financial data formatted with Iranian Rial.
- **Persian Number Conversion**: Western to Persian numeral conversion.

## Frontend Architecture
- **Framework**: React 18 with TypeScript, Vite.
- **State Management**: TanStack Query for server state, React Context for global state.
- **UI Components**: Radix UI primitives with shadcn/ui.
- **Styling**: Tailwind CSS with RTL optimization.
- **Routing**: Wouter.
- **Form Handling**: React Hook Form with Zod validation.
- **Charts**: Recharts.
- **Dev Server**: Runs on port 5000 with HMR configured for Replit proxy

## Backend Architecture
- **Server Framework**: Express.js with TypeScript.
- **API Design**: RESTful endpoints.
- **Session Management**: Express sessions with PostgreSQL storage.
- **File Handling**: Multer for file uploads.
- **Authentication**: bcrypt.js for hashing, session-based authentication.
- **Scheduled Tasks**: Hourly auto-alert scheduler.
- **Server Port**: Integrated with frontend on port 5000 (Vite dev server proxy)

## Database Architecture
- **Database**: PostgreSQL (Replit-managed).
- **ORM**: Drizzle ORM.
- **Schema Location**: `shared/schema.ts`.
- **Migration Strategy**: Drizzle Kit (`npm run db:push`).
- **Key Tables**: Comprehensive tables for users, projects, materials, tenders, alerts, messages, tasks, reports, etc.

## AI Assistant System
- **Primary AI**: Grok API (xAI) using grok-2-1212 for Persian responses.
- **API Key Required**: XAI_API_KEY environment variable (optional - system works without it).
- **Knowledge Base**: Preprocessed legal documents (شرایط عمومی پیمان).
- **Multi-Source Query**: Routes queries to database, legal documents, or general Grok API.
- **Response Caching**: 7-day cache for API responses.

## File Management
- **Storage**: Local filesystem in `uploads/` directory.
- **Cleanup Service**: Automated cleanup of temporary files (runs every 24 hours).

## Authentication & Authorization
- **Role-Based Access Control (RBAC)**: Granular permissions system.
- **Default Roles**: 
  - مدیر سیستم (System Admin)
  - مدیریت (Management)
  - مدیر پروژه (Project Manager)
  - دفتر فنی (Technical Office)
  - سرپرست (Supervisor)
  - بیننده (Viewer)
- **Default Admin Credentials**: username: `admin`, password: `admin123` (must change on first login)
- **User Management**: CRUD operations, password reset.
- **Session Security**: Server-side session management.

## Key Features Architecture
- **Project Management**: CRUD, progress tracking, project-specific material records.
- **Material Management (Bitumen)**: Project-scoped records, invoice tracking, supplier management, CSV export.
- **Progress Statements System**: Financial calculations, index-based adjustments, status workflow.
- **Tender Management**: Tracking, deadline monitoring, automated alerts, status workflow.
- **Alert System**: Multi-severity alerts, recipient assignment, comment threads, automated generation.
- **Internal Messaging**: Direct, group, project-specific conversations, file attachments, read/unread tracking.
- **Lab Sheets Management**: Multiple sheet types, file attachments, status workflow, advanced filtering.
- **Task Management**: User assignment, priority levels, reminders, file attachments.
- **Calendar System**: Jalali calendar, daily notes, task reminder badges.
- **Reporting**: Daily activity reports, execution progress reports with detailed logs.
- **Dashboard**: Real-time KPIs, open alerts, data analysis charts, project progress visualization.

## Project Structure
- `/client`: Frontend React application.
- `/server`: Backend Express application.
- `/shared`: Shared types and Drizzle schema.
- `/uploads`: User uploaded files (gitignored).
- `/attached_assets`: Static assets and images.

## Design System
- **Color Palette**: WCAG AA compliant vibrant colors.
- **Page-Specific Themes**: Distinct themes for sections.
- **Typography**: Vazirmatn (Persian), JetBrains Mono (numbers).
- **Components**: Consistent shadcn/ui components with RTL support.

# External Dependencies

## Core Infrastructure
- **Database**: PostgreSQL (Replit-managed).
- **AI Service**: Grok API (xAI) - requires XAI_API_KEY.

## Authentication & Security
- **Password Hashing**: bcryptjs.
- **Session Storage**: connect-pg-simple.

## File Processing
- **File Uploads**: multer.

## Frontend Libraries
- **UI Components**: Radix UI primitives.
- **Styling**: Tailwind CSS.
- **State Management**: TanStack Query.
- **Form Validation**: React Hook Form, Zod.
- **Date Handling**: date-fns-jalali, jalaali-js.
- **Charts**: recharts.
- **Icons**: lucide-react.

## Backend Libraries
- **ORM**: Drizzle ORM.
- **Database Driver**: @neondatabase/serverless, pg.
- **AI Integration**: openai package (for xAI endpoint).

## Development Tools
- **Build Tool**: Vite.
- **TypeScript**: Full stack support.
- **Dev Runner**: tsx for TypeScript execution.

# Environment Setup

## Required Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (automatically set by Replit)
- `PORT`: Server port (defaults to 5000)
- `NODE_ENV`: Environment mode (development/production)

## Optional Environment Variables
- `XAI_API_KEY`: API key for Grok AI assistant feature

## NPM Scripts
- `npm run dev`: Start development server
- `npm run build`: Build for production
- `npm start`: Run production server
- `npm run db:push`: Push database schema changes
- `npm run check`: TypeScript type checking

## First Time Setup
1. Database is already provisioned and schema is pushed
2. Default admin user created: username `admin`, password `admin123`
3. Six roles created with 34 permissions configured
4. Auto-alert system running (checks every 60 minutes)
5. File cleanup service running (every 24 hours)

## To Enable AI Assistant
The AI assistant feature requires the XAI_API_KEY to be set. Without it, the system will function but the AI assistant queries will not work.
