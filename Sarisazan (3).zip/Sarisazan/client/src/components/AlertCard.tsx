import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, Info, AlertTriangle, CheckCircle2 } from "lucide-react";

interface AlertCardProps {
  id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  project?: string;
  date: string;
  isRead: boolean;
  onMarkRead?: (id: string) => void;
}

const alertConfig = {
  info: {
    icon: Info,
    variant: "default" as const,
    bgClass: "bg-primary/10",
  },
  warning: {
    icon: AlertTriangle,
    variant: "outline" as const,
    bgClass: "bg-chart-2/10",
  },
  error: {
    icon: AlertCircle,
    variant: "destructive" as const,
    bgClass: "bg-destructive/10",
  },
  success: {
    icon: CheckCircle2,
    variant: "secondary" as const,
    bgClass: "bg-chart-3/10",
  },
};

export default function AlertCard({ id, title, message, type, project, date, isRead, onMarkRead }: AlertCardProps) {
  const config = alertConfig[type];
  const Icon = config.icon;

  return (
    <Card className={`hover-elevate ${!isRead ? 'border-r-4 border-r-primary' : ''}`}>
      <CardContent className="p-4">
        <div className="flex gap-3">
          <div className={`p-2 rounded-md h-fit ${config.bgClass}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h4 className="font-bold truncate" data-testid={`alert-title-${id}`}>{title}</h4>
              <Badge variant={config.variant} className="shrink-0">
                {type === "info" && "اطلاع"}
                {type === "warning" && "هشدار"}
                {type === "error" && "خطا"}
                {type === "success" && "موفق"}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-2">{message}</p>
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                {project && <span>پروژه: {project}</span>}
                <span>{date}</span>
              </div>
              {!isRead && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onMarkRead?.(id)}
                  data-testid={`button-mark-read-${id}`}
                >
                  علامت به عنوان خوانده شده
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
