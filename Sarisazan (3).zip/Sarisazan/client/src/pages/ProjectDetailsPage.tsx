import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowRight, Calendar, DollarSign, MapPin, Building2, FileText, TrendingUp, Upload, Download, Trash2, Plus } from "lucide-react";
import type { Project, ProjectFile } from "@shared/schema";
import { toPersianDigits } from "@/lib/persian-utils";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { format } from "date-fns-jalali";

const statusLabels: Record<string, string> = {
  active: "در حال اجرا",
  completed: "تکمیل شده",
  pending: "در انتظار",
  suspended: "متوقف شده",
};

const statusVariants: Record<string, "default" | "outline" | "destructive"> = {
  active: "default" as const,
  completed: "default" as const,
  pending: "outline" as const,
  suspended: "destructive" as const,
};

export default function ProjectDetailsPage() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [fileTitle, setFileTitle] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const project = projects.find((p) => p.id === id);

  const { data: projectFiles = [] } = useQuery<ProjectFile[]>({
    queryKey: [`/api/projects/${id}/files`],
    queryFn: async () => {
      const response = await fetch(`/api/projects/${id}/files`);
      if (!response.ok) throw new Error("خطا در دریافت فایل‌ها");
      return response.json();
    },
    enabled: !!id,
  });

  const uploadFileMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch(`/api/projects/${id}/files`, {
        method: "POST",
        body: formData,
      });
      if (!response.ok) throw new Error("خطا در آپلود فایل");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${id}/files`] });
      setUploadDialogOpen(false);
      setFileTitle("");
      setSelectedFile(null);
      toast({ title: "موفقیت", description: "فایل با موفقیت آپلود شد" });
    },
    onError: () => {
      toast({ variant: "destructive", title: "خطا", description: "آپلود فایل با خطا مواجه شد" });
    },
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const response = await fetch(`/api/projects/${id}/files/${fileId}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("خطا در حذف فایل");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${id}/files`] });
      toast({ title: "موفقیت", description: "فایل با موفقیت حذف شد" });
    },
    onError: () => {
      toast({ variant: "destructive", title: "خطا", description: "حذف فایل با خطا مواجه شد" });
    },
  });

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("title", fileTitle || selectedFile.name);
    formData.append("uploadedBy", "current-user-id");
    uploadFileMutation.mutate(formData);
  };

  const handleFileDelete = (fileId: string) => {
    if (confirm("آیا از حذف این فایل اطمینان دارید؟")) {
      deleteFileMutation.mutate(fileId);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-muted-foreground">در حال بارگذاری...</p>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <p className="text-muted-foreground">پروژه مورد نظر یافت نشد</p>
        <Button onClick={() => setLocation("/projects")}>
          <ArrowRight className="w-4 h-4 ml-2" />
          بازگشت به لیست پروژه‌ها
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-bold">{project.title}</h1>
            <Badge variant={statusVariants[project.status || "active"]}>
              {statusLabels[project.status || "active"]}
            </Badge>
          </div>
          <p className="text-muted-foreground">
            شماره قرارداد: {project.contractNumber || "نامشخص"}
          </p>
        </div>
        <Button variant="outline" onClick={() => setLocation("/projects")}>
          <ArrowRight className="w-4 h-4 ml-2" />
          بازگشت
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">پیشرفت پروژه</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(project.progress || 0)}%</div>
            <Progress value={project.progress || 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">مبلغ قرارداد</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {project.amount ? `${project.amount} ریال` : "نامشخص"}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">محل پروژه</CardTitle>
            <MapPin className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{project.location || "نامشخص"}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">تاریخ شروع</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {project.startDate ? toPersianDigits(project.startDate) : "نامشخص"}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="info" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="info">اطلاعات کلی</TabsTrigger>
          <TabsTrigger value="reports">گزارش‌ها</TabsTrigger>
          <TabsTrigger value="files">فایل‌ها و اسناد</TabsTrigger>
        </TabsList>

        <TabsContent value="info" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>جزئیات پروژه</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <Building2 className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">کارفرما</p>
                      <p className="text-sm text-muted-foreground">
                        {project.employer || "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <FileText className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">شماره قرارداد</p>
                      <p className="text-sm text-muted-foreground">
                        {project.contractNumber || "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">محل اجرا</p>
                      <p className="text-sm text-muted-foreground">
                        {project.location || "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <Calendar className="w-5 h-5 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">تاریخ شروع</p>
                      <p className="text-sm text-muted-foreground">
                        {project.startDate ? toPersianDigits(project.startDate) : "نامشخص"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-3">پیشرفت پروژه</h3>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>پیشرفت ریالی</span>
                    <span className="font-medium">{toPersianDigits(project.progress || 0)}%</span>
                  </div>
                  <Progress value={project.progress || 0} className="h-3" />
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-3">اطلاعات مالی</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">مبلغ کل قرارداد</p>
                    <p className="text-lg font-bold">
                      {project.amount ? `${project.amount} ریال` : "نامشخص"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">وضعیت</p>
                    <Badge variant={statusVariants[project.status || "active"]} className="mt-1">
                      {statusLabels[project.status || "active"]}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>گزارش‌های پروژه</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center py-8">
                گزارشی برای این پروژه ثبت نشده است
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="files" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>فایل‌ها و اسناد</CardTitle>
              <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="w-4 h-4 ml-2" />
                    آپلود فایل
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>آپلود فایل جدید</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleFileUpload} className="space-y-4">
                    <div>
                      <Label htmlFor="fileTitle">عنوان فایل</Label>
                      <Input
                        id="fileTitle"
                        value={fileTitle}
                        onChange={(e) => setFileTitle(e.target.value)}
                        placeholder="عنوان فایل (اختیاری)"
                      />
                    </div>
                    <div>
                      <Label htmlFor="file">انتخاب فایل</Label>
                      <Input
                        id="file"
                        type="file"
                        onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                        required
                      />
                    </div>
                    <Button type="submit" disabled={!selectedFile || uploadFileMutation.isPending}>
                      <Upload className="w-4 h-4 ml-2" />
                      {uploadFileMutation.isPending ? "در حال آپلود..." : "آپلود"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {projectFiles.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  فایلی برای این پروژه آپلود نشده است
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">عنوان</TableHead>
                      <TableHead className="text-right">نام فایل</TableHead>
                      <TableHead className="text-right">حجم</TableHead>
                      <TableHead className="text-right">تاریخ</TableHead>
                      <TableHead className="text-right">عملیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projectFiles.map((file) => (
                      <TableRow key={file.id}>
                        <TableCell className="font-medium">{file.title}</TableCell>
                        <TableCell>{file.fileName}</TableCell>
                        <TableCell>
                          {file.fileSize ? `${Math.round(file.fileSize / 1024)} KB` : "-"}
                        </TableCell>
                        <TableCell>
                          {file.uploadedAt
                            ? format(new Date(file.uploadedAt), "yyyy/MM/dd HH:mm")
                            : "-"}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              asChild
                            >
                              <a href={file.filePath} download>
                                <Download className="w-4 h-4" />
                              </a>
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleFileDelete(file.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
