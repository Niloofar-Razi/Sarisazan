import { db } from "./db";
import { projects, statements, adjustments, bitumenDiffs } from "@shared/schema";

async function importRemainingProjects() {
  console.log('🚀 شروع import پروژه‌های باقیمانده...');

  // پروژه ۸: بهسازی، لکه‌گیری و روکش آسفالت محور قزوین-تاکستان-آوج
  const project8 = await db.insert(projects).values({
    projectNumber: '8',
    title: 'بهسازی، لکه‌گیری و روکش آسفالت محور قزوین-تاکستان-آوج',
    contractNumber: '15/45150',
    contractDate: '1401/09/29',
    amount: '507893878620',
    amount25Percent: '-',
    employer: 'اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین',
    contractor: 'سریع سازان البرز',
    progress: 105,
    status: 'تکمیل شده',
    startDate: '1401/10/01',
  }).returning();
  
  console.log(`✅ پروژه ${project8[0].title.substring(0, 40)}... ثبت شد`);

  // صورت وضعیت‌های پروژه 8 (9 عدد)
  await db.insert(statements).values([
    { projectId: project8[0].id, number: '1', amount: '43018476101', status: 'تایید شده', startDate: '1401/10/01', endDate: '1401/10/06' },
    { projectId: project8[0].id, number: '2', amount: '69950276358', status: 'تایید شده', startDate: '1401/10/07', endDate: '1401/10/13' },
    { projectId: project8[0].id, number: '3', amount: '115642745534', status: 'تایید شده', startDate: '1401/10/14', endDate: '1401/10/20' },
    { projectId: project8[0].id, number: '4', amount: '177912045131', status: 'تایید شده', startDate: '1401/10/21', endDate: '1401/10/27' },
    { projectId: project8[0].id, number: '5', amount: '256539104936', status: 'تایید شده', startDate: '1401/10/28', endDate: '1401/11/02' },
    { projectId: project8[0].id, number: '6', amount: '256539104937', status: 'تایید شده', startDate: '1401/11/03', endDate: '1401/11/08' },
    { projectId: project8[0].id, number: '7', amount: '353062570296', status: 'تایید شده', startDate: '1401/11/09', endDate: '1401/11/15' },
    { projectId: project8[0].id, number: '8', amount: '450787208418', status: 'تایید شده', startDate: '1401/11/16', endDate: '1401/11/22' },
    { projectId: project8[0].id, number: '9', amount: '534973823027', status: 'تایید شده', startDate: '1401/11/23', endDate: '1401/11/27' },
  ]);
  console.log('  ✅ 9 صورت وضعیت ثبت شد');

  // تعدیل‌های پروژه 8 (6 عدد)
  await db.insert(adjustments).values([
    { projectId: project8[0].id, number: '1', amount: '2229801551', status: 'تایید شده', startDate: '1401/10/01', endDate: '1401/10/06' },
    { projectId: project8[0].id, number: '2', amount: '5234569750', status: 'تایید شده', startDate: '1401/10/07', endDate: '1401/10/13' },
    { projectId: project8[0].id, number: '3', amount: '27858169240', status: 'تایید شده', startDate: '1401/10/14', endDate: '1401/10/20' },
    { projectId: project8[0].id, number: '4', amount: '35510698125', status: 'تایید شده', startDate: '1401/10/21', endDate: '1401/10/27' },
    { projectId: project8[0].id, number: '5', amount: '64282698328', status: 'تایید شده', startDate: '1401/10/28', endDate: '1401/11/02' },
    { projectId: project8[0].id, number: '6', amount: '85498763381', status: 'تایید شده', startDate: '1401/11/03', endDate: '1401/11/08' },
  ]);
  console.log('  ✅ 6 تعدیل ثبت شد');

  // مابه‌التفاوت قیر پروژه 8 (4 عدد)
  await db.insert(bitumenDiffs).values([
    { projectId: project8[0].id, number: '1', amount: '6085755434', status: 'تایید شده' },
    { projectId: project8[0].id, number: '2', amount: '33451644186', status: 'تایید شده' },
    { projectId: project8[0].id, number: '3', amount: '56453037015', status: 'تایید شده' },
    { projectId: project8[0].id, number: '4', amount: '-11580787846', status: 'تایید شده' },
  ]);
  console.log('  ✅ 4 مابه‌التفاوت قیر ثبت شد');

  // پروژه ۹: بهسازی و آسفالت محورهای بشر- دولت آباد و آبترش- نیکوئیه- ضیا آباد
  const project9 = await db.insert(projects).values({
    projectNumber: '9',
    title: 'بهسازی و آسفالت محورهای بشر- دولت آباد و آبترش- نیکوئیه- ضیا آباد',
    contractNumber: '15/45624',
    contractDate: '1401/10/01',
    amount: '424604739521',
    employer: 'اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین',
    contractor: 'بهینه مطبوع کاوش کار',
    progress: 90,
    status: 'در حال اجرا',
    startDate: '1401/10/01',
  }).returning();
  
  console.log(`✅ پروژه ${project9[0].title.substring(0, 40)}... ثبت شد`);

  // صورت وضعیت‌های پروژه 9 (7 عدد)
  await db.insert(statements).values([
    { projectId: project9[0].id, number: '1', amount: '97292017090', status: 'تایید شده', startDate: '1401/10/01', endDate: '1401/10/05' },
    { projectId: project9[0].id, number: '2', amount: '118053758068', status: 'تایید شده', startDate: '1401/10/06', endDate: '1401/10/12' },
    { projectId: project9[0].id, number: '3', amount: '111182408628', status: 'تایید شده', startDate: '1401/10/13', endDate: '1401/10/19' },
    { projectId: project9[0].id, number: '4', amount: '111741280402', status: 'تایید شده', startDate: '1401/10/20', endDate: '1401/10/26' },
    { projectId: project9[0].id, number: '5', amount: '160174424837', status: 'تایید شده', startDate: '1401/10/27', endDate: '1401/11/02' },
    { projectId: project9[0].id, number: '3', amount: '232287345234', status: 'اصلاح شده، تایید شده', startDate: '1401/11/03', endDate: '1401/11/09' },
    { projectId: project9[0].id, number: '4', amount: '380953267905', status: 'تایید شده', startDate: '1401/11/10', endDate: '1401/11/15' },
  ]);
  console.log('  ✅ 7 صورت وضعیت ثبت شد');

  // تعدیل‌های پروژه 9 (5 عدد)
  await db.insert(adjustments).values([
    { projectId: project9[0].id, number: '1', amount: '3859092000', status: 'تایید شده', startDate: '1401/10/28', endDate: '1401/11/05' },
    { projectId: project9[0].id, number: '2', amount: '23994473524', status: 'تایید شده', startDate: '1401/10/29', endDate: '1401/11/06' },
    { projectId: project9[0].id, number: '3', amount: '69861488667', status: 'تایید شده', startDate: '1401/10/30', endDate: '1401/11/07' },
    { projectId: project9[0].id, number: '4', amount: '35510698125', status: 'تایید شده', startDate: '1401/10/31', endDate: '1401/11/08' },
    { projectId: project9[0].id, number: '5', amount: '64282698328', status: 'تایید شده', startDate: '1401/11/01', endDate: '1401/11/09' },
  ]);
  console.log('  ✅ 5 تعدیل ثبت شد');

  // مابه‌التفاوت قیر پروژه 9 (2 عدد)
  await db.insert(bitumenDiffs).values([
    { projectId: project9[0].id, number: '1', amount: '46225815122', status: 'تایید شده' },
    { projectId: project9[0].id, number: '2', amount: '-2699695662', status: 'تایید شده' },
  ]);
  console.log('  ✅ 2 مابه‌التفاوت قیر ثبت شد');

  // پروژه ۲۸۰۱۶: بهسازی محور اک- شامی شاپ و ساماندهی ورودی روستای اک و احداث زیرگذر قرقسین
  const project28016 = await db.insert(projects).values({
    projectNumber: '28016',
    title: 'بهسازی محور اک- شامی شاپ و ساماندهی ورودی روستای اک و احداث زیرگذر قرقسین',
    contractNumber: '15/45624',
    contractDate: '1401/08/08',
    amount: '679153092242',
    employer: 'اداره کل راه و شهرسازی استان قزوین',
    contractor: 'سریع سازان البرز',
    progress: 63,
    status: 'در حال اجرا',
    startDate: '1401/08/08',
  }).returning();
  
  console.log(`✅ پروژه ${project28016[0].title.substring(0, 40)}... ثبت شد`);

  // صورت وضعیت‌های پروژه 28016 (22 عدد - فقط مبالغ موجود)
  await db.insert(statements).values([
    { projectId: project28016[0].id, number: '1', amount: '13339200724', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '2', amount: '20652226918', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '3', amount: '107143767913', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '4', amount: '111752242358', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '5', amount: '119632267142', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '6', amount: '125593440695', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '7', amount: '135732550142', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '8', amount: '150757565709', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '9', amount: '161882729458', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '10', amount: '184386923722', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '11', amount: '191895734861', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '12', amount: '207576878732', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '13', amount: '214229263592', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '14', amount: '217356073679', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '15', amount: '230576669373', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '16', amount: '249134838134', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '17', amount: '274064251896', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '18', amount: '294177353702', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '19', amount: '330476969564', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '20', amount: '349933098372', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '21', amount: '390258453948', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '22', amount: '430321719419', status: 'تایید شده' },
  ]);
  console.log('  ✅ 22 صورت وضعیت ثبت شد');

  // مابه‌التفاوت قیر پروژه 28016 (2 عدد - منفی)
  await db.insert(bitumenDiffs).values([
    { projectId: project28016[0].id, number: '1', amount: '-9367382563', status: 'تایید شده' },
    { projectId: project28016[0].id, number: '2', amount: '-23090938585', status: 'تایید شده' },
  ]);
  console.log('  ✅ 2 مابه‌التفاوت قیر ثبت شد');

  console.log('\n✨ همه پروژه‌های باقیمانده با موفقیت import شدند!');
  console.log(`📊 مجموع: 3 پروژه، ${9+7+22} صورت وضعیت، ${6+5} تعدیل، ${4+2+2} مابه‌التفاوت قیر`);
}

// اجرای اسکریپت
importRemainingProjects()
  .then(() => {
    console.log('✅ عملیات با موفقیت انجام شد');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ خطا در import:', error);
    process.exit(1);
  });
