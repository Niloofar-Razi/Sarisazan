import { db } from "./db";
import { projects } from "@shared/schema";

const sampleProjects = [
  {
    title: "احداث راه دسترسی تپه باستانی سگزآباد و تکمیل راه روستایی بندسر- مرادبیگلو و احداث راه دسترسی گلخانه نودهک",
    contractNumber: "15/3598",
    contractDate: "1400/02/04",
    amount: "61,329,030,181",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 58,
    status: "active"
  },
  {
    title: "زیرسازی و آسفالت راه های روستایی شهرستان بوئین زهرا",
    contractNumber: "15/4540",
    contractDate: "1401/02/08",
    amount: "323,713,724,955",
    contractor: "بهینه مطبوع کاوش کار",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 77,
    status: "active"
  },
  {
    title: "لکه گیری و بهسازی محورهای شهرستان های قزوین، تاکستان، آوج و محور دانسفهان، شامی شاب و ابهر",
    contractNumber: "15/26928",
    contractDate: "1400/06/30",
    amount: "298,967,787,901",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 105,
    status: "completed"
  },
  {
    title: "خرید آسفالت سرد و گرم پای کارخانه",
    contractNumber: "15/19872",
    contractDate: "1401/05/08",
    amount: "92,746,168,226",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 31,
    status: "active"
  },
  {
    title: "بهسازی لکه گیری و روکش آسفالت محور قدیم قزوین-رشت",
    contractNumber: "15/45025",
    contractDate: "1401/09/28",
    amount: "1,005,031,507,635",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 105,
    status: "completed"
  },
  {
    title: "بهسازی، لکه گیری و روکش آسفالت محور قزوین- تاکستان- آوج",
    contractNumber: "15/45150",
    contractDate: "1401/09/29",
    amount: "507,893,878,620",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 105,
    status: "completed"
  },
  {
    title: "بهسازی و آسفالت محورهای بشر- دولت آباد و آبترش- نیکوئیه- ضیا آباد",
    contractNumber: "15/45624",
    contractDate: "1401/10/01",
    amount: "424,604,739,521",
    contractor: "بهینه مطبوع کاوش کار",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 89,
    status: "active"
  },
  {
    title: "بهسازی محور اک- شامی شاپ و ساماندهی ورودی روستای اک و احداث زیرگذر قرقسین",
    contractNumber: "28016",
    contractDate: "1401/08/08",
    amount: "679,153,092,242",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راه و شهرسازی استان قزوین",
    progress: 63,
    status: "active"
  },
  {
    title: "بهسازی و روکش آسفالت راه های روستایی شهرستان تاکستان",
    contractNumber: "15/3138",
    contractDate: "1402/01/28",
    amount: "679,214,976,465",
    contractor: "خاک پی دنا",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 49,
    status: "active"
  },
  {
    title: "زیرسازی، مخلوط ریزی، روکش آسفالت، سنگ فرش و اجرای جدول روستای اک",
    contractNumber: "60/د/402",
    contractDate: "1402/06/14",
    amount: "193,416,610,732",
    contractor: "خاک پی دنا",
    employer: "دهیاری اک",
    progress: 49,
    status: "active"
  },
  {
    title: "بهسازی روکش آسفالت آزادراه قزوین کرج و کنارگذر قزوین زنجان",
    contractNumber: "15/9457",
    contractDate: "1403/03/01",
    amount: "447,397,767,841",
    contractor: "بهینه مطبوع کاوش کار",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 62,
    status: "active"
  },
  {
    title: "اجرای فونداسیون سردخانه پلاسمای قزوین",
    contractNumber: "12705",
    contractDate: "1403/04/06",
    amount: "32,150,564,546",
    contractor: "سریع سازان البرز",
    employer: "اداره کل راه و شهرسازی استان قزوین",
    progress: 91,
    status: "active"
  },
  {
    title: "بهسازی و آسفالت محور دانسفهان - چهارراه سعیدآباد",
    contractNumber: "15/10859",
    contractDate: "1404/03/04",
    amount: "192,344,208,380",
    contractor: "بهینه مطبوع کاوش کار",
    employer: "اداره کل راهداری و حمل و نقل جاده ای استان قزوین",
    progress: 56,
    status: "active"
  }
];

async function seedProjects() {
  try {
    console.log("🌱 شروع وارد کردن پروژه‌های نمونه...");
    
    const existingProjects = await db.select().from(projects);
    
    if (existingProjects.length > 0) {
      console.log(`⚠️  ${existingProjects.length} پروژه قبلاً وجود دارد.`);
      console.log("⏭️  اسکریپت از اضافه شدن مجدد پروژه‌ها جلوگیری می‌کند.");
      console.log("ℹ️  اگر می‌خواهید پروژه‌های جدید اضافه کنید، ابتدا پروژه‌های موجود را حذف کنید.");
      
      process.exit(0);
    }

    const insertedProjects = await db.insert(projects).values(sampleProjects).returning();
    
    console.log(`✅ ${insertedProjects.length} پروژه نمونه با موفقیت اضافه شد!`);
    console.log("\nلیست پروژه‌های اضافه شده:");
    insertedProjects.forEach((p, i) => {
      console.log(`${i + 1}. ${p.title?.substring(0, 50)}... (پیشرفت: ${p.progress}%)`);
    });
    
    process.exit(0);
  } catch (error) {
    console.error("❌ خطا در وارد کردن پروژه‌ها:", error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  seedProjects();
}
