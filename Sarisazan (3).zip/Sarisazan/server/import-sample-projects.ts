import { db } from "./db";
import { projects, statements, adjustments, bitumenDiffs } from "@shared/schema";

async function importSampleProjects() {
  console.log("🚀 شروع وارد کردن پروژه‌های نمونه...");

  try {
    // پروژه ۲: احداث راه دسترسی تپه باستانی سگزآباد
    console.log("\n📁 پروژه ۲: احداث راه دسترسی تپه باستانی سگزآباد...");
    const [project2] = await db.insert(projects).values({
      title: "احداث راه دسترسی تپه باستانی سگزآباد و تکمیل راه روستایی بندسر- مرادبیگلو و احداث راه دسترسی گلخانه نودهک",
      contractNumber: "15/3598",
      contractDate: "1400/02/04",
      amount: "61329030181",
      employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
      contractor: "سریع سازان البرز",
      progress: 58,
      status: "active",
      startDate: "1400/02/05",
    }).returning();

    // صورت وضعیت‌های پروژه ۲
    await db.insert(statements).values([
      {
        projectId: project2.id,
        number: "1",
        amount: "16702524489",
        status: "موقت",
        startDate: "1400/02/05",
        endDate: "1400/03/01",
      },
      {
        projectId: project2.id,
        number: "2",
        amount: "35902628577",
        status: "موقت",
        startDate: "1401/02/02",
        endDate: "1401/06/08",
      },
    ]);

    // تعدیل‌های پروژه ۲
    await db.insert(adjustments).values([
      {
        projectId: project2.id,
        number: "1",
        amount: "5845405608",
        status: "موقت",
      },
      {
        projectId: project2.id,
        number: "2",
        amount: "14948065358",
        status: "موقت",
      },
    ]);

    console.log("✅ پروژه ۲ با موفقیت وارد شد");

    // پروژه ۳: زیرسازی و آسفالت راه‌های روستایی شهرستان بوئین زهرا
    console.log("\n📁 پروژه ۳: زیرسازی و آسفالت راه‌های روستایی...");
    const [project3] = await db.insert(projects).values({
      title: "زیرسازی و آسفالت راه‌های روستایی شهرستان بوئین زهرا",
      contractNumber: "15/4540",
      contractDate: "1401/02/08",
      amount: "323713724955",
      employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
      contractor: "بهینه مطبوع کاوش کار",
      progress: 77,
      status: "active",
      startDate: "1400/02/15",
    }).returning();

    // صورت وضعیت‌های پروژه ۳
    await db.insert(statements).values([
      {
        projectId: project3.id,
        number: "1",
        amount: "74585477094",
        status: "تایید شده",
        startDate: "1400/02/15",
        endDate: "1400/03/15",
      },
      {
        projectId: project3.id,
        number: "2",
        amount: "102439212502",
        status: "تایید شده",
        startDate: "1400/04/15",
        endDate: "1400/05/15",
      },
      {
        projectId: project3.id,
        number: "3",
        amount: "145879737001",
        status: "تایید شده",
        startDate: "1400/05/15",
        endDate: "1400/06/15",
      },
      {
        projectId: project3.id,
        number: "4",
        amount: "171717171085",
        status: "تایید شده",
        startDate: "1400/06/15",
        endDate: "1400/07/15",
      },
      {
        projectId: project3.id,
        number: "5",
        amount: "211932993441",
        status: "تایید شده",
        startDate: "1400/07/15",
        endDate: "1400/08/15",
      },
      {
        projectId: project3.id,
        number: "6",
        amount: "251171146885",
        status: "تایید شده",
        startDate: "1400/09/15",
        endDate: "1400/10/15",
      },
    ]);

    // تعدیل‌های پروژه ۳
    await db.insert(adjustments).values([
      {
        projectId: project3.id,
        number: "1",
        amount: "5590411481",
        status: "تایید شده",
      },
      {
        projectId: project3.id,
        number: "2",
        amount: "24740494716",
        status: "تایید شده",
      },
      {
        projectId: project3.id,
        number: "3",
        amount: "0",
        status: "تایید شده",
      },
      {
        projectId: project3.id,
        number: "4",
        amount: "0",
        status: "تایید شده",
      },
      {
        projectId: project3.id,
        number: "5",
        amount: "0",
        status: "تایید شده",
      },
      {
        projectId: project3.id,
        number: "6",
        amount: "0",
        status: "تایید شده",
      },
    ]);

    console.log("✅ پروژه ۳ با موفقیت وارد شد");

    // پروژه ۴: لکه‌گیری و بهسازی محورهای شهرستان‌های قزوین
    console.log("\n📁 پروژه ۴: لکه‌گیری و بهسازی محورهای شهرستان‌های قزوین...");
    const [project4] = await db.insert(projects).values({
      title: "لکه‌گیری و بهسازی محورهای شهرستان‌های قزوین، تاکستان، آوج و محور دانسفهان، شامی شاب و ابهر",
      contractNumber: "15/26928",
      contractDate: "1400/06/30",
      amount: "239174230321",
      employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
      contractor: "سریع سازان البرز",
      progress: 105,
      status: "active",
      startDate: "1400/07/06",
    }).returning();

    // صورت وضعیت‌های پروژه ۴
    await db.insert(statements).values([
      {
        projectId: project4.id,
        number: "1",
        amount: "19209508711",
        status: "تایید شده",
        startDate: "1400/07/06",
        endDate: "1400/08/06",
      },
      {
        projectId: project4.id,
        number: "2",
        amount: "25627930891",
        status: "تایید شده",
        startDate: "1400/10/01",
        endDate: "1400/10/31",
      },
      {
        projectId: project4.id,
        number: "3",
        amount: "31833704201",
        status: "تایید شده",
        startDate: "1400/12/01",
        endDate: "1400/12/31",
      },
      {
        projectId: project4.id,
        number: "4",
        amount: "96663172641",
        status: "تایید شده",
        startDate: "1401/02/01",
        endDate: "1401/02/31",
      },
      {
        projectId: project4.id,
        number: "5",
        amount: "215757774620",
        status: "تایید شده",
        startDate: "1401/04/01",
        endDate: "1401/04/31",
      },
      {
        projectId: project4.id,
        number: "6",
        amount: "252909399598",
        status: "تایید شده",
        startDate: "1401/06/01",
        endDate: "1401/06/15",
      },
    ]);

    // تعدیل‌های پروژه ۴
    await db.insert(adjustments).values([
      {
        projectId: project4.id,
        number: "1",
        amount: "1508942360",
        status: "تایید شده",
      },
      {
        projectId: project4.id,
        number: "2",
        amount: "6203567987",
        status: "تایید شده",
      },
      {
        projectId: project4.id,
        number: "3",
        amount: "38579851972",
        status: "تایید شده",
      },
      {
        projectId: project4.id,
        number: "4",
        amount: "40477442822",
        status: "تایید شده",
      },
      {
        projectId: project4.id,
        number: "5",
        amount: "0",
        status: "تایید شده",
      },
      {
        projectId: project4.id,
        number: "6",
        amount: "0",
        status: "تایید شده",
      },
    ]);

    // مابه‌التفاوت قیر پروژه ۴
    await db.insert(bitumenDiffs).values([
      {
        projectId: project4.id,
        number: "1",
        amount: "2657792773",
        status: "تایید شده",
      },
      {
        projectId: project4.id,
        number: "2",
        amount: "45143019527",
        status: "تایید شده",
      },
    ]);

    console.log("✅ پروژه ۴ با موفقیت وارد شد");

    console.log("\n🎉 تمام پروژه‌های نمونه با موفقیت وارد شدند!");
    console.log("📊 آمار:");
    console.log("   - تعداد پروژه‌ها: 3");
    console.log("   - تعداد صورت وضعیت‌ها: 14");
    console.log("   - تعداد تعدیل‌ها: 14");
    console.log("   - تعداد مابه‌التفاوت قیر: 2");

  } catch (error) {
    console.error("❌ خطا در وارد کردن پروژه‌های نمونه:", error);
    throw error;
  }
}

// اگر مستقیماً اجرا شود
if (import.meta.url === `file://${process.argv[1]}`) {
  importSampleProjects()
    .then(() => {
      console.log("✅ عملیات با موفقیت انجام شد");
      process.exit(0);
    })
    .catch((error) => {
      console.error("❌ عملیات با خطا مواجه شد:", error);
      process.exit(1);
    });
}

export { importSampleProjects };
