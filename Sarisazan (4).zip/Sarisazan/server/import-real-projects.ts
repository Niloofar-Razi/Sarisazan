import { db } from "./db";
import { projects, statements, adjustments, bitumenDiffs } from "@shared/schema";
import fs from "fs";
import path from "path";

// فانکشن تبدیل عدد فارسی به انگلیسی
function convertPersianToEnglish(num: string): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  
  let result = num;
  for (let i = 0; i < 10; i++) {
    result = result.replace(new RegExp(persianDigits[i], 'g'), englishDigits[i]);
  }
  return result;
}

// فانکشن پاک‌سازی مبالغ (حذف کاما و تبدیل به عدد)
function parseAmount(amount: string): string {
  if (!amount || amount === '-') return '0';
  const cleaned = convertPersianToEnglish(amount)
    .replace(/,/g, '')
    .replace(/\s/g, '')
    .replace(/ریال/g, '')
    .trim();
  return cleaned || '0';
}

async function importProjects() {
  console.log('🚀 شروع import اطلاعات پروژه‌ها...');

  // پروژه ۲: احداث راه دسترسی تپه باستانی سگزآباد
  const project2 = await db.insert(projects).values({
    projectNumber: '2',
    title: 'احداث راه دسترسی تپه باستانی سگزآباد و تکمیل راه روستایی بندسر- مرادبیگلو و احداث راه دسترسی گلخانه نودهک',
    contractNumber: '15/3598',
    contractDate: '1400/02/04',
    amount: '61329030181',
    amount25Percent: '-',
    employer: 'اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین',
    contractor: 'سریع سازان البرز',
    progress: 58,
    status: 'در حال اجرا',
    startDate: '1400/02/05',
  }).returning();
  
  console.log(`✅ پروژه ${project2[0].title.substring(0, 40)}... ثبت شد`);

  // صورت وضعیت‌های پروژه 2
  await db.insert(statements).values([
    {
      projectId: project2[0].id,
      number: '1',
      amount: '16702524489',
      status: 'موقت',
      startDate: '1400/02/05',
      endDate: '1400/03/01',
    },
    {
      projectId: project2[0].id,
      number: '2',
      amount: '35902628577',
      status: 'موقت',
      startDate: '1401/02/02',
      endDate: '1401/06/08',
    },
  ]);
  console.log('  ✅ 2 صورت وضعیت ثبت شد');

  // تعدیل‌های پروژه 2
  await db.insert(adjustments).values([
    {
      projectId: project2[0].id,
      number: '1',
      amount: '5845405608',
      status: 'موقت',
      startDate: '1400/02/05',
      endDate: '1400/03/01',
    },
    {
      projectId: project2[0].id,
      number: '2',
      amount: '14948065358',
      status: 'موقت',
      startDate: '1401/02/02',
      endDate: '1401/06/08',
    },
  ]);
  console.log('  ✅ 2 تعدیل ثبت شد');

  // پروژه ۳: زیرسازی و آسفالت راه‌های روستایی شهرستان بوئین زهرا
  const project3 = await db.insert(projects).values({
    projectNumber: '3',
    title: 'زیرسازی و آسفالت راه‌های روستایی شهرستان بوئین زهرا',
    contractNumber: '15/4540',
    contractDate: '1401/02/08',
    amount: '323713724955',
    amount25Percent: '-',
    employer: 'اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین',
    contractor: 'بهینه مطبوع کاوش کار',
    progress: 78,
    status: 'در حال اجرا',
    startDate: '1400/02/15',
  }).returning();
  
  console.log(`✅ پروژه ${project3[0].title.substring(0, 40)}... ثبت شد`);

  // صورت وضعیت‌های پروژه 3
  await db.insert(statements).values([
    { projectId: project3[0].id, number: '1', amount: '74585477094', status: 'تایید شده', startDate: '1400/02/15', endDate: '1400/03/15' },
    { projectId: project3[0].id, number: '2', amount: '102439212502', status: 'تایید شده', startDate: '1400/04/15', endDate: '1400/05/15' },
    { projectId: project3[0].id, number: '3', amount: '145879737001', status: 'تایید شده', startDate: '1400/05/15', endDate: '1400/06/15' },
    { projectId: project3[0].id, number: '4', amount: '171717171085', status: 'تایید شده', startDate: '1400/06/15', endDate: '1400/07/15' },
    { projectId: project3[0].id, number: '5', amount: '211932993441', status: 'تایید شده', startDate: '1400/07/15', endDate: '1400/08/15' },
    { projectId: project3[0].id, number: '6', amount: '251171146885', status: 'تایید شده', startDate: '1400/09/15', endDate: '1400/10/15' },
  ]);
  console.log('  ✅ 6 صورت وضعیت ثبت شد');

  // تعدیل‌های پروژه 3
  await db.insert(adjustments).values([
    { projectId: project3[0].id, number: '1', amount: '5590411481', status: 'تایید شده', startDate: '1400/02/15', endDate: '1400/03/15' },
    { projectId: project3[0].id, number: '2', amount: '24740494716', status: 'تایید شده', startDate: '1400/04/15', endDate: '1400/05/15' },
    { projectId: project3[0].id, number: '3', amount: '0', status: 'تایید شده', startDate: '1400/05/15', endDate: '1400/06/15' },
    { projectId: project3[0].id, number: '4', amount: '0', status: 'تایید شده', startDate: '1400/06/15', endDate: '1400/07/15' },
    { projectId: project3[0].id, number: '5', amount: '0', status: 'تایید شده', startDate: '1400/07/15', endDate: '1400/08/15' },
    { projectId: project3[0].id, number: '6', amount: '0', status: 'تایید شده', startDate: '1400/09/15', endDate: '1400/10/15' },
  ]);
  console.log('  ✅ 6 تعدیل ثبت شد');

  // پروژه ۴: لکه‌گیری و بهسازی محورها
  const project4 = await db.insert(projects).values({
    projectNumber: '4',
    title: 'لکه‌گیری و بهسازی محورهای شهرستان‌های قزوین، تاکستان، آوج و محور دانسفهان، شامی شاب و ابهر',
    contractNumber: '15/26928',
    contractDate: '1400/06/30',
    amount: '239174230321',
    amount25Percent: '298967787901',
    employer: 'اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین',
    contractor: 'سریع سازان البرز',
    progress: 106,
    status: 'تکمیل شده',
    startDate: '1400/07/06',
  }).returning();
  
  console.log(`✅ پروژه ${project4[0].title.substring(0, 40)}... ثبت شد`);

  // صورت وضعیت‌های پروژه 4
  await db.insert(statements).values([
    { projectId: project4[0].id, number: '1', amount: '19209508711', status: 'تایید شده', startDate: '1400/07/06', endDate: '1400/08/06' },
    { projectId: project4[0].id, number: '2', amount: '25627930891', status: 'تایید شده', startDate: '1400/10/01', endDate: '1400/10/31' },
    { projectId: project4[0].id, number: '3', amount: '31833704201', status: 'تایید شده', startDate: '1400/12/01', endDate: '1400/12/31' },
    { projectId: project4[0].id, number: '4', amount: '96663172641', status: 'تایید شده', startDate: '1401/02/01', endDate: '1401/02/31' },
    { projectId: project4[0].id, number: '5', amount: '215757774620', status: 'تایید شده', startDate: '1401/04/01', endDate: '1401/04/31' },
    { projectId: project4[0].id, number: '6', amount: '252909399598', status: 'تایید شده', startDate: '1401/06/01', endDate: '1401/06/15' },
  ]);
  console.log('  ✅ 6 صورت وضعیت ثبت شد');

  // تعدیل‌های پروژه 4
  await db.insert(adjustments).values([
    { projectId: project4[0].id, number: '1', amount: '1508942360', status: 'تایید شده', startDate: '1400/07/06', endDate: '1400/08/06' },
    { projectId: project4[0].id, number: '2', amount: '6203567987', status: 'تایید شده', startDate: '1400/10/01', endDate: '1400/10/31' },
    { projectId: project4[0].id, number: '3', amount: '38579851972', status: 'تایید شده', startDate: '1400/12/01', endDate: '1400/12/31' },
    { projectId: project4[0].id, number: '4', amount: '40477442822', status: 'تایید شده', startDate: '1401/02/01', endDate: '1401/02/31' },
    { projectId: project4[0].id, number: '5', amount: '0', status: 'تایید شده', startDate: '1401/04/01', endDate: '1401/04/31' },
    { projectId: project4[0].id, number: '6', amount: '0', status: 'تایید شده', startDate: '1401/06/01', endDate: '1401/06/15' },
  ]);
  console.log('  ✅ 6 تعدیل ثبت شد');

  // مابه‌التفاوت قیر پروژه 4
  await db.insert(bitumenDiffs).values([
    { projectId: project4[0].id, number: '1', amount: '2657792773', status: 'تایید شده' },
    { projectId: project4[0].id, number: '2', amount: '45143019527', status: 'تایید شده' },
  ]);
  console.log('  ✅ 2 مابه‌التفاوت قیر ثبت شد');

  // پروژه ۷: بهسازی لکه‌گیری و روکش آسفالت محور قدیم قزوین-رشت
  const project7 = await db.insert(projects).values({
    projectNumber: '7',
    title: 'بهسازی لکه‌گیری و روکش آسفالت محور قدیم قزوین-رشت',
    contractNumber: '15/45025',
    contractDate: '1401/09/28',
    amount: '1005031507635',
    amount25Percent: '-',
    employer: 'اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین',
    contractor: 'سریع سازان البرز',
    progress: 105,
    status: 'تکمیل شده',
    startDate: '1400/07/06',
  }).returning();
  
  console.log(`✅ پروژه ${project7[0].title.substring(0, 40)}... ثبت شد`);

  // صورت وضعیت‌های پروژه 7 (10 عدد)
  await db.insert(statements).values([
    { projectId: project7[0].id, number: '1', amount: '41960171926', status: 'تایید شده', startDate: '1400/07/06', endDate: '1400/07/29' },
    { projectId: project7[0].id, number: '2', amount: '113657809510', status: 'تایید شده', startDate: '1400/07/01', endDate: '1400/07/21' },
    { projectId: project7[0].id, number: '3', amount: '155003854906', status: 'تایید شده', startDate: '1400/09/01', endDate: '1400/09/22' },
    { projectId: project7[0].id, number: '4', amount: '274755005871', status: 'تایید شده', startDate: '1400/11/25', endDate: '1400/12/15' },
    { projectId: project7[0].id, number: '5', amount: '520820981064', status: 'تایید شده', startDate: '1401/02/25', endDate: '1401/03/15' },
    { projectId: project7[0].id, number: '6', amount: '541116350007', status: 'تایید شده', startDate: '1401/05/15', endDate: '1401/06/15' },
    { projectId: project7[0].id, number: '7', amount: '673227151509', status: 'تایید شده', startDate: '1401/07/05', endDate: '1401/07/25' },
    { projectId: project7[0].id, number: '8', amount: '901919059846', status: 'تایید شده', startDate: '1401/10/05', endDate: '1401/10/25' },
    { projectId: project7[0].id, number: '9', amount: '954742821347', status: 'تایید شده', startDate: '1401/12/05', endDate: '1401/12/25' },
    { projectId: project7[0].id, number: '10', amount: '1058471906750', status: 'تایید شده', startDate: '1402/02/05', endDate: '1402/02/20' },
  ]);
  console.log('  ✅ 10 صورت وضعیت ثبت شد');

  // تعدیل‌های پروژه 7
  await db.insert(adjustments).values([
    { projectId: project7[0].id, number: '1', amount: '3035438773', status: 'تایید شده', startDate: '1400/07/06', endDate: '1400/07/29' },
    { projectId: project7[0].id, number: '2', amount: '7842501408', status: 'تایید شده', startDate: '1400/08/01', endDate: '1400/08/24' },
    { projectId: project7[0].id, number: '3', amount: '14258931337', status: 'تایید شده', startDate: '1400/10/04', endDate: '1400/10/25' },
    { projectId: project7[0].id, number: '4', amount: '67189197524', status: 'تایید شده', startDate: '1400/12/01', endDate: '1400/12/25' },
    { projectId: project7[0].id, number: '5', amount: '96953968109', status: 'تایید شده', startDate: '1401/02/02', endDate: '1401/02/23' },
    { projectId: project7[0].id, number: '6', amount: '140430718994', status: 'تایید شده', startDate: '1401/04/02', endDate: '1401/04/23' },
    { projectId: project7[0].id, number: '7', amount: '166789268637', status: 'تایید شده', startDate: '1401/06/01', endDate: '1401/06/15' },
  ]);
  console.log('  ✅ 7 تعدیل ثبت شد');

  // مابه‌التفاوت قیر پروژه 7
  await db.insert(bitumenDiffs).values([
    { projectId: project7[0].id, number: '1', amount: '11526123582', status: 'تایید شده' },
    { projectId: project7[0].id, number: '2', amount: '94845157159', status: 'تایید شده' },
    { projectId: project7[0].id, number: '3', amount: '128891020826', status: 'تایید شده' },
    { projectId: project7[0].id, number: '4', amount: '-23837715636', status: 'تایید شده' },
  ]);
  console.log('  ✅ 4 مابه‌التفاوت قیر ثبت شد');

  console.log('\n✨ همه اطلاعات با موفقیت import شد!');
  console.log(`📊 مجموع: 5 پروژه، ${2+6+6+10} صورت وضعیت، ${2+6+6+7} تعدیل، ${2+4} مابه‌التفاوت قیر`);
}

// اجرای اسکریپت
importProjects()
  .then(() => {
    console.log('✅ عملیات با موفقیت انجام شد');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ خطا در import:', error);
    process.exit(1);
  });
