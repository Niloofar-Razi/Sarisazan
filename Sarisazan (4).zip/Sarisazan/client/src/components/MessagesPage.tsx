import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageSquare, Plus, Send, Paperclip, Search, Users, User, FolderOpen, File, X, Check, CheckCheck } from "lucide-react";
import { format } from "date-fns-jalali";
import { useAuth } from "@/lib/auth-context";
import type { Conversation, Message, User as UserType, Project } from "@shared/schema";
import { cn } from "@/lib/utils";

export default function MessagesPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageContent, setMessageContent] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newConversation, setNewConversation] = useState({
    type: "direct",
    title: "",
    memberIds: [] as string[],
    projectId: "",
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: users = [] } = useQuery<UserType[]>({
    queryKey: ["/api/users"],
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  const { data: messages = [] } = useQuery<(Message & { sender?: UserType; files?: any[]; reads?: any[] })[]>({
    queryKey: [`/api/conversations/${selectedConversation}/messages`],
    enabled: !!selectedConversation,
    refetchInterval: 5000, // Auto-refresh every 5 seconds
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const createConversationMutation = useMutation({
    mutationFn: async (data: typeof newConversation) => {
      const res = await fetch("/api/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create conversation");
      return res.json();
    },
    onSuccess: (newConv) => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setNewConversation({ type: "direct", title: "", memberIds: [], projectId: "" });
      setIsCreateDialogOpen(false);
      setSelectedConversation(newConv.id);
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async ({ conversationId, content, files }: { conversationId: string; content: string; files?: File[] }) => {
      const formData = new FormData();
      if (!user?.id) throw new Error("User not authenticated");
      
      formData.append("senderId", user.id);
      formData.append("content", content);
      
      if (files && files.length > 0) {
        files.forEach((file) => {
          formData.append("files", file);
        });
      }

      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        body: formData,
      });
      if (!res.ok) throw new Error("Failed to send message");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setMessageContent("");
      setSelectedFiles([]);
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSendMessage = () => {
    if (!selectedConversation || (!messageContent.trim() && selectedFiles.length === 0)) return;
    
    sendMessageMutation.mutate({
      conversationId: selectedConversation,
      content: messageContent,
      files: selectedFiles.length > 0 ? selectedFiles : undefined,
    });
  };

  const getConversationIcon = (type: string) => {
    switch (type) {
      case "direct": return <User className="h-4 w-4" />;
      case "group": return <Users className="h-4 w-4" />;
      case "project": return <FolderOpen className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getConversationTypeLabel = (type: string) => {
    switch (type) {
      case "direct": return "مستقیم";
      case "group": return "گروهی";
      case "project": return "پروژه‌ای";
      default: return type;
    }
  };

  const getConversationTypeColor = (type: string) => {
    switch (type) {
      case "direct": return "bg-blue-500";
      case "group": return "bg-green-500";
      case "project": return "bg-purple-500";
      default: return "bg-gray-500";
    }
  };

  const selectedConversationData = conversations.find(c => c.id === selectedConversation);

  return (
    <div className="h-[calc(100vh-12rem)] max-w-full" dir="rtl">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-3xl font-bold">پیام‌ها و گفتگوها</h1>
            <p className="text-sm text-muted-foreground mt-1">
              مدیریت ارتباطات داخلی تیم
            </p>
          </div>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="shadow-md">
                <Plus className="h-4 w-4 ml-2" />
                گفتگوی جدید
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>ایجاد گفتگوی جدید</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>نوع گفتگو</Label>
                  <Select 
                    value={newConversation.type} 
                    onValueChange={(value) => setNewConversation({ ...newConversation, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="direct">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4" />
                          <span>مستقیم (کاربر به کاربر)</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="group">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          <span>گروهی</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="project">
                        <div className="flex items-center gap-2">
                          <FolderOpen className="h-4 w-4" />
                          <span>پروژه‌ای</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>عنوان گفتگو</Label>
                  <Input
                    value={newConversation.title}
                    onChange={(e) => setNewConversation({ ...newConversation, title: e.target.value })}
                    placeholder={
                      newConversation.type === "direct" 
                        ? "مثلاً: گفتگو با علی رضایی" 
                        : "عنوان گفتگو را وارد کنید"
                    }
                  />
                </div>

                {newConversation.type === "project" && (
                  <div className="space-y-2">
                    <Label>انتخاب پروژه</Label>
                    <Select 
                      value={newConversation.projectId} 
                      onValueChange={(value) => setNewConversation({ ...newConversation, projectId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب پروژه" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects.map((project) => (
                          <SelectItem key={project.id} value={project.id}>
                            {project.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <Button 
                  onClick={() => createConversationMutation.mutate(newConversation)} 
                  className="w-full"
                  disabled={!newConversation.title.trim() || (newConversation.type === "project" && !newConversation.projectId)}
                >
                  ایجاد گفتگو
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-12 gap-4 h-full overflow-hidden">
          {/* Conversations List */}
          <Card className="col-span-12 md:col-span-4 lg:col-span-3 flex flex-col h-full">
            <div className="p-4 border-b">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو در گفتگوها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <ScrollArea className="flex-1">
              {conversations.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <MessageSquare className="h-12 w-12 text-muted-foreground mb-3" />
                  <p className="text-sm text-muted-foreground">
                    هنوز گفتگویی وجود ندارد
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    برای شروع، گفتگوی جدیدی ایجاد کنید
                  </p>
                </div>
              ) : (
                conversations
                  .filter((conv) => 
                    !searchQuery || 
                    conv.title?.toLowerCase().includes(searchQuery.toLowerCase())
                  )
                  .map((conversation) => (
                    <div
                      key={conversation.id}
                      onClick={() => setSelectedConversation(conversation.id)}
                      className={cn(
                        "p-4 border-b cursor-pointer hover:bg-accent/50 transition-all duration-200",
                        selectedConversation === conversation.id && "bg-accent border-r-4 border-r-primary"
                      )}
                    >
                      <div className="flex items-start gap-3">
                        <div className={cn(
                          "p-2 rounded-lg",
                          getConversationTypeColor(conversation.type),
                          "bg-opacity-10"
                        )}>
                          {getConversationIcon(conversation.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium truncate">
                              {conversation.title || "بدون عنوان"}
                            </span>
                            <Badge variant="secondary" className="text-xs">
                              {getConversationTypeLabel(conversation.type)}
                            </Badge>
                          </div>
                          {conversation.updatedAt && (
                            <span className="text-xs text-muted-foreground">
                              {format(conversation.updatedAt, "yyyy/MM/dd HH:mm")}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
              )}
            </ScrollArea>
          </Card>

          {/* Messages Area */}
          <Card className="col-span-12 md:col-span-8 lg:col-span-9 flex flex-col h-full">
            {!selectedConversation ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">گفتگوی خود را انتخاب کنید</h3>
                  <p className="text-sm text-muted-foreground">
                    برای مشاهده پیام‌ها، یک گفتگو از لیست سمت راست انتخاب کنید
                  </p>
                </div>
              </div>
            ) : (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "p-2 rounded-lg",
                      getConversationTypeColor(selectedConversationData?.type || ""),
                      "bg-opacity-10"
                    )}>
                      {getConversationIcon(selectedConversationData?.type || "")}
                    </div>
                    <div>
                      <h3 className="font-semibold">
                        {selectedConversationData?.title || "بدون عنوان"}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {getConversationTypeLabel(selectedConversationData?.type || "")}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  {messages.length === 0 ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">
                          هنوز پیامی ارسال نشده است
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          اولین پیام را ارسال کنید
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages.map((message) => {
                        const isMyMessage = message.senderId === user?.id;
                        return (
                          <div
                            key={message.id}
                            className={cn(
                              "flex gap-3",
                              isMyMessage ? "flex-row-reverse" : "flex-row"
                            )}
                          >
                            <Avatar className="h-8 w-8 mt-1">
                              <AvatarFallback className={isMyMessage ? "bg-primary text-primary-foreground" : "bg-secondary"}>
                                {message.sender?.firstName?.[0] || "U"}
                              </AvatarFallback>
                            </Avatar>
                            <div className={cn("flex flex-col gap-1 max-w-[70%]", isMyMessage && "items-end")}>
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-medium">
                                  {isMyMessage ? "شما" : `${message.sender?.firstName || ""} ${message.sender?.lastName || ""}`}
                                </span>
                                <span className="text-xs text-muted-foreground">
                                  {message.createdAt ? format(new Date(message.createdAt), "HH:mm") : ""}
                                </span>
                              </div>
                              <div className={cn(
                                "rounded-2xl px-4 py-2 shadow-sm",
                                isMyMessage 
                                  ? "bg-primary text-primary-foreground rounded-tr-sm" 
                                  : "bg-accent rounded-tl-sm"
                              )}>
                                <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
                                {message.files && message.files.length > 0 && (
                                  <div className="mt-2 space-y-1">
                                    {message.files.map((file: any, index: number) => (
                                      <div key={index} className="flex items-center gap-2 text-xs">
                                        <File className="h-3 w-3" />
                                        <span>{file.originalName}</span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                              {isMyMessage && (
                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                  {message.reads && message.reads.length > 0 ? (
                                    <CheckCheck className="h-3 w-3 text-blue-500" />
                                  ) : (
                                    <Check className="h-3 w-3" />
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </ScrollArea>

                {/* Message Input */}
                <div className="p-4 border-t">
                  {selectedFiles.length > 0 && (
                    <div className="mb-2 flex flex-wrap gap-2">
                      {selectedFiles.map((file, index) => (
                        <div key={index} className="flex items-center gap-2 bg-accent px-3 py-1 rounded-lg text-sm">
                          <File className="h-4 w-4" />
                          <span className="max-w-[150px] truncate">{file.name}</span>
                          <button onClick={() => removeFile(index)} className="hover:text-destructive">
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      multiple
                      className="hidden"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => fileInputRef.current?.click()}
                      title="پیوست فایل"
                    >
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    <Textarea
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder="پیام خود را بنویسید... (Enter برای ارسال، Shift+Enter برای خط جدید)"
                      className="min-h-[60px] resize-none"
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!messageContent.trim() && selectedFiles.length === 0}
                      size="icon"
                      className="h-[60px]"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
