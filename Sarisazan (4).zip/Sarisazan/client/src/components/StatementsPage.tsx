import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Plus, Edit, Trash2, FileText, TrendingUp, X, History } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns-jalali";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";

type Statement = {
  id: string;
  projectId: string;
  number: string;
  amount: string;
  status: string;
  filePath?: string | null;
  announcedDate?: string | null;
  submissionDate?: string | null;
  startDate?: string | null;
  endDate?: string | null;
  workPeriod?: string | null;
  baseMaterials?: string | null;
  notes?: string | null;
  createdAt: string;
};

type Adjustment = {
  id: string;
  projectId: string;
  number: string;
  amount: string;
  status: string;
  indexType?: string | null;
  upToStatementNumber?: string | null;
  filePath?: string | null;
  notes?: string | null;
  createdAt: string;
};

type BitumenDiff = {
  id: string;
  projectId: string;
  number: string;
  amount: string;
  status: string;
  filePath?: string | null;
  notes?: string | null;
  createdAt: string;
};

type Project = {
  id: string;
  title: string;
  contractNumber?: string | null;
  contractDate?: string | null;
  employer?: string | null;
  contractor?: string | null;
  amount?: string | null;
};

const statuses = [
  { value: "تأیید شده", label: "تأیید شده", color: "bg-green-500" },
  { value: "ابلاغ شده", label: "ابلاغ شده", color: "bg-blue-500" },
  { value: "ارسال‌شده به کارفرما", label: "ارسال‌شده به کارفرما", color: "bg-cyan-500" },
  { value: "ارسال‌شده به مشاور", label: "ارسال‌شده به مشاور", color: "bg-indigo-500" },
  { value: "در انتظار", label: "در انتظار", color: "bg-yellow-500" },
  { value: "حذف‌شده", label: "حذف‌شده", color: "bg-red-500" },
  { value: "اصلاح‌شده", label: "اصلاح‌شده", color: "bg-purple-500" },
];

type BaseMaterial = {
  type: string;
  quantity: string;
  amount: string;
  amountWithCoefficients: string;
  unit: string;
  coefficient: string;
};

export default function StatementsPage() {
  const [activeTab, setActiveTab] = useState("statements");
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  
  const [statementDialog, setStatementDialog] = useState(false);
  const [adjustmentDialog, setAdjustmentDialog] = useState(false);
  const [bitumenDiffDialog, setBitumenDiffDialog] = useState(false);
  
  const [editingStatement, setEditingStatement] = useState<Statement | null>(null);
  const [editingAdjustment, setEditingAdjustment] = useState<Adjustment | null>(null);
  const [editingBitumenDiff, setEditingBitumenDiff] = useState<BitumenDiff | null>(null);
  
  const [baseMaterials, setBaseMaterials] = useState<BaseMaterial[]>([{
    type: "",
    quantity: "",
    amount: "",
    amountWithCoefficients: "",
    unit: "",
    coefficient: ""
  }]);

  const queryClient = useQueryClient();

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: statements = [] } = useQuery<Statement[]>({
    queryKey: ["/api/statements", { projectId: selectedProject, status: statusFilter === "all" ? undefined : statusFilter }],
    enabled: selectedProject !== "",
  });

  const { data: adjustments = [] } = useQuery<Adjustment[]>({
    queryKey: ["/api/adjustments", { projectId: selectedProject, status: statusFilter === "all" ? undefined : statusFilter }],
    enabled: selectedProject !== "",
  });

  const { data: bitumenDiffs = [] } = useQuery<BitumenDiff[]>({
    queryKey: ["/api/bitumen-diffs", { projectId: selectedProject, status: statusFilter === "all" ? undefined : statusFilter }],
    enabled: selectedProject !== "",
  });

  const selectedProjectData = useMemo(
    () => projects.find(p => p.id === selectedProject),
    [projects, selectedProject]
  );

  const filteredStatements = useMemo(
    () => statements.filter(s => 
      s.number.includes(searchTerm) || s.notes?.includes(searchTerm)
    ),
    [statements, searchTerm]
  );

  const filteredAdjustments = useMemo(
    () => adjustments.filter(a => 
      a.number.includes(searchTerm) || a.notes?.includes(searchTerm)
    ),
    [adjustments, searchTerm]
  );

  const filteredBitumenDiffs = useMemo(
    () => bitumenDiffs.filter(b => 
      b.number.includes(searchTerm) || b.notes?.includes(searchTerm)
    ),
    [bitumenDiffs, searchTerm]
  );

  const statementsSum = useMemo(
    () => filteredStatements.reduce((sum, s) => sum + parseFloat(s.amount || "0"), 0),
    [filteredStatements]
  );
  
  const adjustmentsSum = useMemo(
    () => filteredAdjustments.reduce((sum, a) => sum + parseFloat(a.amount || "0"), 0),
    [filteredAdjustments]
  );
  
  const bitumenDiffsSum = useMemo(
    () => filteredBitumenDiffs.reduce((sum, b) => sum + parseFloat(b.amount || "0"), 0),
    [filteredBitumenDiffs]
  );

  const latestApprovedStatement = useMemo(
    () => statements
      .filter(s => s.status === "تأیید شده")
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0],
    [statements]
  );

  const latestApprovedAdjustment = useMemo(
    () => adjustments
      .filter(a => a.status === "تأیید شده")
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0],
    [adjustments]
  );

  const latestApprovedBitumenDiff = useMemo(
    () => bitumenDiffs
      .filter(b => b.status === "تأیید شده")
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0],
    [bitumenDiffs]
  );

  const financialProgress = useMemo(() => {
    if (!selectedProjectData?.amount) return "0";
    const contractAmount = parseFloat(selectedProjectData.amount.replace(/,/g, "") || "0");
    if (contractAmount === 0) return "0";

    const approvedStatements = statements.filter(s => s.status === "تأیید شده");
    const approvedAdjustments = adjustments.filter(a => a.status === "تأیید شده");
    const approvedBitumenDiffs = bitumenDiffs.filter(b => b.status === "تأیید شده");

    const statementsTotal = approvedStatements.reduce((sum, s) => sum + parseFloat(s.amount || "0"), 0);
    const adjustmentsTotal = approvedAdjustments.reduce((sum, a) => sum + parseFloat(a.amount || "0"), 0);
    const bitumenDiffsTotal = approvedBitumenDiffs.reduce((sum, b) => sum + parseFloat(b.amount || "0"), 0);

    const total = statementsTotal + adjustmentsTotal + bitumenDiffsTotal;
    return ((total / contractAmount) * 100).toFixed(2);
  }, [selectedProjectData, statements, adjustments, bitumenDiffs]);

  const createStatementMutation = useMutation({
    mutationFn: async (data: Partial<Statement>) => {
      const response = await fetch("/api/statements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/statements"] });
      setStatementDialog(false);
      setEditingStatement(null);
      toast({ title: "صورت‌وضعیت با موفقیت ثبت شد" });
    },
  });

  const updateStatementMutation = useMutation({
    mutationFn: async (data: Statement) => {
      const response = await fetch(`/api/statements/${data.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/statements"] });
      setStatementDialog(false);
      setEditingStatement(null);
      toast({ title: "صورت‌وضعیت به‌روزرسانی شد" });
    },
  });

  const deleteStatementMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/statements/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/statements"] });
      toast({ title: "صورت‌وضعیت حذف شد" });
    },
  });

  const createAdjustmentMutation = useMutation({
    mutationFn: async (data: Partial<Adjustment>) => {
      const response = await fetch("/api/adjustments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/adjustments"] });
      setAdjustmentDialog(false);
      setEditingAdjustment(null);
      toast({ title: "تعدیل با موفقیت ثبت شد" });
    },
  });

  const updateAdjustmentMutation = useMutation({
    mutationFn: async (data: Adjustment) => {
      const response = await fetch(`/api/adjustments/${data.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/adjustments"] });
      setAdjustmentDialog(false);
      setEditingAdjustment(null);
      toast({ title: "تعدیل به‌روزرسانی شد" });
    },
  });

  const deleteAdjustmentMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/adjustments/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/adjustments"] });
      toast({ title: "تعدیل حذف شد" });
    },
  });

  const createBitumenDiffMutation = useMutation({
    mutationFn: async (data: Partial<BitumenDiff>) => {
      const response = await fetch("/api/bitumen-diffs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen-diffs"] });
      setBitumenDiffDialog(false);
      setEditingBitumenDiff(null);
      toast({ title: "مابه‌التفاوت قیر با موفقیت ثبت شد" });
    },
  });

  const updateBitumenDiffMutation = useMutation({
    mutationFn: async (data: BitumenDiff) => {
      const response = await fetch(`/api/bitumen-diffs/${data.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen-diffs"] });
      setBitumenDiffDialog(false);
      setEditingBitumenDiff(null);
      toast({ title: "مابه‌التفاوت قیر به‌روزرسانی شد" });
    },
  });

  const deleteBitumenDiffMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/bitumen-diffs/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen-diffs"] });
      toast({ title: "مابه‌التفاوت قیر حذف شد" });
    },
  });

  useEffect(() => {
    if (editingStatement && editingStatement.baseMaterials) {
      try {
        const parsed = JSON.parse(editingStatement.baseMaterials);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setBaseMaterials(parsed);
        }
      } catch (e) {
        setBaseMaterials([{
          type: editingStatement.baseMaterials || "",
          quantity: "",
          amount: "",
          amountWithCoefficients: "",
          unit: "",
          coefficient: ""
        }]);
      }
    } else {
      setBaseMaterials([{
        type: "",
        quantity: "",
        amount: "",
        amountWithCoefficients: "",
        unit: "",
        coefficient: ""
      }]);
    }
  }, [editingStatement, statementDialog]);
  
  const handleAddBaseMaterial = () => {
    setBaseMaterials([...baseMaterials, {
      type: "",
      quantity: "",
      amount: "",
      amountWithCoefficients: "",
      unit: "",
      coefficient: ""
    }]);
  };

  const handleRemoveBaseMaterial = (index: number) => {
    if (baseMaterials.length > 1) {
      setBaseMaterials(baseMaterials.filter((_, i) => i !== index));
    }
  };

  const handleBaseMaterialChange = (index: number, field: keyof BaseMaterial, value: string) => {
    const newMaterials = [...baseMaterials];
    newMaterials[index][field] = value;
    
    if (field === "amount" || field === "quantity" || field === "coefficient") {
      const amount = parseFloat(newMaterials[index].amount);
      const quantity = parseFloat(newMaterials[index].quantity);
      const coefficient = parseFloat(newMaterials[index].coefficient);
      
      const validAmount = isNaN(amount) ? 0 : amount;
      const validQuantity = isNaN(quantity) ? 0 : quantity;
      const validCoefficient = isNaN(coefficient) ? 1 : coefficient;
      
      newMaterials[index].amountWithCoefficients = (validAmount * validQuantity * validCoefficient).toString();
    }
    
    setBaseMaterials(newMaterials);
  };

  const handleStatementSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      projectId: selectedProject,
      number: formData.get("number") as string,
      amount: formData.get("amount") as string,
      status: formData.get("status") as string,
      announcedDate: formData.get("announcedDate") as string,
      submissionDate: formData.get("submissionDate") as string,
      startDate: formData.get("startDate") as string,
      endDate: formData.get("endDate") as string,
      workPeriod: formData.get("workPeriod") as string,
      baseMaterials: JSON.stringify(baseMaterials.filter(m => m.type.trim() !== "")),
      notes: formData.get("notes") as string,
    };

    if (editingStatement) {
      updateStatementMutation.mutate({ ...editingStatement, ...data });
    } else {
      createStatementMutation.mutate(data);
    }
  };

  const handleAdjustmentSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      projectId: selectedProject,
      number: formData.get("number") as string,
      amount: formData.get("amount") as string,
      status: formData.get("status") as string,
      indexType: formData.get("indexType") as string,
      upToStatementNumber: formData.get("upToStatementNumber") as string,
      notes: formData.get("notes") as string,
    };

    if (editingAdjustment) {
      updateAdjustmentMutation.mutate({ ...editingAdjustment, ...data });
    } else {
      createAdjustmentMutation.mutate(data);
    }
  };

  const handleBitumenDiffSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      projectId: selectedProject,
      number: formData.get("number") as string,
      amount: formData.get("amount") as string,
      status: formData.get("status") as string,
      notes: formData.get("notes") as string,
    };

    if (editingBitumenDiff) {
      updateBitumenDiffMutation.mutate({ ...editingBitumenDiff, ...data });
    } else {
      createBitumenDiffMutation.mutate(data);
    }
  };


  const getStatusBadge = (status: string) => {
    const statusInfo = statuses.find(s => s.value === status);
    return (
      <Badge className={statusInfo?.color || "bg-gray-500"}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">صورت‌وضعیت‌ها</h1>
      </div>

      <Card>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>انتخاب پروژه</Label>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger>
                  <SelectValue placeholder="پروژه را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>جست‌وجو</Label>
              <Input
                placeholder="شماره یا توضیحات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div>
              <Label>وضعیت</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="همه" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  {statuses.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedProjectData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              اطلاعات پروژه
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">عنوان پروژه</p>
                <p className="font-medium">{selectedProjectData.title}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">شماره قرارداد</p>
                <p className="font-medium">{selectedProjectData.contractNumber || "-"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">تاریخ قرارداد</p>
                <p className="font-medium">{selectedProjectData.contractDate ? toPersianDigits(format(new Date(selectedProjectData.contractDate), 'yyyy/MM/dd')) : "-"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">مبلغ قرارداد</p>
                <p className="font-medium">{selectedProjectData.amount ? formatCurrency(selectedProjectData.amount) + " ریال" : "-"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">پیمانکار</p>
                <p className="font-medium">{selectedProjectData.contractor || "-"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">کارفرما</p>
                <p className="font-medium">{selectedProjectData.employer || "-"}</p>
              </div>
            </div>
            <div className="pt-4 border-t flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <p className="text-lg font-bold text-green-600">
                پیشرفت ریالی: {financialProgress}٪
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedProject && statements.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              تاریخچه مالی پروژه
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="multiple" className="w-full">
              <AccordionItem value="statements-history">
                <AccordionTrigger className="text-lg font-semibold">
                  صورت‌وضعیت‌ها ({statements.filter(s => s.status === "تأیید شده").length} تایید شده)
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2 mt-2">
                    {statements
                      .filter(s => s.status === "تأیید شده")
                      .sort((a, b) => parseInt(a.number) - parseInt(b.number))
                      .map((statement) => (
                        <div key={statement.id} className="flex justify-between items-center p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
                          <div>
                            <span className="font-medium">شماره {statement.number}</span>
                            <span className="text-sm text-muted-foreground mr-2">
                              {statement.startDate && statement.endDate ? 
                                `(${toPersianDigits(statement.startDate)} تا ${toPersianDigits(statement.endDate)})` : 
                                ""
                              }
                            </span>
                          </div>
                          <div className="text-left">
                            <div className="font-bold text-green-600">{formatCurrency(statement.amount)} ریال</div>
                            <div className="text-xs text-muted-foreground">
                              {toPersianDigits(format(new Date(statement.createdAt), 'yyyy/MM/dd'))}
                            </div>
                          </div>
                        </div>
                      ))}
                    {statements.filter(s => s.status === "تأیید شده").length === 0 && (
                      <p className="text-center text-muted-foreground py-4">هیچ صورت‌وضعیت تایید شده‌ای وجود ندارد</p>
                    )}
                  </div>
                  <div className="mt-4 pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="font-bold">جمع کل:</span>
                      <span className="text-xl font-bold text-green-600">
                        {formatCurrency(statements.filter(s => s.status === "تأیید شده").reduce((sum, s) => sum + parseFloat(s.amount || "0"), 0).toString())} ریال
                      </span>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {adjustments.length > 0 && (
                <AccordionItem value="adjustments-history">
                  <AccordionTrigger className="text-lg font-semibold">
                    تعدیل‌ها ({adjustments.filter(a => a.status === "تأیید شده").length} تایید شده)
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2 mt-2">
                      {adjustments
                        .filter(a => a.status === "تأیید شده")
                        .sort((a, b) => parseInt(a.number) - parseInt(b.number))
                        .map((adjustment) => (
                          <div key={adjustment.id} className="flex justify-between items-center p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
                            <div>
                              <span className="font-medium">شماره {adjustment.number}</span>
                              {adjustment.indexType && (
                                <Badge variant="outline" className="mr-2">{adjustment.indexType}</Badge>
                              )}
                            </div>
                            <div className="text-left">
                              <div className="font-bold text-blue-600">{formatCurrency(adjustment.amount)} ریال</div>
                              <div className="text-xs text-muted-foreground">
                                {toPersianDigits(format(new Date(adjustment.createdAt), 'yyyy/MM/dd'))}
                              </div>
                            </div>
                          </div>
                        ))}
                      {adjustments.filter(a => a.status === "تأیید شده").length === 0 && (
                        <p className="text-center text-muted-foreground py-4">هیچ تعدیل تایید شده‌ای وجود ندارد</p>
                      )}
                    </div>
                    <div className="mt-4 pt-4 border-t">
                      <div className="flex justify-between items-center">
                        <span className="font-bold">جمع کل:</span>
                        <span className="text-xl font-bold text-blue-600">
                          {formatCurrency(adjustments.filter(a => a.status === "تأیید شده").reduce((sum, a) => sum + parseFloat(a.amount || "0"), 0).toString())} ریال
                        </span>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )}

              {bitumenDiffs.length > 0 && (
                <AccordionItem value="bitumen-diffs-history">
                  <AccordionTrigger className="text-lg font-semibold">
                    مابه‌التفاوت قیر ({bitumenDiffs.filter(b => b.status === "تأیید شده").length} تایید شده)
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2 mt-2">
                      {bitumenDiffs
                        .filter(b => b.status === "تأیید شده")
                        .sort((a, b) => parseInt(a.number) - parseInt(b.number))
                        .map((bitumenDiff) => (
                          <div key={bitumenDiff.id} className="flex justify-between items-center p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
                            <div>
                              <span className="font-medium">شماره {bitumenDiff.number}</span>
                            </div>
                            <div className="text-left">
                              <div className={`font-bold ${parseFloat(bitumenDiff.amount) < 0 ? 'text-red-600' : 'text-purple-600'}`}>
                                {formatCurrency(bitumenDiff.amount)} ریال
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {toPersianDigits(format(new Date(bitumenDiff.createdAt), 'yyyy/MM/dd'))}
                              </div>
                            </div>
                          </div>
                        ))}
                      {bitumenDiffs.filter(b => b.status === "تأیید شده").length === 0 && (
                        <p className="text-center text-muted-foreground py-4">هیچ مابه‌التفاوت تایید شده‌ای وجود ندارد</p>
                      )}
                    </div>
                    <div className="mt-4 pt-4 border-t">
                      <div className="flex justify-between items-center">
                        <span className="font-bold">جمع کل:</span>
                        <span className={`text-xl font-bold ${bitumenDiffs.filter(b => b.status === "تأیید شده").reduce((sum, b) => sum + parseFloat(b.amount || "0"), 0) < 0 ? 'text-red-600' : 'text-purple-600'}`}>
                          {formatCurrency(bitumenDiffs.filter(b => b.status === "تأیید شده").reduce((sum, b) => sum + parseFloat(b.amount || "0"), 0).toString())} ریال
                        </span>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )}
            </Accordion>
          </CardContent>
        </Card>
      )}

      {selectedProject && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="statements">صورت‌وضعیت‌ها</TabsTrigger>
            <TabsTrigger value="adjustments">تعدیل‌ها</TabsTrigger>
            <TabsTrigger value="bitumen-diffs">مابه‌التفاوت قیر</TabsTrigger>
          </TabsList>

          <TabsContent value="statements" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>صورت‌وضعیت‌ها</CardTitle>
                  <Button onClick={() => { setEditingStatement(null); setStatementDialog(true); }}>
                    <Plus className="ml-2 h-4 w-4" />
                    افزودن صورت‌وضعیت
                  </Button>
                </div>
                {latestApprovedStatement && (
                  <div className="text-sm text-muted-foreground">
                    آخرین صورت‌وضعیت تأیید شده: شماره {latestApprovedStatement.number} - مبلغ: {formatCurrency(latestApprovedStatement.amount)} ریال
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">ردیف</TableHead>
                      <TableHead className="text-right">شماره</TableHead>
                      <TableHead className="text-right">مبلغ (ریال)</TableHead>
                      <TableHead className="text-right">وضعیت</TableHead>
                      <TableHead className="text-right">تاریخ ابلاغ</TableHead>
                      <TableHead className="text-right">تاریخ ثبت</TableHead>
                      <TableHead className="text-right">عملیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStatements.map((statement, index) => (
                      <TableRow key={statement.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{statement.number}</TableCell>
                        <TableCell>{formatCurrency(statement.amount)}</TableCell>
                        <TableCell>{getStatusBadge(statement.status)}</TableCell>
                        <TableCell>{statement.announcedDate ? toPersianDigits(format(new Date(statement.announcedDate), 'yyyy/MM/dd')) : "-"}</TableCell>
                        <TableCell>{toPersianDigits(format(new Date(statement.createdAt), 'yyyy/MM/dd'))}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => { setEditingStatement(statement); setStatementDialog(true); }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteStatementMutation.mutate(statement.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4 text-left font-bold text-lg">
                  جمع کل: {formatCurrency(statementsSum.toString())} ریال
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="adjustments" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>تعدیل‌ها</CardTitle>
                  <Button onClick={() => { setEditingAdjustment(null); setAdjustmentDialog(true); }}>
                    <Plus className="ml-2 h-4 w-4" />
                    افزودن تعدیل
                  </Button>
                </div>
                {latestApprovedAdjustment && (
                  <div className="text-sm text-muted-foreground">
                    آخرین تعدیل تأیید شده: شماره {latestApprovedAdjustment.number} - مبلغ: {formatCurrency(latestApprovedAdjustment.amount)} ریال
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">ردیف</TableHead>
                      <TableHead className="text-right">شماره</TableHead>
                      <TableHead className="text-right">مبلغ (ریال)</TableHead>
                      <TableHead className="text-right">وضعیت</TableHead>
                      <TableHead className="text-right">تاریخ ثبت</TableHead>
                      <TableHead className="text-right">عملیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAdjustments.map((adjustment, index) => (
                      <TableRow key={adjustment.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{adjustment.number}</TableCell>
                        <TableCell>{formatCurrency(adjustment.amount)}</TableCell>
                        <TableCell>{getStatusBadge(adjustment.status)}</TableCell>
                        <TableCell>{toPersianDigits(format(new Date(adjustment.createdAt), 'yyyy/MM/dd'))}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => { setEditingAdjustment(adjustment); setAdjustmentDialog(true); }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteAdjustmentMutation.mutate(adjustment.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4 text-left font-bold text-lg">
                  جمع کل: {formatCurrency(adjustmentsSum.toString())} ریال
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bitumen-diffs" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>مابه‌التفاوت قیر</CardTitle>
                  <Button onClick={() => { setEditingBitumenDiff(null); setBitumenDiffDialog(true); }}>
                    <Plus className="ml-2 h-4 w-4" />
                    افزودن مابه‌التفاوت
                  </Button>
                </div>
                {latestApprovedBitumenDiff && (
                  <div className="text-sm text-muted-foreground">
                    آخرین مابه‌التفاوت تأیید شده: شماره {latestApprovedBitumenDiff.number} - مبلغ: {formatCurrency(latestApprovedBitumenDiff.amount)} ریال
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">ردیف</TableHead>
                      <TableHead className="text-right">شماره</TableHead>
                      <TableHead className="text-right">مبلغ (ریال)</TableHead>
                      <TableHead className="text-right">وضعیت</TableHead>
                      <TableHead className="text-right">تاریخ ثبت</TableHead>
                      <TableHead className="text-right">عملیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBitumenDiffs.map((bitumenDiff, index) => (
                      <TableRow key={bitumenDiff.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{bitumenDiff.number}</TableCell>
                        <TableCell className={parseFloat(bitumenDiff.amount) < 0 ? "text-red-600" : ""}>
                          {formatCurrency(bitumenDiff.amount)}
                        </TableCell>
                        <TableCell>{getStatusBadge(bitumenDiff.status)}</TableCell>
                        <TableCell>{toPersianDigits(format(new Date(bitumenDiff.createdAt), 'yyyy/MM/dd'))}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => { setEditingBitumenDiff(bitumenDiff); setBitumenDiffDialog(true); }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteBitumenDiffMutation.mutate(bitumenDiff.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4 text-left font-bold text-lg">
                  جمع کل: {formatCurrency(bitumenDiffsSum.toString())} ریال
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      <Dialog open={statementDialog} onOpenChange={setStatementDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingStatement ? "ویرایش صورت‌وضعیت" : "افزودن صورت‌وضعیت"}</DialogTitle>
            <DialogDescription>اطلاعات صورت‌وضعیت را وارد کنید</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleStatementSubmit} className="space-y-4">
            <div>
              <Label htmlFor="number">شماره</Label>
              <Input id="number" name="number" defaultValue={editingStatement?.number} required />
            </div>
            <div>
              <Label htmlFor="amount">مبلغ (ریال)</Label>
              <Input id="amount" name="amount" type="number" defaultValue={editingStatement?.amount} required />
            </div>
            <div>
              <Label htmlFor="status">وضعیت</Label>
              <Select name="status" defaultValue={editingStatement?.status || "در انتظار"}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statuses.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="announcedDate">تاریخ ابلاغ</Label>
              <Input id="announcedDate" name="announcedDate" type="text" placeholder="1403/07/15" defaultValue={editingStatement?.announcedDate || ""} />
            </div>
            <div>
              <Label htmlFor="submissionDate">تاریخ تحویل</Label>
              <Input id="submissionDate" name="submissionDate" type="text" placeholder="1403/07/15" defaultValue={editingStatement?.submissionDate || ""} />
            </div>
            <div>
              <Label htmlFor="startDate">تاریخ شروع</Label>
              <Input id="startDate" name="startDate" type="text" placeholder="1403/07/01" defaultValue={editingStatement?.startDate || ""} />
            </div>
            <div>
              <Label htmlFor="endDate">تاریخ پایان</Label>
              <Input id="endDate" name="endDate" type="text" placeholder="1403/07/15" defaultValue={editingStatement?.endDate || ""} />
            </div>
            <div>
              <Label htmlFor="workPeriod">دوره کار</Label>
              <Input id="workPeriod" name="workPeriod" placeholder="هفته اول مهر 1403" defaultValue={editingStatement?.workPeriod || ""} />
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>مصالح پایه کار</Label>
                <Button type="button" variant="outline" size="sm" onClick={handleAddBaseMaterial}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن ردیف
                </Button>
              </div>
              <div className="space-y-3 max-h-[300px] overflow-y-auto p-2 border rounded-lg">
                {baseMaterials.map((material, index) => (
                  <div key={index} className="p-3 border rounded-lg bg-muted/20 space-y-2">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">ردیف {toPersianDigits(index + 1)}</span>
                      {baseMaterials.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveBaseMaterial(index)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Label className="text-xs">نوع</Label>
                        <Input
                          value={material.type}
                          onChange={(e) => handleBaseMaterialChange(index, "type", e.target.value)}
                          placeholder="نوع ماده"
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">مقدار</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={material.quantity}
                          onChange={(e) => handleBaseMaterialChange(index, "quantity", e.target.value)}
                          placeholder="0"
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">واحد</Label>
                        <Input
                          value={material.unit}
                          onChange={(e) => handleBaseMaterialChange(index, "unit", e.target.value)}
                          placeholder="تن، متر مکعب..."
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">مبلغ (ریال)</Label>
                        <Input
                          type="number"
                          value={material.amount}
                          onChange={(e) => handleBaseMaterialChange(index, "amount", e.target.value)}
                          placeholder="0"
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">ضریب</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={material.coefficient}
                          onChange={(e) => handleBaseMaterialChange(index, "coefficient", e.target.value)}
                          placeholder="1"
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">مبلغ با ضرایب</Label>
                        <Input
                          value={material.amountWithCoefficients}
                          readOnly
                          placeholder="محاسبه خودکار"
                          className="h-8 bg-muted"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <Label htmlFor="notes">توضیحات</Label>
              <Textarea id="notes" name="notes" defaultValue={editingStatement?.notes || ""} />
            </div>
            <DialogFooter>
              <Button type="submit">{editingStatement ? "به‌روزرسانی" : "ثبت"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={adjustmentDialog} onOpenChange={setAdjustmentDialog}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingAdjustment ? "ویرایش تعدیل" : "افزودن تعدیل"}</DialogTitle>
            <DialogDescription>اطلاعات تعدیل را وارد کنید</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAdjustmentSubmit} className="space-y-4">
            <div>
              <Label htmlFor="adj-number">شماره</Label>
              <Input id="adj-number" name="number" defaultValue={editingAdjustment?.number} required />
            </div>
            <div>
              <Label htmlFor="adj-amount">مبلغ (ریال)</Label>
              <Input id="adj-amount" name="amount" type="number" defaultValue={editingAdjustment?.amount} required />
            </div>
            <div>
              <Label htmlFor="adj-status">وضعیت</Label>
              <Select name="status" defaultValue={editingAdjustment?.status || "در انتظار"}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statuses.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="adj-indexType">نوع شاخص</Label>
              <Select name="indexType" defaultValue={editingAdjustment?.indexType || "قطعی"}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="قطعی">قطعی</SelectItem>
                  <SelectItem value="علی‌الحساب">علی‌الحساب</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="adj-upToStatementNumber">تا صورت‌وضعیت شماره</Label>
              <Input id="adj-upToStatementNumber" name="upToStatementNumber" placeholder="5" defaultValue={editingAdjustment?.upToStatementNumber || ""} />
            </div>
            <div>
              <Label htmlFor="adj-notes">توضیحات</Label>
              <Textarea id="adj-notes" name="notes" defaultValue={editingAdjustment?.notes || ""} />
            </div>
            <DialogFooter>
              <Button type="submit">{editingAdjustment ? "به‌روزرسانی" : "ثبت"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={bitumenDiffDialog} onOpenChange={setBitumenDiffDialog}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingBitumenDiff ? "ویرایش مابه‌التفاوت" : "افزودن مابه‌التفاوت"}</DialogTitle>
            <DialogDescription>اطلاعات مابه‌التفاوت قیر را وارد کنید</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleBitumenDiffSubmit} className="space-y-4">
            <div>
              <Label htmlFor="bit-number">شماره</Label>
              <Input id="bit-number" name="number" defaultValue={editingBitumenDiff?.number} required />
            </div>
            <div>
              <Label htmlFor="bit-amount">مبلغ (ریال) - می‌تواند منفی باشد</Label>
              <Input id="bit-amount" name="amount" type="number" step="any" defaultValue={editingBitumenDiff?.amount} required />
            </div>
            <div>
              <Label htmlFor="bit-status">وضعیت</Label>
              <Select name="status" defaultValue={editingBitumenDiff?.status || "در انتظار"}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statuses.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="bit-notes">توضیحات</Label>
              <Textarea id="bit-notes" name="notes" defaultValue={editingBitumenDiff?.notes || ""} />
            </div>
            <DialogFooter>
              <Button type="submit">{editingBitumenDiff ? "به‌روزرسانی" : "ثبت"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
