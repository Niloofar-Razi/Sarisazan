#!/usr/bin/env python3
import pdfplumber
import json
import re

def extract_and_chunk_pdf(pdf_path, output_path):
    """Extract text from PDF and chunk by articles (ماده)"""
    
    print(f"📖 Reading PDF: {pdf_path}")
    
    # Extract all text from PDF
    full_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                full_text += text + "\n"
    
    print(f"✅ Extracted {len(full_text)} characters")
    
    # Split by articles (ماده)
    # Pattern: ماده followed by number and possibly : or other chars
    article_pattern = r'ماده\s*[:\d]+\s*[:：]?\s*([^\n]+)'
    
    articles = []
    current_chapter = None
    
    # Split text into lines
    lines = full_text.split('\n')
    
    current_article = None
    current_number = None
    current_title = None
    current_text = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Check if this is a chapter header
        if 'فصل' in line or 'بخش' in line:
            current_chapter = line
            continue
        
        # Check if this is an article header
        article_match = re.search(r'ماده\s*[:：]?\s*(\d+)\s*[:：]?\s*(.+)?', line)
        
        if article_match:
            # Save previous article if exists
            if current_article is not None and current_text:
                text_content = '\n'.join(current_text).strip()
                if text_content:
                    articles.append({
                        "chapter": current_chapter,
                        "article_number": current_number,
                        "article_title": current_title,
                        "text": text_content
                    })
            
            # Start new article
            current_number = int(article_match.group(1))
            current_title = article_match.group(2).strip() if article_match.group(2) else ""
            current_article = f"ماده {current_number}"
            current_text = []
        else:
            # Add to current article text
            if current_article is not None:
                current_text.append(line)
    
    # Save last article
    if current_article is not None and current_text:
        text_content = '\n'.join(current_text).strip()
        if text_content:
            articles.append({
                "chapter": current_chapter,
                "article_number": current_number,
                "article_title": current_title,
                "text": text_content
            })
    
    # Write to JSONL
    print(f"📝 Writing {len(articles)} articles to {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        for article in articles:
            f.write(json.dumps(article, ensure_ascii=False) + '\n')
    
    print(f"✅ Successfully created {len(articles)} chunks")
    print(f"📊 Sample articles:")
    for i, article in enumerate(articles[:3]):
        print(f"\n  {i+1}. ماده {article['article_number']} - {article['article_title'][:50]}...")
    
    return len(articles)

if __name__ == "__main__":
    pdf_path = "attached_assets/sharayetomoomipeiman_1761451386801.pdf"
    output_path = "server/assets/sharayet_omoomi_peyman_full.jsonl"
    
    count = extract_and_chunk_pdf(pdf_path, output_path)
    print(f"\n🎉 Done! Created {count} article chunks")
