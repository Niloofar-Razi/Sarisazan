#!/usr/bin/env python3
import pdfplumber
import json
import re

def extract_and_chunk_pdf(pdf_path, output_path):
    """Extract text from PDF and chunk by articles"""
    
    print(f"📖 Reading PDF: {pdf_path}")
    
    # Extract all text from PDF
    full_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                full_text += text + "\n"
    
    print(f"✅ Extracted {len(full_text)} characters")
    
    # Save full text for inspection
    with open('temp_full_text.txt', 'w', encoding='utf-8') as f:
        f.write(full_text[:5000])  # First 5000 chars for inspection
    
    # Split by "ماده" (article)
    articles = []
    current_chapter = None
    
    # More flexible pattern - look for "ماده" followed by space and number
    lines = full_text.split('\n')
    
    current_article_num = None
    current_article_title = None
    current_text_lines = []
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        # Skip empty lines
        if not line:
            i += 1
            continue
        
        # Check for chapter/section
        if re.search(r'(فصل|بخش)\s*[:\d]', line):
            current_chapter = line
            i += 1
            continue
        
        # Check for article number - more flexible pattern
        # Looking for: ماده + space + number (possibly with : or other chars)
        article_match = re.search(r'ماده\s*[:\s]*(\d+)', line)
        
        if article_match:
            # Save previous article
            if current_article_num is not None and current_text_lines:
                text_content = '\n'.join(current_text_lines).strip()
                if text_content and len(text_content) > 20:  # Minimum length
                    articles.append({
                        "chapter": current_chapter,
                        "article_number": current_article_num,
                        "article_title": current_article_title or "",
                        "text": text_content
                    })
            
            # Start new article
            current_article_num = int(article_match.group(1))
            
            # Try to get title from same line or next line
            title_part = line.split(str(current_article_num), 1)[-1].strip()
            title_part = re.sub(r'^[\s:：]+', '', title_part)
            
            if not title_part and i + 1 < len(lines):
                title_part = lines[i + 1].strip()
                i += 1  # Skip next line as it was title
            
            current_article_title = title_part
            current_text_lines = []
        else:
            # Add to current article
            if current_article_num is not None:
                current_text_lines.append(line)
        
        i += 1
    
    # Save last article
    if current_article_num is not None and current_text_lines:
        text_content = '\n'.join(current_text_lines).strip()
        if text_content and len(text_content) > 20:
            articles.append({
                "chapter": current_chapter,
                "article_number": current_article_num,
                "article_title": current_article_title or "",
                "text": text_content
            })
    
    # Write to JSONL
    print(f"📝 Writing {len(articles)} articles to {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        for article in articles:
            f.write(json.dumps(article, ensure_ascii=False) + '\n')
    
    print(f"✅ Successfully created {len(articles)} chunks")
    if articles:
        print(f"\n📊 Sample articles:")
        for i, article in enumerate(articles[:5]):
            title = article['article_title'][:60] if article['article_title'] else 'بدون عنوان'
            print(f"  {i+1}. ماده {article['article_number']}: {title}...")
            print(f"     Text length: {len(article['text'])} chars")
    
    return len(articles)

if __name__ == "__main__":
    pdf_path = "attached_assets/sharayetomoomipeiman_1761451386801.pdf"
    output_path = "server/assets/sharayet_omoomi_peyman_full.jsonl"
    
    count = extract_and_chunk_pdf(pdf_path, output_path)
    print(f"\n🎉 Done! Created {count} article chunks")
