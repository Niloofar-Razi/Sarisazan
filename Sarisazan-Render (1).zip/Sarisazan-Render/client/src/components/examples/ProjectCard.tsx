import ProjectCard from '../ProjectCard';

export default function ProjectCardExample() {
  return (
    <div className="p-4 max-w-sm">
      <ProjectCard
        id="1"
        title="پروژه آزادراه تهران-شمال"
        contractNumber="QR-1402-001"
        location="تهران - چالوس"
        employer="سازمان راهداری"
        amount="45,000,000,000"
        progress={65}
        status="active"
        startDate="1402/03/15"
        onViewDetails={(id) => console.log('View project:', id)}
      />
    </div>
  );
}
