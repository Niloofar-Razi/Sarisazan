import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin } from "lucide-react";

interface UserCardProps {
  id: string;
  name: string;
  role: string;
  email?: string;
  phone?: string;
  location?: string;
  avatar?: string;
  isActive: boolean;
  onViewProfile?: (id: string) => void;
}

export default function UserCard({ id, name, role, email, phone, location, avatar, isActive, onViewProfile }: UserCardProps) {
  return (
    <Card className="hover-elevate">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="w-16 h-16">
            <AvatarImage src={avatar} />
            <AvatarFallback className="text-lg">{name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex-1 min-w-0">
                <h3 className="font-bold truncate" data-testid={`user-name-${id}`}>{name}</h3>
                <p className="text-sm text-muted-foreground">{role}</p>
              </div>
              <Badge variant={isActive ? "default" : "secondary"}>
                {isActive ? "فعال" : "غیرفعال"}
              </Badge>
            </div>
            <div className="space-y-1">
              {email && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="w-4 h-4" />
                  <span className="truncate">{email}</span>
                </div>
              )}
              {phone && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-4 h-4" />
                  <span>{phone}</span>
                </div>
              )}
              {location && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span>{location}</span>
                </div>
              )}
            </div>
            {onViewProfile && (
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-3"
                onClick={() => onViewProfile(id)}
                data-testid={`button-view-user-${id}`}
              >
                مشاهده پروفایل
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
