# سریع‌سازان البرز - سیستم مدیریت پروژه

## Overview
This project is a comprehensive construction project management application developed in Farsi. Its primary purpose is to streamline project tracking, material management, tendering processes, and internal communication for construction firms. Key capabilities include managing construction projects, tracking materials like bitumen, daily reporting, tender management with SLA alerts, an analytical dashboard, and an internal messaging system. The ambition is to provide a robust, localized solution for construction project management in Farsi-speaking markets, enhancing efficiency and communication.

## User Preferences
- All user interface elements and content should be in Farsi.
- The application should utilize the Jalali (Persian) calendar system for all date-related functionalities.
- The default currency for all financial transactions and displays should be Iranian Rial (ریال).
- The user interface design must support Right-to-Left (RTL) directionality consistently across all components.

## System Architecture

### UI/UX Decisions
- **Language & Direction**: Farsi language with RTL layout.
- **Date & Currency**: Jalali calendar and Iranian Rial.
- **Components**: Utilizes Radix UI and shadcn/ui for a modern and accessible design system.
- **Design Approach**: Focus on clear, intuitive navigation and data presentation, especially for complex features like tender management and alerts.
- **AI Assistant**: Free token-based search with Persian-aware text normalization, punctuation handling, and stop words filtering. Context-aware responses for projects, alerts, tenders, and statements.

### Technical Implementations
- **Frontend**: Developed with React, Vite, TypeScript, and styled using Tailwind CSS. State management is handled by TanStack Query (React Query).
- **Backend**: Built with Express.js and TypeScript, providing a robust API layer.
- **Database**: PostgreSQL, managed with Drizzle ORM.
- **File Uploads**: `multer` is used for handling file attachments.
- **Real-time Updates**: Hot Module Replacement (HMR) is configured for seamless development.
- **Performance**: Extensive use of `useMemo` for optimizing data-heavy components.

### Feature Specifications
- **Project Management**: CRUD, progress tracking, search, filtering.
- **Material Management (Bitumen)**: Project-specific bitumen record management with CSV export.
- **Progress Statements**: Three-tab interface for Statements, Adjustments, and Bitumen Differences with CRUD, project-based filtering, status tracking, financial calculation, soft delete, and negative amounts support.
- **Tender Management**: Comprehensive CRUD, automated SLA alerts, intelligent sorting, and status tracking.
- **Alert Management**: Centralized listing, advanced filtering, manual creation, status changes, user assignment, and CSV export. Automated hourly alerts for overdue tenders, nearing deadlines, and underperforming projects.
- **Lab Sheets Management**: CRUD for various sheet types, file attachment support (up to 5 files), advanced filtering, status tracking, CSV export, and soft delete.
- **Internal Messaging System**: Supports Direct, Group, and Project-specific conversations with text, file attachments, read/unread status, search, and member management.
- **Reporting**: Daily activity reports and execution progress reports.
- **Roles & Permissions**: Role-based access control with predefined and custom roles, granular permissions, and user profile management.
- **Dashboard**: Real database-driven KPIs (Total Projects, Active Projects, Open Alerts, Average Project Progress), "هشدارها" tab for open alerts, and "تحلیل داده" tab with charts (alert distribution, project status, individual project progress) powered by Recharts.
- **Global Search**: Integrated global search bar in header for project titles and contract numbers.

### System Design Choices
- **Monorepo Structure**: Organized into `client/`, `server/`, and `shared/` directories.
- **Database Schema**: Comprehensive schema including `users`, `projects`, `bitumen_records`, `statements`, `adjustments`, `bitumen_diffs`, `tenders`, `alerts`, `user_projects`, `sheets`, `sheet_files`, `conversations`, `conversation_members`, `messages`, `message_files`, `message_reads`.
- **Integrated Server**: Express server serves both API endpoints and frontend assets on port 5000.
- **Automated Tasks**: Scheduled tasks (e.g., hourly checks for alerts) integrated into the backend.

## External Dependencies
- **Database**: PostgreSQL.
- **ORM**: Drizzle ORM.
- **Node.js Driver**: `pg`.
- **Frontend Libraries**: React, Vite, TypeScript, Tailwind CSS, Radix UI, shadcn/ui, TanStack Query (React Query), Recharts.
- **Backend Libraries**: Express.js, TypeScript.
- **File Upload Middleware**: `multer`.