# Overview

"سریع‌سازان البرز" (Sarisazan Alborz) is a comprehensive construction project management system tailored for Persian/Farsi-speaking users. It offers tools for project tracking, bitumen material management, tender management, alerts, reporting, internal messaging, and an AI assistant for construction contract queries. The system aims to streamline construction project workflows, improve efficiency, and provide robust data management. It's built as a full-stack monorepo with React, Express.js, and PostgreSQL, featuring strong authentication and role-based access control.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Language and Localization
- **Full Persian/Farsi Interface**: RTL layout, Farsi UI and data display.
- **Jalali Calendar System**: All dates use the Persian calendar.
- **Iranian Rial Currency**: Financial data formatted with Iranian Rial.
- **Persian Number Conversion**: Western to Persian numeral conversion.

## Frontend Architecture
- **Framework**: React 18 with TypeScript, Vite.
- **State Management**: TanStack Query for server state, React Context for global state.
- **UI Components**: Radix UI primitives with shadcn/ui.
- **Styling**: Tailwind CSS with RTL optimization.
- **Routing**: Wouter.
- **Form Handling**: React Hook Form with Zod validation.
- **Charts**: Recharts.

## Backend Architecture
- **Server Framework**: Express.js with TypeScript.
- **API Design**: RESTful endpoints.
- **Session Management**: Express sessions with PostgreSQL storage.
- **File Handling**: Multer for file uploads.
- **Authentication**: bcrypt.js for hashing, session-based authentication.
- **Scheduled Tasks**: Hourly auto-alert scheduler.

## Database Architecture
- **Database**: PostgreSQL.
- **ORM**: Drizzle ORM.
- **Schema Location**: `shared/schema.ts`.
- **Migration Strategy**: Drizzle Kit.
- **Key Tables**: Comprehensive tables for users, projects, materials, tenders, alerts, messages, tasks, reports, etc.

## AI Assistant System
- **Primary AI**: Grok API (xAI) using grok-2-1212 for Persian responses.
- **Knowledge Base**: Preprocessed legal documents (شرایط عمومی پیمان).
- **Multi-Source Query**: Routes queries to database, legal documents, or general Grok API.
- **Response Caching**: 7-day cache for API responses.

## File Management
- **Storage**: Local filesystem in `uploads/` directory.
- **Cleanup Service**: Automated cleanup of temporary files.

## Authentication & Authorization
- **Role-Based Access Control (RBAC)**: Granular permissions system.
- **Default Roles**: Admin, Manager, User, Viewer.
- **User Management**: CRUD operations, password reset.
- **Session Security**: Server-side session management.

## Key Features Architecture
- **Project Management**: CRUD, progress tracking, project-specific material records.
- **Material Management (Bitumen)**: Project-scoped records, invoice tracking, supplier management, CSV export.
- **Progress Statements System**: Financial calculations, index-based adjustments, status workflow.
- **Tender Management**: Tracking, deadline monitoring, automated alerts, status workflow.
- **Alert System**: Multi-severity alerts, recipient assignment, comment threads, automated generation.
- **Internal Messaging**: Direct, group, project-specific conversations, file attachments, read/unread tracking.
- **Lab Sheets Management**: Multiple sheet types, file attachments, status workflow, advanced filtering.
- **Task Management**: User assignment, priority levels, reminders, file attachments.
- **Calendar System**: Jalali calendar, daily notes, task reminder badges.
- **Reporting**: Daily activity reports, execution progress reports with detailed logs.
- **Dashboard**: Real-time KPIs, open alerts, data analysis charts, project progress visualization.

## Project Structure
- `/client`: Frontend React application.
- `/server`: Backend Express application.
- `/shared`: Shared types and Drizzle schema.
- `/migrations`: Database migrations.

## Design System
- **Color Palette**: WCAG AA compliant vibrant colors.
- **Page-Specific Themes**: Distinct themes for sections.
- **Typography**: Vazirmatn (Persian), JetBrains Mono (numbers).
- **Components**: Consistent shadcn/ui components with RTL support.

# External Dependencies

## Core Infrastructure
- **Database**: PostgreSQL.
- **AI Service**: Grok API (xAI).

## Authentication & Security
- **Password Hashing**: bcryptjs.
- **Session Storage**: connect-pg-simple.

## File Processing
- **File Uploads**: multer.

## Frontend Libraries
- **UI Components**: Radix UI primitives.
- **Styling**: Tailwind CSS.
- **State Management**: TanStack Query.
- **Form Validation**: React Hook Form, Zod.
- **Date Handling**: date-fns-jalali, jalaali-js.
- **Charts**: recharts.
- **Icons**: lucide-react.

## Backend Libraries
- **ORM**: Drizzle ORM.
- **Database Driver**: @neondatabase/serverless, pg.
- **AI Integration**: openai package (for xAI endpoint).

## Development Tools
- **Build Tool**: Vite.
- **TypeScript**: Full stack support.