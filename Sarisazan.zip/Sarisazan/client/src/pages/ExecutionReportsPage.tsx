import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExecutionReportForm } from "@/components/ExecutionReportForm";
import { ExecutionReportList } from "@/components/ExecutionReportList";

export default function ExecutionReportsPage() {
  const currentUser = {
    id: "87140069-9ef7-4f84-9531-f065f793a4f9",
    name: "علی احمدی",
  };

  return (
    <div className="container mx-auto py-6" dir="rtl">
      <h1 className="text-3xl font-bold mb-6">گزارش روزانه اجرا</h1>
      
      <Tabs defaultValue="form" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="form">ثبت گزارش جدید</TabsTrigger>
          <TabsTrigger value="list">لیست گزارش‌ها</TabsTrigger>
        </TabsList>
        
        <TabsContent value="form" className="mt-6">
          <ExecutionReportForm 
            supervisorId={currentUser.id} 
            supervisorName={currentUser.name} 
          />
        </TabsContent>
        
        <TabsContent value="list" className="mt-6">
          <ExecutionReportList />
        </TabsContent>
      </Tabs>
    </div>
  );
}
