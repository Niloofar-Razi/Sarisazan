import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Edit, Trash2, AlertCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";
import { format } from "date-fns-jalali";
import type { Tender, InsertTender } from "@shared/schema";

export default function TendersPage() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [editingTender, setEditingTender] = useState<Tender | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState<InsertTender>({
    title: "",
    city: "",
    amount: "",
    announcedDate: "",
    deadlineDate: "",
    client: "",
    companies: "",
    status: "در انتظار بررسی",
    notes: "",
  });

  const { data: tenders = [], isLoading } = useQuery<Tender[]>({
    queryKey: ["/api/tenders"],
    queryFn: async () => {
      const response = await fetch("/api/tenders");
      if (!response.ok) throw new Error("خطا در دریافت مناقصات");
      return response.json();
    },
  });

  const createTenderMutation = useMutation({
    mutationFn: async (data: InsertTender) => {
      const response = await fetch("/api/tenders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ایجاد مناقصه");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenders"] });
      setOpen(false);
      resetForm();
      toast({
        title: "موفقیت",
        description: "مناقصه جدید با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const updateTenderMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: InsertTender }) => {
      const response = await fetch(`/api/tenders/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ویرایش مناقصه");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenders"] });
      setOpen(false);
      resetForm();
      toast({
        title: "موفقیت",
        description: "مناقصه با موفقیت ویرایش شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const deleteTenderMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/tenders/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("خطا در حذف مناقصه");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenders"] });
      toast({
        title: "موفقیت",
        description: "مناقصه با موفقیت حذف شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      city: "",
      amount: "",
      announcedDate: "",
      deadlineDate: "",
      client: "",
      companies: "",
      status: "در انتظار بررسی",
      notes: "",
    });
    setEditingTender(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTender) {
      updateTenderMutation.mutate({ id: editingTender.id, data: formData });
    } else {
      createTenderMutation.mutate(formData);
    }
  };

  const handleEdit = (tender: Tender) => {
    setEditingTender(tender);
    setFormData({
      title: tender.title,
      city: tender.city || "",
      amount: tender.amount || "",
      announcedDate: tender.announcedDate || "",
      deadlineDate: tender.deadlineDate || "",
      client: tender.client || "",
      companies: tender.companies || "",
      status: tender.status || "در انتظار بررسی",
      notes: tender.notes || "",
    });
    setOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("آیا از حذف این مناقصه اطمینان دارید؟")) {
      deleteTenderMutation.mutate(id);
    }
  };

  const getDeadlineAlert = (deadlineDate: string | null) => {
    if (!deadlineDate) return null;
    
    const deadline = new Date(deadlineDate);
    const now = new Date();
    const diffTime = deadline.getTime() - now.getTime();
    const diffHours = diffTime / (1000 * 60 * 60);

    if (diffHours < 0) {
      return { type: "expired", message: "مهلت گذشته", icon: AlertCircle };
    } else if (diffHours < 48) {
      return { type: "urgent", message: "مهلت نزدیک است", icon: Clock };
    }
    return null;
  };

  const getReviewAlert = (tender: Tender) => {
    if (tender.status === "بررسی شده" || !tender.createdAt) return null;
    
    const created = new Date(tender.createdAt);
    const now = new Date();
    const diffTime = now.getTime() - created.getTime();
    const diffHours = diffTime / (1000 * 60 * 60);

    if (diffHours > 24) {
      return { type: "review", message: "نیاز به بررسی", icon: AlertCircle };
    }
    return null;
  };

  const filteredTenders = useMemo(
    () => tenders.filter((tender) => {
      const matchesSearch = tender.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tender.city?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tender.client?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "all" || tender.status === statusFilter;
      return matchesSearch && matchesStatus;
    }),
    [tenders, searchQuery, statusFilter]
  );

  const sortedTenders = useMemo(
    () => [...filteredTenders].sort((a, b) => {
      if (!a.deadlineDate) return 1;
      if (!b.deadlineDate) return -1;
      return new Date(a.deadlineDate).getTime() - new Date(b.deadlineDate).getTime();
    }),
    [filteredTenders]
  );

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">مناقصات</h1>
          <p className="text-muted-foreground">مدیریت مناقصات و فرصت‌های تجاری</p>
        </div>
        <Dialog open={open} onOpenChange={(isOpen) => {
          setOpen(isOpen);
          if (!isOpen) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 ml-2" />
              مناقصه جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingTender ? "ویرایش مناقصه" : "ایجاد مناقصه جدید"}</DialogTitle>
              <DialogDescription>
                اطلاعات مناقصه را وارد کنید
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="title">عنوان مناقصه *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="city">شهر / محل پروژه</Label>
                  <Input
                    id="city"
                    value={formData.city || ""}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="client">مناقصه‌گزار / کارفرما</Label>
                  <Input
                    id="client"
                    value={formData.client || ""}
                    onChange={(e) => setFormData({ ...formData, client: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="amount">مبلغ تقریبی (ریال)</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={formData.amount || ""}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="status">وضعیت بررسی</Label>
                  <Select
                    value={formData.status || "در انتظار بررسی"}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="در انتظار بررسی">در انتظار بررسی</SelectItem>
                      <SelectItem value="بررسی شده">بررسی شده</SelectItem>
                      <SelectItem value="شرکت کرده">شرکت کرده</SelectItem>
                      <SelectItem value="برنده">برنده</SelectItem>
                      <SelectItem value="رد شده">رد شده</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="announcedDate">تاریخ اعلام</Label>
                  <Input
                    id="announcedDate"
                    type="text"
                    value={formData.announcedDate || ""}
                    onChange={(e) => setFormData({ ...formData, announcedDate: e.target.value })}
                    placeholder="1403/07/15"
                  />
                </div>
                <div>
                  <Label htmlFor="deadlineDate">مهلت نهایی</Label>
                  <Input
                    id="deadlineDate"
                    type="text"
                    value={formData.deadlineDate || ""}
                    onChange={(e) => setFormData({ ...formData, deadlineDate: e.target.value })}
                    placeholder="1403/08/01"
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="companies">شرکت‌های شرکت‌کننده (با کاما جدا کنید)</Label>
                  <Input
                    id="companies"
                    value={formData.companies || ""}
                    onChange={(e) => setFormData({ ...formData, companies: e.target.value })}
                    placeholder="شرکت الف، شرکت ب، شرکت ج"
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="notes">یادداشت‌ها</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes || ""}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createTenderMutation.isPending || updateTenderMutation.isPending}>
                  {editingTender ? "ویرایش" : "ایجاد"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجو بر اساس عنوان، شهر یا مناقصه‌گزار..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            <SelectItem value="در انتظار بررسی">در انتظار بررسی</SelectItem>
            <SelectItem value="بررسی شده">بررسی شده</SelectItem>
            <SelectItem value="شرکت کرده">شرکت کرده</SelectItem>
            <SelectItem value="برنده">برنده</SelectItem>
            <SelectItem value="رد شده">رد شده</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">در حال بارگذاری...</div>
      ) : sortedTenders.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          {searchQuery || statusFilter !== "all" ? "مناقصه‌ای یافت نشد" : "هنوز مناقصه‌ای ثبت نشده است"}
        </div>
      ) : (
        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">عنوان</TableHead>
                <TableHead className="text-right">شهر</TableHead>
                <TableHead className="text-right">مناقصه‌گزار</TableHead>
                <TableHead className="text-right">مبلغ (ریال)</TableHead>
                <TableHead className="text-right">تاریخ اعلام</TableHead>
                <TableHead className="text-right">مهلت</TableHead>
                <TableHead className="text-right">وضعیت</TableHead>
                <TableHead className="text-right">هشدارها</TableHead>
                <TableHead className="text-right">عملیات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedTenders.map((tender) => {
                const deadlineAlert = getDeadlineAlert(tender.deadlineDate);
                const reviewAlert = getReviewAlert(tender);
                const DeadlineIcon = deadlineAlert?.icon;
                const ReviewIcon = reviewAlert?.icon;

                return (
                  <TableRow key={tender.id}>
                    <TableCell className="font-medium">{tender.title}</TableCell>
                    <TableCell>{tender.city || "-"}</TableCell>
                    <TableCell>{tender.client || "-"}</TableCell>
                    <TableCell>
                      {tender.amount ? formatCurrency(tender.amount) : "-"}
                    </TableCell>
                    <TableCell>
                      {tender.announcedDate ? toPersianDigits(format(new Date(tender.announcedDate), "yyyy/MM/dd")) : "-"}
                    </TableCell>
                    <TableCell>
                      {tender.deadlineDate ? toPersianDigits(format(new Date(tender.deadlineDate), "yyyy/MM/dd")) : "-"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={
                        tender.status === "برنده" ? "default" :
                        tender.status === "بررسی شده" ? "secondary" :
                        tender.status === "رد شده" ? "destructive" :
                        "outline"
                      }>
                        {tender.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {deadlineAlert && DeadlineIcon && (
                          <Badge variant={deadlineAlert.type === "expired" ? "destructive" : "default"} className="text-xs">
                            <DeadlineIcon className="w-3 h-3 ml-1" />
                            {deadlineAlert.message}
                          </Badge>
                        )}
                        {reviewAlert && ReviewIcon && (
                          <Badge variant="outline" className="text-xs">
                            <ReviewIcon className="w-3 h-3 ml-1" />
                            {reviewAlert.message}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(tender)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(tender.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
