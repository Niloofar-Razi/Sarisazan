import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Bell } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export type PageTheme = 
  | "dashboard" 
  | "projects" 
  | "tasks" 
  | "users" 
  | "notes" 
  | "sheets" 
  | "tenders" 
  | "alerts"
  | "calendar"
  | "letters";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  theme: PageTheme;
  actions?: ReactNode;
  children?: ReactNode;
  className?: string;
}

const themeColors: Record<PageTheme, string> = {
  dashboard: "bg-page-dashboard",
  projects: "bg-page-projects",
  tasks: "bg-page-tasks",
  users: "bg-page-users",
  notes: "bg-page-notes",
  sheets: "bg-page-sheets",
  tenders: "bg-page-tenders",
  alerts: "bg-page-alerts",
  calendar: "bg-page-dashboard",
  letters: "bg-page-dashboard",
};

export function PageHeader({
  title,
  subtitle,
  theme,
  actions,
  children,
  className,
}: PageHeaderProps) {
  const { data: needsAction } = useQuery({
    queryKey: ['/api/needs-action'],
    queryFn: async () => {
      const res = await fetch('/api/needs-action');
      if (!res.ok) return { count: 0, items: [] };
      return res.json();
    },
    refetchInterval: 30000,
  });

  const actionCount = needsAction?.count || 0;

  return (
    <div className={cn("w-full", className)}>
      {/* Main header bar - simple design without colored background */}
      <div className="px-6 py-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{title}</h1>
            {subtitle && (
              <p className="text-muted-foreground text-sm mt-1">{subtitle}</p>
            )}
          </div>
          
          <div className="flex items-center gap-4">
            {/* Needs Action Badge */}
            {actionCount > 0 && (
              <button className="flex items-center gap-2 px-3 py-1.5 bg-muted hover:bg-muted/80 rounded-lg transition-colors">
                <Bell className="w-4 h-4" />
                <span className="text-sm font-medium">نیاز به اقدام</span>
                <Badge variant="destructive">
                  {actionCount}
                </Badge>
              </button>
            )}
            
            {actions && (
              <div className="flex items-center gap-2">
                {actions}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Additional content below header */}
      {children && (
        <div className="px-6 py-3 border-b">
          {children}
        </div>
      )}
    </div>
  );
}
