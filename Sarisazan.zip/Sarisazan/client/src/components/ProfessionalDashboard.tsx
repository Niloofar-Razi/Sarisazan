import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toPersianDigits } from "@/lib/persian-utils";
import { FolderKanban, TrendingUp, Activity, AlertTriangle, CheckCircle } from "lucide-react";
import type { Project, Alert, Task } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function ProfessionalDashboard() {
  // Fetch projects
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  // Fetch alerts
  const { data: alerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    queryFn: async () => {
      const response = await fetch("/api/alerts");
      if (!response.ok) throw new Error("خطا در دریافت هشدارها");
      return response.json();
    },
  });

  // Fetch tasks
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const response = await fetch("/api/tasks");
      if (!response.ok) throw new Error("خطا در دریافت وظایف");
      return response.json();
    },
  });

  // Calculate analytics
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === "در حال اجرا").length;
  const completedProjects = projects.filter(p => p.status === "تکمیل شده").length;
  const averageProgress = projects.length > 0
    ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
    : 0;

  const openAlerts = alerts.filter(a => a.status === "باز").length;
  const completedTasks = tasks.filter(t => t.isCompleted).length;
  const totalTasks = tasks.length;

  // Project progress data for chart
  const projectProgressData = projects
    .slice(0, 10)
    .map(p => ({
      name: p.title.length > 20 ? p.title.substring(0, 20) + "..." : p.title,
      progress: p.progress || 0,
    }));

  // Project status distribution
  const statusDistribution = [
    { name: "در حال اجرا", value: activeProjects, color: "#22c55e" },
    { name: "تکمیل شده", value: completedProjects, color: "#3b82f6" },
    { name: "معلق", value: projects.filter(p => p.status === "معلق").length, color: "#f59e0b" },
  ].filter(s => s.value > 0);

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">داشبورد تحلیلی</h1>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-r-4 border-r-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">کل پروژه‌ها</CardTitle>
            <FolderKanban className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(totalProjects.toString())}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {toPersianDigits(activeProjects.toString())} پروژه فعال
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">میانگین پیشرفت</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(averageProgress.toString())}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              از کل پروژه‌ها
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">هشدارهای باز</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{toPersianDigits(openAlerts.toString())}</div>
            <p className="text-xs text-muted-foreground mt-1">
              نیاز به بررسی
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">وظایف</CardTitle>
            <CheckCircle className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {toPersianDigits(completedTasks.toString())}/{toPersianDigits(totalTasks.toString())}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              انجام شده
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Project Progress Chart */}
        <Card>
          <CardHeader>
            <CardTitle>پیشرفت پروژه‌ها</CardTitle>
          </CardHeader>
          <CardContent>
            {projectProgressData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={projectProgressData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" domain={[0, 100]} />
                  <YAxis type="category" dataKey="name" width={150} />
                  <Tooltip />
                  <Bar dataKey="progress" fill="#3b82f6" name="درصد پیشرفت" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                هیچ پروژه‌ای یافت نشد
              </div>
            )}
          </CardContent>
        </Card>

        {/* Project Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>توزیع وضعیت پروژه‌ها</CardTitle>
          </CardHeader>
          <CardContent>
            {statusDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${toPersianDigits(value.toString())}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                هیچ پروژه‌ای یافت نشد
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Projects Table */}
      <Card>
        <CardHeader>
          <CardTitle>پروژه‌های اخیر</CardTitle>
        </CardHeader>
        <CardContent>
          {projects.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-right p-2">نام پروژه</th>
                    <th className="text-right p-2">پیمانکار</th>
                    <th className="text-right p-2">وضعیت</th>
                    <th className="text-right p-2">پیشرفت</th>
                  </tr>
                </thead>
                <tbody>
                  {projects.slice(0, 10).map((project) => (
                    <tr key={project.id} className="border-b hover:bg-muted/50">
                      <td className="p-2">{project.title}</td>
                      <td className="p-2">{project.contractor || "—"}</td>
                      <td className="p-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          project.status === "در حال اجرا" ? "bg-green-100 text-green-800" :
                          project.status === "تکمیل شده" ? "bg-blue-100 text-blue-800" :
                          "bg-orange-100 text-orange-800"
                        }`}>
                          {project.status}
                        </span>
                      </td>
                      <td className="p-2">
                        {toPersianDigits((project.progress || 0).toString())}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              هیچ پروژه‌ای یافت نشد
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
