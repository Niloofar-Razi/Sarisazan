import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toPersianDigits } from "@/lib/persian-utils";
import type { Project } from "@shared/schema";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Clock,
  DollarSign,
  Users,
  FileText,
  AlertCircle,
  RefreshCw,
} from "lucide-react";

interface Statement {
  id: string;
  projectId: string;
  periodNumber: number;
  status: string;
  amount?: string;
  approvedAt?: Date;
}

interface Adjustment {
  id: string;
  projectId: string;
  status: string;
  amount?: string;
  indexAdjustment?: string;
}

interface BitumenRecord {
  id: string;
  projectId: string;
  quantity?: string;
  unitPrice?: string;
  totalAmount?: string;
}

interface AgentAnalysis {
  progressReport: {
    summary: string;
    criticalProjects: string[];
    recommendations: string[];
  };
  financialAnalysis: {
    summary: string;
    budgetStatus: string;
    statementsCount: string;
    adjustmentsInsight: string;
    bitumenInsight: string;
    recommendations: string[];
  };
  delayPredictions: {
    summary: string;
    atRiskProjects: Array<{ name: string; risk: string; reason: string }>;
    recommendations: string[];
  };
  resourceManagement: {
    summary: string;
    needs: Array<{ project: string; resource: string }>;
    recommendations: string[];
  };
  statementsStatus: {
    summary: string;
    pending: string;
    approved: string;
    insights: string[];
  };
}

export default function ProfessionalDashboard() {
  const [analysis, setAnalysis] = useState<AgentAnalysis | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { data: projects = [], isSuccess: projectsLoaded } = useQuery<
    Project[]
  >({
    queryKey: ["/api/projects"],
  });

  const { data: statements = [], isSuccess: statementsLoaded } = useQuery<
    Statement[]
  >({
    queryKey: ["/api/statements"],
  });

  const { data: adjustments = [], isSuccess: adjustmentsLoaded } = useQuery<
    Adjustment[]
  >({
    queryKey: ["/api/adjustments"],
  });

  const { data: bitumen = [], isSuccess: bitumenLoaded } = useQuery<
    BitumenRecord[]
  >({
    queryKey: ["/api/bitumen"],
  });

  const allDataReady =
    projectsLoaded && statementsLoaded && adjustmentsLoaded && bitumenLoaded;

  useEffect(() => {
    if (
      allDataReady &&
      projects.length > 0 &&
      !analysis &&
      !isLoadingAnalysis
    ) {
      fetchAgentAnalysis();
    }
  }, [allDataReady, projects.length]);

  const fetchAgentAnalysis = async () => {
    setIsLoadingAnalysis(true);
    setError(null);
    try {
      const activeProjects = projects.filter((p) => p.status === "active");
      const completedProjects = projects.filter(
        (p) => p.status === "completed",
      );
      const lowProgressProjects = activeProjects.filter(
        (p) => (p.progress || 0) < 50,
      );

      const pendingStatements = statements.filter(
        (s) => s.status === "pending",
      ).length;
      const approvedStatements = statements.filter(
        (s) => s.status === "approved",
      ).length;
      const pendingAdjustments = adjustments.filter(
        (a) => a.status === "pending",
      ).length;

      const totalBitumenQty = bitumen.reduce(
        (sum, b) => sum + parseFloat(b.quantity || "0"),
        0,
      );

      const prompt = `تحلیل ${projects.length} پروژه (فعال:${activeProjects.length}, تکمیل:${completedProjects.length}, پیشرفت<50%:${lowProgressProjects.length})
📊 صورت‌وضعیت: ${statements.length} (انتظار:${pendingStatements}, تأیید:${approvedStatements})
💰 تعدیل‌ها: ${adjustments.length} (انتظار:${pendingAdjustments})
🛢️ قیر: ${bitumen.length} رکورد، ${Math.round(totalBitumenQty)} تن

فرمت JSON (فقط داده‌های کلیدی برای بهینه‌سازی توکن):
{
  "progress": {"sum":"خلاصه","critical":["پ1","پ2"],"rec":["ر1"]},
  "financial": {"sum":"مالی","budget":"بودجه","stmt":"صورت‌وضعیت","adj":"تعدیل","bit":"قیر","rec":["ر"]},
  "delay": {"sum":"تأخیر","risks":[{"n":"پروژه","r":"بالا","why":"دلیل"}],"rec":["ر"]},
  "resource": {"sum":"منابع","needs":[{"p":"پروژه","r":"نیاز"}],"rec":["ر"]},
  "statements": {"sum":"وضعیت","pend":"${pendingStatements}","app":"${approvedStatements}","ins":["نکته"]}
}`;

      const response = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: prompt,
          mode: "general",
        }),
      });

      if (!response.ok) throw new Error("خطا در دریافت تحلیل");

      const data = await response.json();

      let parsed: any = {};
      try {
        const jsonMatch = data.response.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[0]);
        }
      } catch (e) {
        console.error("JSON parse error:", e);
      }

      const prog = parsed.progress || {};
      const fin = parsed.financial || {};
      const del = parsed.delay || {};
      const res = parsed.resource || {};
      const stmt = parsed.statements || {};

      setAnalysis({
        progressReport: {
          summary: prog.sum || data.response.substring(0, 200),
          criticalProjects:
            prog.critical ||
            lowProgressProjects.slice(0, 3).map((p) => p.title || ""),
          recommendations: prog.rec || [
            "تخصیص منابع بیشتر",
            "بررسی دقیق پروژه‌های عقب‌مانده",
          ],
        },
        financialAnalysis: {
          summary:
            fin.sum ||
            `تحلیل ${statements.length} صورت‌وضعیت، ${adjustments.length} تعدیل و ${bitumen.length} رکورد قیر`,
          budgetStatus: fin.budget || "بررسی مستمر وضعیت بودجه پروژه‌ها",
          statementsCount: `${statements.length} صورت‌وضعیت کل (${pendingStatements} در انتظار، ${approvedStatements} تأیید شده)`,
          adjustmentsInsight: `${adjustments.length} تعدیل قیمت ثبت شده${pendingAdjustments > 0 ? ` (${pendingAdjustments} در انتظار تأیید)` : ""}`,
          bitumenInsight: `${bitumen.length} رکورد قیر${totalBitumenQty > 0 ? `, مجموع حدود ${Math.round(totalBitumenQty)} تن` : ""}`,
          recommendations: fin.rec || ["پیگیری صورت‌وضعیت‌های در انتظار تأیید"],
        },
        delayPredictions: {
          summary:
            del.sum || `${lowProgressProjects.length} پروژه در معرض خطر تأخیر`,
          atRiskProjects:
            (del.risks || []).length > 0
              ? del.risks
              : lowProgressProjects.slice(0, 5).map((p) => ({
                  name: p.title || "",
                  risk: (p.progress || 0) < 30 ? "بالا" : "متوسط",
                  reason: `پیشرفت ${p.progress}٪ - نیاز فوری به اقدام`,
                })),
          recommendations: del.rec || ["تسریع عملیات در پروژه‌های عقب‌مانده"],
        },
        resourceManagement: {
          summary: res.sum || "بررسی نیازهای منابع پروژه‌های فعال",
          needs:
            (res.needs || []).length > 0
              ? res.needs
              : lowProgressProjects.slice(0, 4).map((p) => ({
                  project: p.title || "",
                  resource:
                    (p.progress || 0) < 30
                      ? "نیروی کار و تجهیزات (فوری)"
                      : "بررسی تخصیص منابع",
                })),
          recommendations: res.rec || [
            "اولویت‌بندی منابع برای پروژه‌های کلیدی",
          ],
        },
        statementsStatus: {
          summary:
            stmt.sum ||
            `وضعیت صورت‌وضعیت‌ها: ${pendingStatements} در انتظار، ${approvedStatements} تأیید شده`,
          pending: toPersianDigits(pendingStatements.toString()),
          approved: toPersianDigits(approvedStatements.toString()),
          insights: stmt.ins || [
            `مجموع ${statements.length} صورت‌وضعیت ثبت شده`,
            `${adjustments.length} تعدیل قیمت در سیستم`,
            `${bitumen.length} رکورد قیر ثبت شده${totalBitumenQty > 0 ? ` (${Math.round(totalBitumenQty)} تن)` : ""}`,
          ],
        },
      });
    } catch (error: any) {
      console.error("Error:", error);
      setError(error.message);
    } finally {
      setIsLoadingAnalysis(false);
    }
  };

  const riskChart = [
    {
      name: "خطر بالا (<30%)",
      value: projects.filter((p) => (p.progress || 0) < 30).length,
      color: "#ef4444",
    },
    {
      name: "خطر متوسط (30-50%)",
      value: projects.filter(
        (p) => (p.progress || 0) >= 30 && (p.progress || 0) < 50,
      ).length,
      color: "#f59e0b",
    },
    {
      name: "در مسیر (50-99%)",
      value: projects.filter(
        (p) => (p.progress || 0) >= 50 && (p.progress || 0) < 100,
      ).length,
      color: "#10b981",
    },
    {
      name: "تکمیل شده",
      value: projects.filter((p) => (p.progress || 0) >= 100).length,
      color: "#3b82f6",
    },
  ];

  return (
    <div className="space-y-6 p-6 bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">داشبورد تحلیلی هوشمند</h1>
          <p className="text-muted-foreground">
            تحلیل جامع با ایجنت AI (بهینه‌سازی شده برای مصرف توکن)
          </p>
        </div>
        <Button
          onClick={fetchAgentAnalysis}
          disabled={isLoadingAnalysis}
          className="gap-2"
        >
          {isLoadingAnalysis ? "در حال تحلیل..." : "تحلیل مجدد"}
          <RefreshCw
            className={`h-4 w-4 ${isLoadingAnalysis ? "animate-spin" : ""}`}
          />
        </Button>
      </div>

      {/* Error */}
      {error && (
        <Card className="border-red-200 bg-red-50 dark:bg-red-950/20">
          <CardContent className="pt-6 flex items-center gap-2 text-red-600">
            <AlertCircle className="h-5 w-5" />
            <span>{error} - نمایش داده‌های محلی</span>
          </CardContent>
        </Card>
      )}

      {/* Loading */}
      {isLoadingAnalysis && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Analysis Results */}
      {analysis && (
        <Tabs defaultValue="progress" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto">
            <TabsTrigger value="progress">
              <TrendingUp className="h-4 w-4 mr-2" />
              پیشرفت
            </TabsTrigger>
            <TabsTrigger value="financial">
              <DollarSign className="h-4 w-4 mr-2" />
              مالی
            </TabsTrigger>
            <TabsTrigger value="delays">
              <Clock className="h-4 w-4 mr-2" />
              تأخیرات
            </TabsTrigger>
            <TabsTrigger value="resources">
              <Users className="h-4 w-4 mr-2" />
              منابع
            </TabsTrigger>
            <TabsTrigger value="statements">
              <FileText className="h-4 w-4 mr-2" />
              صورت‌وضعیت
            </TabsTrigger>
          </TabsList>

          {/* Progress Tab */}
          <TabsContent value="progress" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>گزارش پیشرفت پروژه‌ها</CardTitle>
              </CardHeader>
              <CardContent>
                {/* نمایش درصد پیشرفت پروژه‌ها */}
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={projects}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="progress"
                      fill="#82ca9d"
                      label={{
                        position: "insideLeft",
                        angle: -90,
                        style: { textAnchor: "middle" },
                      }}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
