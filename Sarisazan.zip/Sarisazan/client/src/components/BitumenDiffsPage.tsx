import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Droplet, TrendingUp } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns-jalali";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";

type BitumenDiff = {
  id: string;
  projectId: string;
  number: string;
  amount: string;
  status: string;
  startDate?: string | null;
  endDate?: string | null;
  filePath?: string | null;
  notes?: string | null;
  createdAt: string;
};

type Project = {
  id: string;
  title: string;
  contractNumber?: string | null;
  contractDate?: string | null;
  employer?: string | null;
  contractor?: string | null;
  amount?: string | null;
};

const statuses = [
  { value: "تأیید شده", label: "تأیید شده", color: "bg-green-500" },
  { value: "ابلاغ شده", label: "ابلاغ شده", color: "bg-blue-500" },
  { value: "ارسال‌شده به کارفرما", label: "ارسال‌شده به کارفرما", color: "bg-cyan-500" },
  { value: "ارسال‌شده به مشاور", label: "ارسال‌شده به مشاور", color: "bg-indigo-500" },
  { value: "در انتظار", label: "در انتظار", color: "bg-yellow-500" },
  { value: "موقت", label: "موقت", color: "bg-amber-500" },
];

export default function BitumenDiffsPage() {
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [bitumenDiffDialog, setBitumenDiffDialog] = useState(false);
  const [editingBitumenDiff, setEditingBitumenDiff] = useState<BitumenDiff | null>(null);

  const queryClient = useQueryClient();

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: bitumenDiffs = [] } = useQuery<BitumenDiff[]>({
    queryKey: ["/api/bitumen-diffs", { projectId: selectedProject, status: statusFilter === "all" ? undefined : statusFilter }],
    enabled: selectedProject !== "",
  });

  const selectedProjectData = useMemo(
    () => projects.find(p => p.id === selectedProject),
    [projects, selectedProject]
  );

  const filteredBitumenDiffs = useMemo(
    () => bitumenDiffs.filter(b =>
      b.number.includes(searchTerm) ||
      b.notes?.includes(searchTerm)
    ),
    [bitumenDiffs, searchTerm]
  );

  const bitumenDiffsSum = useMemo(
    () => filteredBitumenDiffs.reduce((sum, b) => sum + parseFloat(b.amount || "0"), 0),
    [filteredBitumenDiffs]
  );

  const approvedBitumenDiffsSum = useMemo(
    () => bitumenDiffs.filter(b => b.status === "تأیید شده")
      .reduce((sum, b) => sum + parseFloat(b.amount || "0"), 0),
    [bitumenDiffs]
  );

  const createBitumenDiffMutation = useMutation({
    mutationFn: async (data: Partial<BitumenDiff>) => {
      const response = await fetch("/api/bitumen-diffs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen-diffs"] });
      setBitumenDiffDialog(false);
      setEditingBitumenDiff(null);
      toast({ title: "مابه‌التفاوت قیر با موفقیت ثبت شد" });
    },
  });

  const updateBitumenDiffMutation = useMutation({
    mutationFn: async (data: BitumenDiff) => {
      const response = await fetch(`/api/bitumen-diffs/${data.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen-diffs"] });
      setBitumenDiffDialog(false);
      setEditingBitumenDiff(null);
      toast({ title: "مابه‌التفاوت قیر به‌روزرسانی شد" });
    },
  });

  const deleteBitumenDiffMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/bitumen-diffs/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen-diffs"] });
      toast({ title: "مابه‌التفاوت قیر حذف شد" });
    },
  });

  const handleBitumenDiffSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      projectId: selectedProject,
      number: formData.get("number") as string,
      amount: formData.get("amount") as string,
      status: formData.get("status") as string,
      startDate: formData.get("startDate") as string || null,
      endDate: formData.get("endDate") as string || null,
      notes: formData.get("notes") as string || null,
    };

    if (editingBitumenDiff) {
      updateBitumenDiffMutation.mutate({ ...editingBitumenDiff, ...data });
    } else {
      createBitumenDiffMutation.mutate(data);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusInfo = statuses.find(s => s.value === status);
    return (
      <Badge className={statusInfo?.color || "bg-gray-500"}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">مابه‌التفاوت قیر</h1>
          <p className="text-muted-foreground mt-1">مدیریت و ثبت مابه‌التفاوت‌های قیر پروژه‌ها</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>انتخاب پروژه</Label>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger>
                  <SelectValue placeholder="پروژه را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>جست‌وجو</Label>
              <Input
                placeholder="شماره یا توضیحات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div>
              <Label>وضعیت</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="همه" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  {statuses.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedProjectData && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-r-4 border-r-purple-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">کل مابه‌التفاوت‌ها</CardTitle>
              <Droplet className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{toPersianDigits(filteredBitumenDiffs.length.toString())}</div>
              <p className="text-xs text-muted-foreground mt-1">رکورد ثبت شده</p>
            </CardContent>
          </Card>

          <Card className="border-r-4 border-r-emerald-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">مابه‌التفاوت تأیید شده</CardTitle>
              <TrendingUp className="h-4 w-4 text-emerald-500" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${approvedBitumenDiffsSum < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                {formatCurrency((approvedBitumenDiffsSum / 1000000000).toFixed(1))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">میلیارد ریال</p>
            </CardContent>
          </Card>

          <Card className="border-r-4 border-r-blue-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">جمع کل</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${bitumenDiffsSum < 0 ? 'text-red-600' : 'text-blue-600'}`}>
                {formatCurrency((bitumenDiffsSum / 1000000000).toFixed(1))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">میلیارد ریال</p>
            </CardContent>
          </Card>
        </div>
      )}

      {selectedProject && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>لیست مابه‌التفاوت‌های قیر</CardTitle>
              <Button onClick={() => { setEditingBitumenDiff(null); setBitumenDiffDialog(true); }}>
                <Plus className="ml-2 h-4 w-4" />
                افزودن مابه‌التفاوت
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">ردیف</TableHead>
                  <TableHead className="text-right">شماره</TableHead>
                  <TableHead className="text-right">مبلغ (ریال)</TableHead>
                  <TableHead className="text-right">وضعیت</TableHead>
                  <TableHead className="text-right">تاریخ شروع</TableHead>
                  <TableHead className="text-right">تاریخ پایان</TableHead>
                  <TableHead className="text-right">تاریخ ثبت</TableHead>
                  <TableHead className="text-right">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBitumenDiffs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground">
                      هیچ مابه‌التفاوتی یافت نشد
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredBitumenDiffs.map((bitumenDiff, index) => (
                    <TableRow key={bitumenDiff.id}>
                      <TableCell>{toPersianDigits((index + 1).toString())}</TableCell>
                      <TableCell className="font-medium">{toPersianDigits(bitumenDiff.number)}</TableCell>
                      <TableCell className={parseFloat(bitumenDiff.amount) < 0 ? 'text-red-600 font-semibold' : 'font-semibold'}>
                        {formatCurrency(bitumenDiff.amount)}
                      </TableCell>
                      <TableCell>{getStatusBadge(bitumenDiff.status)}</TableCell>
                      <TableCell>{bitumenDiff.startDate ? toPersianDigits(bitumenDiff.startDate) : "-"}</TableCell>
                      <TableCell>{bitumenDiff.endDate ? toPersianDigits(bitumenDiff.endDate) : "-"}</TableCell>
                      <TableCell>{toPersianDigits(format(new Date(bitumenDiff.createdAt), 'yyyy/MM/dd'))}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setEditingBitumenDiff(bitumenDiff);
                              setBitumenDiffDialog(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              if (confirm("آیا از حذف این مابه‌التفاوت مطمئن هستید؟")) {
                                deleteBitumenDiffMutation.mutate(bitumenDiff.id);
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            {filteredBitumenDiffs.length > 0 && (
              <div className="mt-4 flex justify-end">
                <div className="text-lg font-bold">
                  جمع کل: <span className={bitumenDiffsSum < 0 ? 'text-red-600' : 'text-purple-600'}>
                    {formatCurrency(bitumenDiffsSum.toString())} ریال
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Dialog open={bitumenDiffDialog} onOpenChange={setBitumenDiffDialog}>
        <DialogContent className="max-w-2xl" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingBitumenDiff ? "ویرایش مابه‌التفاوت قیر" : "افزودن مابه‌التفاوت قیر"}</DialogTitle>
            <DialogDescription>اطلاعات مابه‌التفاوت قیر را وارد کنید</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleBitumenDiffSubmit} className="space-y-4">
            <div>
              <Label htmlFor="number">شماره</Label>
              <Input id="number" name="number" defaultValue={editingBitumenDiff?.number} required />
            </div>
            <div>
              <Label htmlFor="amount">مبلغ (ریال)</Label>
              <Input id="amount" name="amount" type="number" step="0.01" defaultValue={editingBitumenDiff?.amount} required />
              <p className="text-xs text-muted-foreground mt-1">مبلغ منفی برای کسر از مبلغ قرارداد وارد کنید</p>
            </div>
            <div>
              <Label htmlFor="status">وضعیت</Label>
              <Select name="status" defaultValue={editingBitumenDiff?.status || "در انتظار"}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statuses.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate">تاریخ شروع</Label>
                <Input id="startDate" name="startDate" type="text" placeholder="1403/07/01" defaultValue={editingBitumenDiff?.startDate || ""} />
              </div>
              <div>
                <Label htmlFor="endDate">تاریخ پایان</Label>
                <Input id="endDate" name="endDate" type="text" placeholder="1403/07/15" defaultValue={editingBitumenDiff?.endDate || ""} />
              </div>
            </div>
            <div>
              <Label htmlFor="notes">یادداشت</Label>
              <Textarea id="notes" name="notes" rows={3} defaultValue={editingBitumenDiff?.notes || ""} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setBitumenDiffDialog(false)}>انصراف</Button>
              <Button type="submit">ذخیره</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
