import DashboardCard from "./DashboardCard";
import ProjectCard from "./ProjectCard";
import AlertCard from "./AlertCard";
import { FolderKanban, Bell, TrendingUp, Activity } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import type { Project } from "@shared/schema";
import { useProject } from "@/lib/project-context";
import { useLocation } from "wouter";
import { useMemo } from "react";
import { toPersianDigits } from "@/lib/persian-utils";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line 
} from "recharts";

interface Alert {
  id: string;
  title: string;
  description?: string;
  severity: string;
  status: string;
  createdAt: Date;
  project?: {
    id: string;
    title: string;
  };
}

export default function Dashboard() {
  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const { data: alerts = [], isLoading: alertsLoading } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    queryFn: async () => {
      const response = await fetch("/api/alerts");
      if (!response.ok) throw new Error("خطا در دریافت هشدارها");
      return response.json();
    },
  });

  const [, setLocation] = useLocation();

  const handleViewDetails = (id: string) => {
    setLocation(`/projects/${id}`);
  };

  const kpis = useMemo(() => {
    const totalProjects = projects.length;
    const activeProjects = projects.filter(p => p.status === 'active').length;
    const openAlerts = alerts.filter(a => a.status === 'open').length;
    const avgProgress = projects.length > 0 
      ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
      : 0;

    return { totalProjects, activeProjects, openAlerts, avgProgress };
  }, [projects, alerts]);

  const openAlerts = useMemo(() => {
    return alerts.filter(a => a.status === 'open');
  }, [alerts]);

  const chartData = useMemo(() => {
    const alertsByLevel = alerts.reduce((acc, alert) => {
      const level = alert.severity === 'critical' ? 'بحرانی' :
                    alert.severity === 'warning' ? 'هشدار' : 'اطلاعات';
      acc[level] = (acc[level] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const alertsData = [
      { name: 'اطلاعات', value: alertsByLevel['اطلاعات'] || 0 },
      { name: 'هشدار', value: alertsByLevel['هشدار'] || 0 },
      { name: 'بحرانی', value: alertsByLevel['بحرانی'] || 0 },
    ];

    const projectProgressData = projects.map(p => ({
      name: p.title?.substring(0, 30) + (p.title && p.title.length > 30 ? '...' : ''),
      progress: p.progress || 0
    }));

    const statusDistribution = projects.reduce((acc, project) => {
      const status = project.status === 'active' ? 'فعال' :
                     project.status === 'planning' ? 'در حال برنامه‌ریزی' : 'تکمیل شده';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const statusData = [
      { name: 'در حال برنامه‌ریزی', value: statusDistribution['در حال برنامه‌ریزی'] || 0 },
      { name: 'فعال', value: statusDistribution['فعال'] || 0 },
      { name: 'تکمیل شده', value: statusDistribution['تکمیل شده'] || 0 },
    ];

    return { alertsData, projectProgressData, statusData };
  }, [projects, alerts]);

  const COLORS = ['#3b82f6', '#eab308', '#ef4444'];
  const STATUS_COLORS = ['#f59e0b', '#10b981', '#6366f1'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">داشبورد</h1>
        <p className="text-muted-foreground">خلاصه وضعیت پروژه‌ها و فعالیت‌ها</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <DashboardCard
          title="تعداد کل پروژه‌ها"
          value={toPersianDigits(kpis.totalProjects.toString())}
          icon={FolderKanban}
          description="پروژه ثبت شده"
        />
        <DashboardCard
          title="پروژه‌های فعال"
          value={toPersianDigits(kpis.activeProjects.toString())}
          icon={Activity}
          description="پروژه در حال اجرا"
        />
        <DashboardCard
          title="هشدارهای باز"
          value={toPersianDigits(kpis.openAlerts.toString())}
          icon={Bell}
          description="نیاز به بررسی"
        />
        <DashboardCard
          title="میانگین پیشرفت"
          value={toPersianDigits(`${kpis.avgProgress}٪`)}
          icon={TrendingUp}
          description="پیشرفت کلی پروژه‌ها"
        />
      </div>

      <Tabs defaultValue="projects" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-2xl">
          <TabsTrigger value="projects" data-testid="tab-projects">پروژه‌های اخیر</TabsTrigger>
          <TabsTrigger value="alerts" data-testid="tab-alerts">هشدارها</TabsTrigger>
          <TabsTrigger value="analysis" data-testid="tab-analysis">تحلیل داده</TabsTrigger>
        </TabsList>
        
        <TabsContent value="projects" className="mt-6">
          {isLoading ? (
            <div className="text-center text-muted-foreground py-8">در حال بارگذاری...</div>
          ) : projects.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">هنوز پروژه‌ای ثبت نشده است</div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {projects.map((project) => (
                <ProjectCard
                  key={project.id}
                  {...project}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="alerts" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>هشدارهای باز</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {alertsLoading ? (
                <div className="text-center text-muted-foreground py-8">در حال بارگذاری...</div>
              ) : openAlerts.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">هشداری یافت نشد</div>
              ) : (
                openAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="flex items-start gap-3 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <div className={`p-2 rounded-lg ${
                      alert.severity === 'critical' ? 'bg-red-100 dark:bg-red-900/20' :
                      alert.severity === 'warning' ? 'bg-yellow-100 dark:bg-yellow-900/20' :
                      'bg-blue-100 dark:bg-blue-900/20'
                    }`}>
                      <Bell className={`w-4 h-4 ${
                        alert.severity === 'critical' ? 'text-red-600' :
                        alert.severity === 'warning' ? 'text-yellow-600' :
                        'text-blue-600'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold">{alert.title}</h4>
                      {alert.description && (
                        <p className="text-sm text-muted-foreground mt-1">{alert.description}</p>
                      )}
                      {alert.project && (
                        <p className="text-xs text-muted-foreground mt-2">
                          پروژه: {alert.project.title}
                        </p>
                      )}
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>توزیع هشدارها بر اساس سطح</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData.alertsData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="تعداد" fill="#8884d8">
                      {chartData.alertsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
                <p className="text-sm text-muted-foreground mt-4 text-center">
                  نمایش تعداد هشدارها در سطوح مختلف: اطلاعات، هشدار و بحرانی
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>وضعیت پروژه‌ها</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={chartData.statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => value > 0 ? `${name}: ${toPersianDigits(value.toString())}` : ''}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {chartData.statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={STATUS_COLORS[index % STATUS_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <p className="text-sm text-muted-foreground mt-4 text-center">
                  توزیع پروژه‌ها بر اساس وضعیت: در حال برنامه‌ریزی، فعال و تکمیل شده
                </p>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>درصد پیشرفت پروژه‌ها</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData.projectProgressData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" domain={[0, 100]} />
                    <YAxis dataKey="name" type="category" width={200} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="progress" name="پیشرفت (%)" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
                <p className="text-sm text-muted-foreground mt-4 text-center">
                  نمایش درصد پیشرفت هر پروژه به صورت نمودار میله‌ای افقی
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
