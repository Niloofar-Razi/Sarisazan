import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Edit, Trash2, AlertCircle, Download, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { toPersianDigits } from "@/lib/persian-utils";
import { format } from "date-fns-jalali";
import type { Alert, InsertAlert, Project } from "@shared/schema";

export default function AlertsPage() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [severityFilter, setSeverityFilter] = useState("all");
  const [projectFilter, setProjectFilter] = useState("all");
  const [editingAlert, setEditingAlert] = useState<Alert | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState<InsertAlert>({
    projectId: undefined,
    entityType: "",
    entityId: "",
    title: "",
    description: "",
    severity: "medium",
    status: "open",
    assigneeId: undefined,
    createdBy: undefined,
  });

  const { data: alerts = [], isLoading } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    queryFn: async () => {
      const response = await fetch("/api/alerts");
      if (!response.ok) throw new Error("خطا در دریافت هشدارها");
      return response.json();
    },
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const createAlertMutation = useMutation({
    mutationFn: async (data: InsertAlert) => {
      const response = await fetch("/api/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ایجاد هشدار");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      setOpen(false);
      resetForm();
      toast({
        title: "موفقیت",
        description: "هشدار جدید با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const updateAlertMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertAlert> }) => {
      const response = await fetch(`/api/alerts/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ویرایش هشدار");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      setOpen(false);
      resetForm();
      toast({
        title: "موفقیت",
        description: "هشدار با موفقیت ویرایش شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const deleteAlertMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/alerts/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("خطا در حذف هشدار");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({
        title: "موفقیت",
        description: "هشدار با موفقیت حذف شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingAlert) {
      updateAlertMutation.mutate({ id: editingAlert.id, data: formData });
    } else {
      createAlertMutation.mutate(formData);
    }
  };

  const handleEdit = (alert: Alert) => {
    setEditingAlert(alert);
    setFormData({
      projectId: alert.projectId || undefined,
      entityType: alert.entityType || "",
      entityId: alert.entityId || "",
      title: alert.title,
      description: alert.description || "",
      severity: alert.severity,
      status: alert.status,
      assigneeId: alert.assigneeId || undefined,
      createdBy: alert.createdBy || undefined,
    });
    setOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("آیا از حذف این هشدار اطمینان دارید؟")) {
      deleteAlertMutation.mutate(id);
    }
  };

  const handleStatusChange = (id: string, newStatus: string) => {
    updateAlertMutation.mutate({ id, data: { status: newStatus } });
  };

  const resetForm = () => {
    setFormData({
      projectId: undefined,
      entityType: "",
      entityId: "",
      title: "",
      description: "",
      severity: "medium",
      status: "open",
      assigneeId: undefined,
      createdBy: undefined,
    });
    setEditingAlert(null);
  };

  const handleDownloadCSV = async () => {
    try {
      const response = await fetch("/api/alerts/csv");
      if (!response.ok) throw new Error("خطا در دانلود فایل");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `alerts-${new Date().toISOString()}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "موفقیت",
        description: "فایل CSV با موفقیت دانلود شد",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "خطا",
        description: "خطا در دانلود فایل CSV",
      });
    }
  };

  const filteredAlerts = useMemo(
    () => alerts.filter((alert) => {
      const matchesSearch = alert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           alert.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "all" || alert.status === statusFilter;
      const matchesSeverity = severityFilter === "all" || alert.severity === severityFilter;
      const matchesProject = projectFilter === "all" || alert.projectId === projectFilter;
      
      return matchesSearch && matchesStatus && matchesSeverity && matchesProject;
    }),
    [alerts, searchQuery, statusFilter, severityFilter, projectFilter]
  );

  const getSeverityBadge = (severity: string) => {
    const variants: Record<string, { variant: "destructive" | "default" | "secondary" | "outline"; label: string }> = {
      low: { variant: "secondary", label: "کم" },
      medium: { variant: "default", label: "متوسط" },
      high: { variant: "outline", label: "بالا" },
      critical: { variant: "destructive", label: "بحرانی" },
    };
    const config = variants[severity] || variants.medium;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "destructive" | "default" | "secondary" | "outline"; label: string }> = {
      open: { variant: "destructive", label: "باز" },
      in_progress: { variant: "outline", label: "در حال پیگیری" },
      closed: { variant: "secondary", label: "بسته شده" },
    };
    const config = variants[status] || variants.open;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">در حال بارگذاری...</div>;
  }

  return (
    <div className="container mx-auto p-6" dir="rtl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">مدیریت هشدارها</h1>
        <div className="flex gap-2">
          <Button onClick={handleDownloadCSV} variant="outline">
            <Download className="ml-2 h-4 w-4" />
            دانلود CSV
          </Button>
          <Dialog open={open} onOpenChange={(newOpen) => {
            setOpen(newOpen);
            if (!newOpen) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="ml-2 h-4 w-4" />
                هشدار جدید
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
              <DialogHeader>
                <DialogTitle>{editingAlert ? "ویرایش هشدار" : "ایجاد هشدار جدید"}</DialogTitle>
                <DialogDescription>
                  اطلاعات هشدار را وارد کنید
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="title">عنوان هشدار *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="description">توضیحات</Label>
                    <Textarea
                      id="description"
                      value={formData.description || ""}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="severity">شدت *</Label>
                      <Select
                        value={formData.severity}
                        onValueChange={(value) => setFormData({ ...formData, severity: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">کم</SelectItem>
                          <SelectItem value="medium">متوسط</SelectItem>
                          <SelectItem value="high">بالا</SelectItem>
                          <SelectItem value="critical">بحرانی</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="status">وضعیت *</Label>
                      <Select
                        value={formData.status}
                        onValueChange={(value) => setFormData({ ...formData, status: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="open">باز</SelectItem>
                          <SelectItem value="in_progress">در حال پیگیری</SelectItem>
                          <SelectItem value="closed">بسته شده</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="projectId">پروژه</Label>
                    <Select
                      value={formData.projectId || "none"}
                      onValueChange={(value) => setFormData({ ...formData, projectId: value === "none" ? undefined : value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب پروژه" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">بدون پروژه</SelectItem>
                        {projects.map((project) => (
                          <SelectItem key={project.id} value={project.id}>
                            {project.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="entityType">نوع موجودیت</Label>
                      <Input
                        id="entityType"
                        value={formData.entityType || ""}
                        onChange={(e) => setFormData({ ...formData, entityType: e.target.value })}
                        placeholder="مثال: مناقصه، گزارش"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="entityId">شناسه موجودیت</Label>
                      <Input
                        id="entityId"
                        value={formData.entityId || ""}
                        onChange={(e) => setFormData({ ...formData, entityId: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">
                    {editingAlert ? "ذخیره تغییرات" : "ایجاد هشدار"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative">
          <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="جستجو در هشدارها..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
          />
        </div>

        <Select value={projectFilter} onValueChange={setProjectFilter}>
          <SelectTrigger>
            <SelectValue placeholder="همه پروژه‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه پروژه‌ها</SelectItem>
            {projects.map((project) => (
              <SelectItem key={project.id} value={project.id}>
                {project.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger>
            <SelectValue placeholder="همه وضعیت‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            <SelectItem value="open">باز</SelectItem>
            <SelectItem value="in_progress">در حال پیگیری</SelectItem>
            <SelectItem value="closed">بسته شده</SelectItem>
          </SelectContent>
        </Select>

        <Select value={severityFilter} onValueChange={setSeverityFilter}>
          <SelectTrigger>
            <SelectValue placeholder="همه شدت‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه شدت‌ها</SelectItem>
            <SelectItem value="low">کم</SelectItem>
            <SelectItem value="medium">متوسط</SelectItem>
            <SelectItem value="high">بالا</SelectItem>
            <SelectItem value="critical">بحرانی</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">عنوان</TableHead>
              <TableHead className="text-right">پروژه</TableHead>
              <TableHead className="text-right">نوع</TableHead>
              <TableHead className="text-right">شدت</TableHead>
              <TableHead className="text-right">وضعیت</TableHead>
              <TableHead className="text-right">تاریخ ایجاد</TableHead>
              <TableHead className="text-right">عملیات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAlerts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                  <AlertCircle className="mx-auto h-12 w-12 mb-2" />
                  هیچ هشداری یافت نشد
                </TableCell>
              </TableRow>
            ) : (
              filteredAlerts.map((alert) => {
                const project = projects.find(p => p.id === alert.projectId);
                return (
                  <TableRow key={alert.id}>
                    <TableCell className="font-medium">
                      <div className="flex flex-col">
                        <span>{alert.title}</span>
                        {alert.description && (
                          <span className="text-sm text-gray-500 mt-1">{alert.description}</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{project?.title || "-"}</TableCell>
                    <TableCell>{alert.entityType || "-"}</TableCell>
                    <TableCell>{getSeverityBadge(alert.severity)}</TableCell>
                    <TableCell>
                      <Select
                        value={alert.status}
                        onValueChange={(value) => handleStatusChange(alert.id, value)}
                      >
                        <SelectTrigger className="w-[140px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="open">باز</SelectItem>
                          <SelectItem value="in_progress">در حال پیگیری</SelectItem>
                          <SelectItem value="closed">بسته شده</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      {alert.createdAt
                        ? toPersianDigits(format(new Date(alert.createdAt), "yyyy/MM/dd"))
                        : "-"}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(alert)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(alert.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
