import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toPersianDigits } from "@/lib/persian-utils";
import { CheckCircle2, Circle, Plus, Send, Calendar as CalendarIcon, FolderKanban, TrendingUp, Activity } from "lucide-react";
import type { Task, DailyNote, FollowUpTask, Project } from "@shared/schema";
import { format } from "date-fns-jalali";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function PersonalDashboard() {
  const currentUser = JSON.parse(localStorage.getItem("user") || "{}");
  const userId = currentUser.id;

  // Greeting based on time
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "صبح بخیر";
    if (hour < 18) return "ظهر بخیر";
    return "عصر بخیر";
  };

  // Fetch tasks
  const { data: tasks = [], refetch: refetchTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks", userId],
    queryFn: async () => {
      const response = await fetch(`/api/tasks?userId=${userId}`);
      if (!response.ok) throw new Error("خطا در دریافت کارها");
      return response.json();
    },
    enabled: !!userId,
  });

  // Fetch daily notes
  const { data: dailyNotes = [], refetch: refetchNotes } = useQuery<DailyNote[]>({
    queryKey: ["/api/daily-notes", userId],
    queryFn: async () => {
      const response = await fetch(`/api/daily-notes?userId=${userId}`);
      if (!response.ok) throw new Error("خطا در دریافت یادداشت‌ها");
      return response.json();
    },
    enabled: !!userId,
  });

  // Fetch follow-up tasks sent TO me
  const { data: followUpTasksToMe = [], refetch: refetchFollowUps } = useQuery<FollowUpTask[]>({
    queryKey: ["/api/follow-up-tasks-to-me", userId],
    queryFn: async () => {
      const response = await fetch(`/api/follow-up-tasks?toUserId=${userId}`);
      if (!response.ok) throw new Error("خطا در دریافت پیگیری‌ها");
      return response.json();
    },
    enabled: !!userId,
  });

  // Fetch all users for follow-up dropdown
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users");
      if (!response.ok) throw new Error("خطا در دریافت کاربران");
      return response.json();
    },
  });

  // Fetch projects for analysis
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const queryClient = useQueryClient();

  // Task mutations
  const addTaskMutation = useMutation({
    mutationFn: async (task: Partial<Task>) => {
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...task, userId }),
      });
      if (!response.ok) throw new Error("خطا در ایجاد کار");
      return response.json();
    },
    onSuccess: () => {
      refetchTasks();
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Task> }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در به‌روزرسانی کار");
      return response.json();
    },
    onSuccess: () => {
      refetchTasks();
    },
  });

  // Daily note mutation
  const saveNoteMutation = useMutation({
    mutationFn: async (note: Partial<DailyNote>) => {
      const response = await fetch("/api/daily-notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...note, userId }),
      });
      if (!response.ok) throw new Error("خطا در ذخیره یادداشت");
      return response.json();
    },
    onSuccess: () => {
      refetchNotes();
    },
  });

  // Follow-up task mutations
  const sendFollowUpMutation = useMutation({
    mutationFn: async (task: Partial<FollowUpTask>) => {
      const response = await fetch("/api/follow-up-tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...task, fromUserId: userId }),
      });
      if (!response.ok) throw new Error("خطا در ارسال پیگیری");
      return response.json();
    },
    onSuccess: () => {
      refetchFollowUps();
    },
  });

  const confirmFollowUpMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/follow-up-tasks/${id}/confirm`, {
        method: "PATCH",
      });
      if (!response.ok) throw new Error("خطا در تأیید پیگیری");
      return response.json();
    },
    onSuccess: () => {
      refetchFollowUps();
      refetchTasks();
    },
  });

  // State for forms
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskCategory, setNewTaskCategory] = useState<"today" | "overdue" | "followup">("today");
  const [selectedDate, setSelectedDate] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [followUpTo, setFollowUpTo] = useState("");
  const [followUpTitle, setFollowUpTitle] = useState("");
  const [followUpDesc, setFollowUpDesc] = useState("");

  // Filter tasks
  const todayTasks = useMemo(() => tasks.filter(t => t.category === "today" && !t.isCompleted), [tasks]);
  const overdueTasks = useMemo(() => tasks.filter(t => t.category === "overdue" && !t.isCompleted), [tasks]);
  const followupTasks = useMemo(() => tasks.filter(t => t.category === "followup" && !t.isCompleted), [tasks]);
  const completedTasks = useMemo(() => tasks.filter(t => t.isCompleted), [tasks]);

  // Handle task completion
  const toggleTask = (task: Task) => {
    updateTaskMutation.mutate({
      id: task.id,
      data: {
        isCompleted: !task.isCompleted,
        completedAt: !task.isCompleted ? new Date() : null,
      },
    });
  };

  // Handle add task
  const handleAddTask = () => {
    if (!newTaskTitle.trim()) return;
    addTaskMutation.mutate({
      title: newTaskTitle,
      category: newTaskCategory,
      status: "pending",
    });
    setNewTaskTitle("");
  };

  // Calendar note handling
  const handleSaveNote = () => {
    if (!selectedDate || !noteContent.trim()) return;
    saveNoteMutation.mutate({
      noteDate: selectedDate,
      content: noteContent,
    });
    setNoteContent("");
    setSelectedDate("");
  };

  // Send follow-up task
  const handleSendFollowUp = () => {
    if (!followUpTo || !followUpTitle.trim()) return;
    sendFollowUpMutation.mutate({
      toUserId: followUpTo,
      title: followUpTitle,
      description: followUpDesc,
    });
    setFollowUpTo("");
    setFollowUpTitle("");
    setFollowUpDesc("");
  };

  const displayName = currentUser.firstName && currentUser.lastName
    ? `${currentUser.firstName} ${currentUser.lastName}`
    : currentUser.username || "کاربر";

  // Project analysis data
  const projectAnalysis = useMemo(() => {
    const totalProjects = projects.length;
    const activeProjects = projects.filter(p => p.status === 'active').length;
    const completedProjects = projects.filter(p => p.status === 'completed').length;
    const avgProgress = projects.length > 0 
      ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
      : 0;
    
    const totalContractValue = projects.reduce((sum, p) => {
      const amount = p.amount ? p.amount.replace(/,/g, '').replace(/،/g, '').replace(/[^0-9]/g, '') : '0';
      return sum + parseFloat(amount || '0');
    }, 0);

    const chartData = projects
      .filter(p => p.status === 'active')
      .map(p => ({
        name: p.title?.substring(0, 25) + (p.title && p.title.length > 25 ? '...' : ''),
        progress: p.progress || 0
      }));

    return { totalProjects, activeProjects, completedProjects, avgProgress, totalContractValue, chartData };
  }, [projects]);

  return (
    <div className="space-y-6">
      {/* Header with User Profile and Greeting */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">{displayName}</h1>
              <p className="text-muted-foreground">{getGreeting()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Project Analysis Section */}
      {projects.length > 0 && (
        <>
          {/* Stats Cards Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Card 1 - Total Projects (Cyan) */}
            <Card className="bg-gradient-to-br from-cyan-50 to-cyan-100 dark:from-cyan-950/30 dark:to-cyan-900/20 border-cyan-200 dark:border-cyan-800">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-cyan-700 dark:text-cyan-400 mb-1">تعداد پروژه‌ها</p>
                    <h3 className="text-3xl font-bold text-cyan-900 dark:text-cyan-100">{toPersianDigits(projectAnalysis.totalProjects.toString())}</h3>
                    <p className="text-xs text-cyan-600 dark:text-cyan-500 mt-1">پروژه ثبت شده</p>
                  </div>
                  <div className="p-2 rounded-lg bg-cyan-200 dark:bg-cyan-900/40">
                    <FolderKanban className="w-5 h-5 text-cyan-700 dark:text-cyan-400" />
                  </div>
                </div>
                <div className="mt-3 h-8">
                  <div className="h-full flex items-end gap-1">
                    <div className="w-1 bg-cyan-400 h-[60%] rounded-t"></div>
                    <div className="w-1 bg-cyan-500 h-[80%] rounded-t"></div>
                    <div className="w-1 bg-cyan-400 h-[70%] rounded-t"></div>
                    <div className="w-1 bg-cyan-600 h-[90%] rounded-t"></div>
                    <div className="w-1 bg-cyan-500 h-[75%] rounded-t"></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Card 2 - Average Progress (Purple) with Circle */}
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/30 dark:to-purple-900/20 border-purple-200 dark:border-purple-800">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center">
                  <p className="text-xs text-purple-700 dark:text-purple-400 mb-2">میانگین پیشرفت</p>
                  <div className="relative w-20 h-20">
                    <svg className="w-full h-full transform -rotate-90">
                      <circle
                        cx="40"
                        cy="40"
                        r="36"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        className="text-purple-200 dark:text-purple-900/40"
                      />
                      <circle
                        cx="40"
                        cy="40"
                        r="36"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 36}`}
                        strokeDashoffset={`${2 * Math.PI * 36 * (1 - projectAnalysis.avgProgress / 100)}`}
                        className="text-purple-600 dark:text-purple-400"
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xl font-bold text-purple-900 dark:text-purple-100">{toPersianDigits(`${projectAnalysis.avgProgress}٪`)}</span>
                    </div>
                  </div>
                  <p className="text-xs text-purple-600 dark:text-purple-500 mt-2">کل پروژه‌ها</p>
                </div>
              </CardContent>
            </Card>

            {/* Card 3 - Active Projects (Green) */}
            <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/20 border-green-200 dark:border-green-800">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-green-700 dark:text-green-400 mb-1">پروژه‌های فعال</p>
                    <h3 className="text-3xl font-bold text-green-900 dark:text-green-100">{toPersianDigits(`${Math.round((projectAnalysis.activeProjects / projectAnalysis.totalProjects) * 100)}٪`)}</h3>
                    <p className="text-xs text-green-600 dark:text-green-500 mt-1">{toPersianDigits(projectAnalysis.activeProjects.toString())} از {toPersianDigits(projectAnalysis.totalProjects.toString())} پروژه</p>
                  </div>
                  <div className="p-2 rounded-lg bg-green-200 dark:bg-green-900/40">
                    <Activity className="w-5 h-5 text-green-700 dark:text-green-400" />
                  </div>
                </div>
                <div className="mt-3 h-8">
                  <div className="h-full flex items-end gap-1">
                    <div className="w-1 bg-green-400 h-[50%] rounded-t"></div>
                    <div className="w-1 bg-green-500 h-[70%] rounded-t"></div>
                    <div className="w-1 bg-green-600 h-[85%] rounded-t"></div>
                    <div className="w-1 bg-green-500 h-[65%] rounded-t"></div>
                    <div className="w-1 bg-green-400 h-[55%] rounded-t"></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Card 4 - Completed Projects (Red/Orange) */}
            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950/30 dark:to-orange-900/20 border-orange-200 dark:border-orange-800">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-orange-700 dark:text-orange-400 mb-1">پروژه تکمیل شده</p>
                    <h3 className="text-3xl font-bold text-orange-900 dark:text-orange-100">{toPersianDigits(`${projectAnalysis.totalProjects > 0 ? Math.round((projectAnalysis.completedProjects / projectAnalysis.totalProjects) * 100) : 0}٪`)}</h3>
                    <p className="text-xs text-orange-600 dark:text-orange-500 mt-1">{toPersianDigits(projectAnalysis.completedProjects.toString())} پروژه انجام شده</p>
                  </div>
                  <div className="p-2 rounded-lg bg-orange-200 dark:bg-orange-900/40">
                    <CheckCircle2 className="w-5 h-5 text-orange-700 dark:text-orange-400" />
                  </div>
                </div>
                <div className="mt-3 h-8">
                  <div className="h-full flex items-end gap-1">
                    <div className="w-1 bg-orange-400 h-[70%] rounded-t"></div>
                    <div className="w-1 bg-orange-500 h-[50%] rounded-t"></div>
                    <div className="w-1 bg-orange-600 h-[60%] rounded-t"></div>
                    <div className="w-1 bg-orange-500 h-[80%] rounded-t"></div>
                    <div className="w-1 bg-orange-400 h-[65%] rounded-t"></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Card 5 - Tasks (Blue) */}
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/20 border-blue-200 dark:border-blue-800">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-blue-700 dark:text-blue-400 mb-1">کارهای امروز</p>
                    <h3 className="text-3xl font-bold text-blue-900 dark:text-blue-100">{toPersianDigits(todayTasks.length.toString())}</h3>
                    <p className="text-xs text-blue-600 dark:text-blue-500 mt-1">کار باقی‌مانده</p>
                  </div>
                  <div className="p-2 rounded-lg bg-blue-200 dark:bg-blue-900/40">
                    <CheckCircle2 className="w-5 h-5 text-blue-700 dark:text-blue-400" />
                  </div>
                </div>
                <div className="mt-3 h-8">
                  <div className="h-full flex items-end gap-1">
                    <div className="w-1 bg-blue-400 h-[80%] rounded-t"></div>
                    <div className="w-1 bg-blue-500 h-[60%] rounded-t"></div>
                    <div className="w-1 bg-blue-600 h-[90%] rounded-t"></div>
                    <div className="w-1 bg-blue-500 h-[70%] rounded-t"></div>
                    <div className="w-1 bg-blue-400 h-[55%] rounded-t"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Left Column - Progress Chart */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>پیشرفت پروژه‌ها</CardTitle>
              </CardHeader>
              <CardContent>
                {projectAnalysis.chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={projectAnalysis.chartData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis dataKey="name" type="category" width={150} />
                      <Tooltip />
                      <Bar dataKey="progress" name="پیشرفت (%)" fill="#10b981" radius={[0, 8, 8, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-center text-muted-foreground py-8">پروژه فعالی وجود ندارد</p>
                )}
              </CardContent>
            </Card>

            {/* Right Column - Tasks */}
            <Card>
              <CardHeader>
                <CardTitle>کارهای امروز</CardTitle>
              </CardHeader>
              <Separator />
              <CardContent className="pt-4">
                <div className="space-y-3 max-h-[280px] overflow-y-auto">
                  {todayTasks.slice(0, 5).map((task) => (
                    <div key={task.id} className="flex items-center gap-2 p-2 rounded hover:bg-muted/50">
                      <Checkbox
                        checked={!!task.isCompleted}
                        onCheckedChange={() => toggleTask(task)}
                      />
                      <span className={task.isCompleted ? "line-through text-muted-foreground text-sm" : "text-sm"}>
                        {task.title}
                      </span>
                    </div>
                  ))}
                  {todayTasks.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">کاری برای امروز ثبت نشده</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {/* Tasks Sections */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Today's Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>کارهای امروز من</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4 space-y-3">
            {todayTasks.map((task) => (
              <div key={task.id} className="flex items-center gap-2">
                <Checkbox
                  checked={!!task.isCompleted}
                  onCheckedChange={() => toggleTask(task)}
                />
                <span className={task.isCompleted ? "line-through text-muted-foreground" : ""}>
                  {task.title}
                </span>
              </div>
            ))}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="w-full mt-2" onClick={() => setNewTaskCategory("today")}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن کار جدید
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>کار جدید</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="عنوان کار"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                  />
                  <Button onClick={handleAddTask} className="w-full">
                    افزودن
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Overdue Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>کارهای با تأخیر</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4 space-y-3">
            {overdueTasks.map((task) => (
              <div key={task.id} className="flex items-center gap-2">
                <Checkbox
                  checked={!!task.isCompleted}
                  onCheckedChange={() => toggleTask(task)}
                />
                <span className={task.isCompleted ? "line-through text-muted-foreground" : "text-red-600"}>
                  {task.title}
                </span>
              </div>
            ))}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="w-full mt-2" onClick={() => setNewTaskCategory("overdue")}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن کار با تأخیر
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>کار با تأخیر</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="عنوان کار"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                  />
                  <Button onClick={handleAddTask} className="w-full">
                    افزودن
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Follow-up Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>کارهای قابل پیگیری</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4 space-y-3">
            {followupTasks.map((task) => (
              <div key={task.id} className="flex items-center gap-2">
                <Checkbox
                  checked={!!task.isCompleted}
                  onCheckedChange={() => toggleTask(task)}
                />
                <span className={task.isCompleted ? "line-through text-muted-foreground" : ""}>
                  {task.title}
                </span>
              </div>
            ))}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="w-full mt-2" onClick={() => setNewTaskCategory("followup")}>
                  <Plus className="w-4 h-4 ml-2" />
                  افزودن کار قابل پیگیری
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>کار قابل پیگیری</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="عنوان کار"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                  />
                  <Button onClick={handleAddTask} className="w-full">
                    افزودن
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      </div>

      {/* Completed Tasks */}
      {completedTasks.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>انجام‌شده‌ها</CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="pt-4">
            <div className="space-y-2">
              {completedTasks.map((task) => (
                <div key={task.id} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span className="line-through text-muted-foreground">{task.title}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* My Duties */}
      <Card>
        <CardHeader>
          <CardTitle>وظایف من</CardTitle>
        </CardHeader>
        <Separator />
        <CardContent className="pt-4">
          <div className="space-y-4">
            {tasks.slice(0, 5).map((task) => (
              <div key={task.id} className="p-3 border rounded-lg">
                <div className="flex items-start gap-2">
                  <Checkbox
                    checked={!!task.isCompleted}
                    onCheckedChange={() => toggleTask(task)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold">{task.title}</h4>
                    {task.description && (
                      <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Persian Calendar with Notes */}
          <div className="mt-6">
            <h3 className="font-semibold mb-4">تقویم و یادداشت روزانه</h3>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full">
                  <CalendarIcon className="w-4 h-4 ml-2" />
                  انتخاب تاریخ و ثبت یادداشت
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>یادداشت روزانه</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                  <Textarea
                    placeholder="یادداشت خود را وارد کنید..."
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    rows={4}
                  />
                  <Button onClick={handleSaveNote} className="w-full">
                    ذخیره یادداشت
                  </Button>
                  
                  {/* Show existing notes */}
                  {dailyNotes.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">یادداشت‌های ذخیره شده</h4>
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {dailyNotes.map((note) => (
                          <div key={note.id} className="p-2 border rounded">
                            <div className="text-sm text-muted-foreground">
                              {toPersianDigits(note.noteDate)}
                            </div>
                            <div>{note.content}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Follow-up from Others */}
      <Card>
        <CardHeader>
          <CardTitle>پیگیری از دیگران</CardTitle>
        </CardHeader>
        <Separator />
        <CardContent className="pt-4">
          <div className="space-y-4">
            {/* Tasks sent TO me */}
            {followUpTasksToMe.length > 0 && (
              <div>
                <h4 className="font-semibold mb-3">وظایف ارسال شده به من</h4>
                <div className="space-y-2">
                  {followUpTasksToMe.map((task: any) => (
                    <div key={task.id} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h5 className="font-semibold">{task.title}</h5>
                          {task.description && (
                            <p className="text-sm text-muted-foreground">{task.description}</p>
                          )}
                        </div>
                        {!task.isConfirmed && (
                          <Button size="sm" onClick={() => confirmFollowUpMutation.mutate(task.id)}>
                            تأیید
                          </Button>
                        )}
                        {task.isConfirmed && (
                          <CheckCircle2 className="w-5 h-5 text-green-600" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Send task to someone */}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full">
                  <Send className="w-4 h-4 ml-2" />
                  ارسال وظیفه به شخص دیگر
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>ارسال وظیفه</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Select value={followUpTo} onValueChange={setFollowUpTo}>
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب کاربر" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.filter((u: any) => u.id !== userId).map((user: any) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.firstName && user.lastName
                            ? `${user.firstName} ${user.lastName}`
                            : user.username}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    placeholder="عنوان وظیفه"
                    value={followUpTitle}
                    onChange={(e) => setFollowUpTitle(e.target.value)}
                  />
                  <Textarea
                    placeholder="توضیحات (اختیاری)"
                    value={followUpDesc}
                    onChange={(e) => setFollowUpDesc(e.target.value)}
                    rows={3}
                  />
                  <Button onClick={handleSendFollowUp} className="w-full">
                    <Send className="w-4 h-4 ml-2" />
                    ارسال
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
