import Dashboard from '../Dashboard';

export default function DashboardExample() {
  return <Dashboard />;
}
