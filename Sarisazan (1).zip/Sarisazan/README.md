# سریع‌سازان البرز - سامانه مدیریت پروژه‌های ساختمانی


📋 فهرست مطالب
درباره پروژه
ویژگی‌های کلیدی
معماری و تکنولوژی
ساختار پروژه
نصب و راه‌اندازی
بخش‌های اصلی سیستم
API Documentation
دیتابیس
احراز هویت و مجوزها
راهنمای توسعه
🎯 درباره پروژه
سریع‌سازان البرز یک سیستم جامع مدیریت پروژه‌های ساختمانی است که به طور ویژه برای کاربران فارسی‌زبان طراحی شده است. این سیستم تمامی نیازهای مدیریت پروژه‌های عمرانی از جمله پیگیری پیشرفت، مدیریت مصالح، مناقصات، گزارش‌دهی و ارتباطات داخلی را پوشش می‌دهد.

ویژگی‌های منحصر به فرد
رابط کاربری راست‌به‌چپ (RTL): طراحی کامل برای زبان فارسی
تقویم جلالی: استفاده از تقویم شمسی در تمام بخش‌ها
هوش مصنوعی: دستیار هوشمند برای پاسخگویی به سوالات مرتبط با قراردادهای ساختمانی
سیستم نقش‌محور: کنترل دسترسی دقیق با ۶ نقش پیش‌فرض و ۳۴ مجوز
✨ ویژگی‌های کلیدی
📊 مدیریت پروژه
ثبت و پیگیری پروژه‌های ساختمانی
نمایش درصد پیشرفت و وضعیت پروژه‌ها
تخصیص کاربران به پروژه‌ها
داشبورد تحلیلی با نمودارهای تعاملی
جستجوی پیشرفته و فیلتر چندگانه
🛢️ مدیریت مصالح (قیر)
ثبت و پیگیری مصرف قیر
مدیریت فاکتورها و بارنامه‌ها
پیگیری تامین‌کنندگان و حمل‌کنندگان
محاسبه موجودی و مصرف
خروجی Excel
📝 صورت‌وضعیت‌ها و تعدیل‌ها
ثبت صورت‌وضعیت‌های مالی
محاسبات تعدیل با شاخص
مابه‌التفاوت قیر
پیگیری وضعیت تایید و پرداخت
ضمیمه فایل
🎯 مناقصات
ثبت و پیگیری مناقصات
هشدار خودکار برای ضرب‌الاجل‌ها
ثبت شرکت‌های شرکت‌کننده
گردش کار تایید
🔔 سیستم هشدارها
هشدارهای چندسطحی (کم، متوسط، بالا، بحرانی)
تخصیص به کاربران
نظرات و بحث
پیگیری وضعیت (باز، تایید شده، حل شده، بسته)
هشدارهای خودکار برای ضرب‌الاجل‌های مناقصات و پروژه‌ها
💬 پیام‌رسانی داخلی
گفتگوهای مستقیم، گروهی و پروژه‌ای
ضمیمه فایل
پیگیری خوانده/نخوانده
جستجو در پیام‌ها
🧪 شیت‌های آزمایشگاهی
انواع آزمایش‌ها (کنترل کیفیت، مصالح، خاک)
ضمیمه نتایج آزمایش
گردش کار تایید
فیلتر پیشرفته
خروجی Excel
✅ مدیریت وظایف
تخصیص وظایف به کاربران
سطح اولویت (کم، متوسط، بالا، فوری)
یادآور زمان‌دار
پیگیری تکمیل
ضمیمه فایل
📅 تقویم و یادداشت‌ها
تقویم جلالی
یادداشت‌های روزانه
نمایش یادآورها در تقویم
نشانگر روزهای دارای محتوا
📈 گزارش‌دهی
گزارش‌های روزانه
گزارش‌های اجرایی با جزئیات:
شرایط آب و هوایی
دما
ماشین‌آلات مورد استفاده
مصرف مصالح
نیروی کار
توضیحات کار
ضمیمه تصاویر
گزارش‌های هفتگی
🤖 دستیار هوشمند
پاسخگویی به سوالات مرتبط با شرایط عمومی پیمان
پشتیبانی از زبان فارسی با مدل Grok
جستجوی چندمنبعی (دیتابیس + اسناد + AI)
کش کردن پاسخ‌ها برای کاهش هزینه
👥 مدیریت کاربران و نقش‌ها
۶ نقش پیش‌فرض:
مدیر سیستم
مدیریت
مدیر پروژه
دفتر فنی
سرپرست
بیننده
۳۴ مجوز دقیق
تخصیص نقش‌ها به کاربران
غیرفعال‌سازی کاربران
تغییر رمز عبور اجباری
🏛️ معماری و تکنولوژی
Frontend
React 18 + TypeScript + Vite
├── UI Framework: Radix UI + shadcn/ui
├── Styling: Tailwind CSS
├── State Management: TanStack Query (React Query)
├── Routing: Wouter
├── Forms: React Hook Form + Zod
├── Charts: Recharts
├── Date: date-fns-jalali + jalaali-js
└── Icons: Lucide React
Backend
Express.js + TypeScript
├── ORM: Drizzle ORM
├── Database: PostgreSQL
├── Authentication: bcrypt + express-session
├── File Upload: Multer
├── AI: OpenAI SDK (configured for xAI Grok)
└── Validation: Zod
Database
PostgreSQL
├── 20+ Tables
├── Relations & Constraints
├── Soft Delete Support
└── Migrations via Drizzle Kit
Infrastructure
Session Storage: PostgreSQL-backed sessions
File Storage: Local filesystem (organized by entity)
Real-time: WebSocket support
Scheduled Tasks: Auto-alert scheduler (hourly)
Cleanup Service: Automatic temp file cleanup (daily)
📁 ساختار پروژه
.
├── client/                          # Frontend React Application
│   ├── src/
│   │   ├── components/             # React Components
│   │   │   ├── ui/                 # shadcn/ui Components
│   │   │   ├── examples/           # Example Components
│   │   │   ├── AlertsPage.tsx      # Alerts Management
│   │   │   ├── ProjectsPage.tsx    # Projects List
│   │   │   ├── TendersPage.tsx     # Tenders Management
│   │   │   ├── MessagesPage.tsx    # Internal Messaging
│   │   │   ├── SheetsPage.tsx      # Lab Sheets
│   │   │   ├── TasksPage.tsx       # Task Management
│   │   │   ├── CalendarPage.tsx    # Calendar & Notes
│   │   │   ├── UsersPage.tsx       # User Management
│   │   │   ├── RolesPage.tsx       # Roles & Permissions
│   │   │   ├── AIAssistantPage.tsx # AI Assistant
│   │   │   ├── PersonalDashboard.tsx # Personal Dashboard
│   │   │   ├── ProfessionalDashboard.tsx # Analytics Dashboard
│   │   │   └── ...
│   │   ├── pages/                  # Page Components
│   │   │   ├── ProjectDetailsPage.tsx
│   │   │   ├── ExecutionReportsPage.tsx
│   │   │   └── not-found.tsx
│   │   ├── lib/                    # Utilities & Helpers
│   │   │   ├── utils.ts           # General Utilities
│   │   │   ├── persian-utils.ts   # Persian/Farsi Helpers
│   │   │   ├── queryClient.ts     # React Query Config
│   │   │   └── project-context.tsx # Global State
│   │   ├── hooks/                  # Custom React Hooks
│   │   │   ├── use-mobile.tsx
│   │   │   └── use-toast.ts
│   │   ├── App.tsx                 # Main App Component
│   │   ├── main.tsx                # Entry Point
│   │   └── index.css               # Global Styles
│   └── index.html                  # HTML Template
│
├── server/                          # Backend Express Application
│   ├── index.ts                    # Main Server File
│   ├── routes.ts                   # API Routes (2000+ lines)
│   ├── db.ts                       # Database Connection
│   ├── vite.ts                     # Vite Dev Server Setup
│   ├── storage.ts                  # Storage Abstraction
│   ├── agent-service.ts            # AI Assistant Service
│   ├── multi-source-agent.ts       # Multi-source Query Router
│   ├── auto-alerts.ts              # Auto Alert Scheduler
│   ├── cleanup-service.ts          # File Cleanup Service
│   ├── init-permissions.ts         # Permissions Initializer
│   ├── seed-projects.ts            # Sample Data Seeder
│   └── import-projects.ts          # Project Import Script
│
├── shared/                          # Shared Code (Frontend + Backend)
│   └── schema.ts                   # Drizzle Database Schema
│
├── uploads/                         # File Upload Storage
│   ├── sheets/                     # Lab Sheets Files
│   ├── tasks/                      # Task Files
│   ├── messages/                   # Message Attachments
│   ├── letters/                    # Letters
│   ├── project-files/              # Project Documents
│   └── agent-documents/            # AI Knowledge Base
│
├── attached_assets/                 # Static Assets
│   └── project-data.txt            # Sample Project Data
│
├── package.json                    # Dependencies
├── tsconfig.json                   # TypeScript Config
├── vite.config.ts                  # Vite Config
├── tailwind.config.ts              # Tailwind Config
├── drizzle.config.ts               # Drizzle Config
├── components.json                 # shadcn/ui Config
└── README.md                       # This File
🚀 نصب و راه‌اندازی
پیش‌نیازها
Node.js 20+
PostgreSQL 14+
npm یا yarn
نصب
کلون کردن پروژه
git clone <repository-url>
cd sarisazan
نصب وابستگی‌ها
npm install
تنظیم متغیرهای محیطی یک فایل .env در ریشه پروژه ایجاد کنید:
DATABASE_URL=postgresql://user:password@localhost:5432/sarisazan
XAI_API_KEY=your_xai_api_key_here  # اختیاری - برای AI Assistant
ایجاد دیتابیس
# اگر دیتابیس PostgreSQL ندارید، ایجاد کنید
createdb sarisazan
اعمال Schema
npm run db:push
اجرای برنامه در حالت توسعه
npm run dev
برنامه روی http://localhost:5000 در دسترس خواهد بود.

اطلاعات ورود پیش‌فرض
نام کاربری: admin
رمز عبور: admin123
⚠️ هشدار: رمز عبور باید در اولین ورود تغییر کند.

ساخت برای Production
# ساخت فایل‌های نهایی
npm run build
# اجرای برنامه
npm start
🔧 بخش‌های اصلی سیستم
1️⃣ مدیریت پروژه (Projects)
فایل‌های مرتبط:

client/src/components/ProjectsPage.tsx - لیست و فیلتر پروژه‌ها
client/src/pages/ProjectDetailsPage.tsx - جزئیات و تب‌های پروژه
client/src/components/ProjectCard.tsx - کارت نمایش پروژه
API Endpoints:

GET    /api/projects              // لیست پروژه‌ها با فیلتر
GET    /api/projects/:id          // جزئیات یک پروژه
POST   /api/projects              // ایجاد پروژه جدید
PUT    /api/projects/:id          // ویرایش پروژه
DELETE /api/projects/:id          // حذف پروژه
GET    /api/projects/:id/users    // کاربران پروژه
POST   /api/projects/:id/users    // اضافه کردن کاربر به پروژه
جداول دیتابیس:

projects - اطلاعات پروژه‌ها
user_projects - ارتباط کاربران و پروژه‌ها
2️⃣ مدیریت قیر (Bitumen)
فایل‌های مرتبط:

client/src/components/BitumenPage.tsx
API Endpoints:

GET    /api/bitumen               // لیست رکوردهای قیر
GET    /api/bitumen/:id           // جزئیات یک رکورد
POST   /api/bitumen               // ثبت رکورد جدید
PUT    /api/bitumen/:id           // ویرایش رکورد
DELETE /api/bitumen/:id           // حذف رکورد
GET    /api/bitumen/export/csv    // خروجی Excel
جداول دیتابیس:

bitumen_records - رکوردهای قیر
3️⃣ صورت‌وضعیت‌ها (Statements)
فایل‌های مرتبط:

client/src/components/StatementsPage.tsx
API Endpoints:

GET    /api/statements            // لیست صورت‌وضعیت‌ها
POST   /api/statements            // ایجاد صورت‌وضعیت
PUT    /api/statements/:id        // ویرایش
DELETE /api/statements/:id        // حذف (soft delete)
GET    /api/adjustments           // تعدیل‌ها
GET    /api/bitumen-diffs         // مابه‌التفاوت قیر
جداول دیتابیس:

statements - صورت‌وضعیت‌ها
adjustments - تعدیل‌ها
bitumen_differences - مابه‌التفاوت‌ها
4️⃣ مناقصات (Tenders)
فایل‌های مرتبط:

client/src/components/TendersPage.tsx
client/src/components/TenderCard.tsx
API Endpoints:

GET    /api/tenders               // لیست مناقصات
POST   /api/tenders               // ثبت مناقصه
PUT    /api/tenders/:id           // ویرایش
DELETE /api/tenders/:id           // حذف
جداول دیتابیس:

tenders - مناقصات
ویژگی‌های خاص:

هشدار خودکار ۳ روز قبل از ضرب‌الاجل
مرتب‌سازی SLA-based (اولویت با مناقصات نزدیک به ضرب‌الاجل)
5️⃣ هشدارها (Alerts)
فایل‌های مرتبط:

client/src/components/AlertsPage.tsx
client/src/components/AlertCard.tsx
server/auto-alerts.ts - سیستم هشدار خودکار
API Endpoints:

GET    /api/alerts                // لیست هشدارها
POST   /api/alerts                // ایجاد هشدار
PUT    /api/alerts/:id            // ویرایش
DELETE /api/alerts/:id            // حذف
POST   /api/alerts/:id/comments   // افزودن نظر
GET    /api/alerts/export/csv     // خروجی Excel
جداول دیتابیس:

alerts - هشدارها
alert_recipients - گیرندگان هشدار
alert_comments - نظرات
هشدارهای خودکار:

بررسی هر ساعت
مناقصات با ضرب‌الاجل نزدیک
پروژه‌های با پیشرفت کمتر از ۵۰٪
6️⃣ پیام‌رسانی (Messages)
فایل‌های مرتبط:

client/src/components/MessagesPage.tsx
API Endpoints:

GET    /api/conversations         // لیست گفتگوها
POST   /api/conversations         // ایجاد گفتگو
GET    /api/conversations/:id/messages  // پیام‌های یک گفتگو
POST   /api/messages              // ارسال پیام
POST   /api/messages/:id/read     // علامت‌گذاری خوانده شده
POST   /api/messages/upload       // آپلود فایل
جداول دیتابیس:

conversations - گفتگوها
conversation_members - اعضای گفتگو
messages - پیام‌ها
message_files - فایل‌های پیام
message_reads - وضعیت خوانده شده
7️⃣ شیت‌های آزمایشگاهی (Lab Sheets)
فایل‌های مرتبط:

client/src/components/SheetsPage.tsx
API Endpoints:

GET    /api/sheets                // لیست شیت‌ها
POST   /api/sheets                // ایجاد شیت
PUT    /api/sheets/:id            // ویرایش
DELETE /api/sheets/:id            // حذف (soft delete)
POST   /api/sheets/:id/files      // آپلود فایل
GET    /api/sheets/export/csv     // خروجی Excel
جداول دیتابیس:

sheets - شیت‌های آزمایش
sheet_files - فایل‌های ضمیمه
انواع شیت:

کنترل کیفیت بتن
کنترل کیفیت آسفالت
آزمایش مصالح
آزمایش خاک
آزمایش قیر
8️⃣ وظایف (Tasks)
فایل‌های مرتبط:

client/src/components/TasksPage.tsx
API Endpoints:

GET    /api/tasks                 // لیست وظایف
POST   /api/tasks                 // ایجاد وظیفه
PUT    /api/tasks/:id             // ویرایش
DELETE /api/tasks/:id             // حذف
POST   /api/tasks/:id/files       // آپلود فایل
POST   /api/tasks/:id/confirm     // تایید وظیفه
جداول دیتابیس:

tasks - وظایف
task_files - فایل‌های ضمیمه
9️⃣ تقویم و یادداشت‌ها (Calendar)
فایل‌های مرتبط:

client/src/components/CalendarPage.tsx
client/src/components/NotesPage.tsx
API Endpoints:

GET    /api/calendar-notes        // یادداشت‌های تقویم
POST   /api/calendar-notes        // ثبت یادداشت
PUT    /api/calendar-notes/:id    // ویرایش
DELETE /api/calendar-notes/:id    // حذف
GET    /api/sticky-notes          // یادداشت‌های چسبان
جداول دیتابیس:

calendar_notes - یادداشت‌های تقویم
sticky_notes - یادداشت‌های چسبان
note_items - آیتم‌های یادداشت
🔟 گزارش‌دهی (Reports)
فایل‌های مرتبط:

client/src/components/WeeklyReportsPage.tsx
client/src/pages/ExecutionReportsPage.tsx
client/src/components/DailyReportForm.tsx
client/src/components/ExecutionReportForm.tsx
API Endpoints:

GET    /api/reports               // گزارش‌های روزانه
POST   /api/reports               // ثبت گزارش روزانه
GET    /api/execution-reports     // گزارش‌های اجرایی
POST   /api/execution-reports     // ثبت گزارش اجرایی
GET    /api/weekly-reports        // گزارش‌های هفتگی
POST   /api/weekly-reports        // ثبت گزارش هفتگی
جداول دیتابیس:

reports - گزارش‌های روزانه
execution_reports - گزارش‌های اجرایی
weekly_reports - گزارش‌های هفتگی
1️⃣1️⃣ دستیار هوشمند (AI Assistant)
فایل‌های مرتبط:

client/src/components/AIAssistantPage.tsx
server/agent-service.ts - سرویس اصلی AI
server/multi-source-agent.ts - مسیریاب چند منبعی
API Endpoints:

POST   /api/agent/ask             // پرسش از AI
GET    /api/agent/article/:id     // دریافت ماده قانونی
GET    /api/agent/status          // وضعیت اتصال
POST   /api/agent/upload-document // آپلود سند
ویژگی‌ها:

استفاده از مدل Grok-2-1212 از xAI
جستجوی چندمنبعی (دیتابیس + اسناد + AI)
کش ۷ روزه برای کاهش هزینه
پشتیبانی کامل از زبان فارسی
1️⃣2️⃣ مدیریت کاربران (Users)
فایل‌های مرتبط:

client/src/components/UsersPage.tsx
client/src/components/UserCard.tsx
API Endpoints:

GET    /api/users                 // لیست کاربران
GET    /api/users/:id             // جزئیات کاربر
POST   /api/users                 // ایجاد کاربر
PUT    /api/users/:id             // ویرایش کاربر
DELETE /api/users/:id             // حذف کاربر
POST   /api/users/:id/reset-password  // بازنشانی رمز
جداول دیتابیس:

users - کاربران
1️⃣3️⃣ نقش‌ها و مجوزها (Roles & Permissions)
فایل‌های مرتبط:

client/src/components/RolesPage.tsx
server/init-permissions.ts - مقداردهی اولیه
API Endpoints:

GET    /api/roles                 // لیست نقش‌ها
GET    /api/roles/:id             // جزئیات نقش
POST   /api/roles                 // ایجاد نقش
PUT    /api/roles/:id             // ویرایش نقش
DELETE /api/roles/:id             // حذف نقش
GET    /api/permissions           // لیست مجوزها
جداول دیتابیس:

roles - نقش‌ها
permissions - مجوزها
role_permissions - ارتباط نقش‌ها و مجوزها
📚 API Documentation
احراز هویت (Authentication)
POST   /api/login
Body: { username: string, password: string, rememberMe?: boolean }
Response: { id, username, firstName, lastName, roleId, ... }
POST   /api/logout
Response: { success: true }
GET    /api/user
Response: User object or 401
ساختار پاسخ‌ها
موفق:

{
  "id": "uuid",
  "field": "value",
  ...
}
خطا:

{
  "message": "توضیح خطا به فارسی"
}
کدهای وضعیت
200 - موفق
201 - ایجاد شد
400 - درخواست نامعتبر
401 - احراز هویت نشده
403 - دسترسی ممنوع
404 - یافت نشد
500 - خطای سرور
🗄️ دیتابیس
جداول اصلی
users                 - کاربران سیستم
roles                 - نقش‌های کاربری
permissions           - مجوزهای سیستم
role_permissions      - ارتباط نقش و مجوز
projects              - پروژه‌های ساختمانی
user_projects         - ارتباط کاربر و پروژه
bitumen_records       - رکوردهای قیر
statements            - صورت‌وضعیت‌ها
adjustments           - تعدیل‌ها
bitumen_differences   - مابه‌التفاوت قیر
tenders               - مناقصات
alerts                - هشدارها
alert_recipients      - گیرندگان هشدار
alert_comments        - نظرات هشدار
sheets                - شیت‌های آزمایشگاهی
sheet_files           - فایل‌های شیت
tasks                 - وظایف
task_files            - فایل‌های وظیفه
conversations         - گفتگوها
conversation_members  - اعضای گفتگو
messages              - پیام‌ها
message_files         - فایل‌های پیام
message_reads         - وضعیت خواندن
reports               - گزارش‌های روزانه
execution_reports     - گزارش‌های اجرایی
weekly_reports        - گزارش‌های هفتگی
calendar_notes        - یادداشت‌های تقویم
sticky_notes          - یادداشت‌های چسبان
note_items            - آیتم‌های یادداشت
daily_notes           - یادداشت‌های روزانه
follow_up_tasks       - وظایف پیگیری
letters               - نامه‌ها
letter_recipients     - گیرندگان نامه
user_preferences      - تنظیمات کاربر
مدیریت Schema
# مشاهده تغییرات
npm run check
# اعمال تغییرات
npm run db:push
# در صورت خطا
npm run db:push --force
🔐 احراز هویت و مجوزها
نقش‌های پیش‌فرض
مدیر سیستم (system_admin)

تمام مجوزها (۳۴ مجوز)
مدیریت کاربران و نقش‌ها
مدیریت (management)

تمام مجوزها
نظارت بر کل سیستم
مدیر پروژه (project_manager)

مدیریت پروژه‌ها
گزارش‌ها
قیر
صورت‌وضعیت‌ها
دفتر فنی (technical_office)

شیت‌ها
گزارش‌ها
مشاهده پروژه‌ها
سرپرست (supervisor)

گزارش‌های روزانه
وظایف
مشاهده پروژه‌ها
بیننده (viewer)

فقط مشاهده
دسته‌بندی مجوزها
projects.*        - پروژه‌ها
reports.*         - گزارش‌ها
bitumen.*         - قیر
sheets.*          - شیت‌ها
tenders.*         - مناقصات
alerts.*          - هشدارها
users.*           - کاربران
roles.*           - نقش‌ها
messages.*        - پیام‌ها
statements.*      - صورت‌وضعیت‌ها
💻 راهنمای توسعه
دستورات npm
# اجرا در حالت توسعه
npm run dev
# ساخت برای production
npm run build
# اجرا در production
npm start
# بررسی TypeScript
npm run check
# مدیریت دیتابیس
npm run db:push
ساختار کامپوننت‌ها
// الگوی استاندارد کامپوننت
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
export default function MyPage() {
  // Queries
  const { data, isLoading } = useQuery({
    queryKey: ['/api/endpoint'],
    queryFn: async () => {
      const res = await fetch('/api/endpoint');
      return res.json();
    }
  });
  // Mutations
  const mutation = useMutation({
    mutationFn: async (data) => {
      const res = await fetch('/api/endpoint', {
        method: 'POST',
        body: JSON.stringify(data)
      });
      return res.json();
    }
  });
  return (
    <Card>
      <CardHeader>
        <CardTitle>عنوان</CardTitle>
      </CardHeader>
      <CardContent>
        {/* محتوا */}
      </CardContent>
    </Card>
  );
}
الگوی API Route
// در server/routes.ts
app.get("/api/resource", async (req, res) => {
  try {
    const data = await db.select().from(table);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});
app.post("/api/resource", async (req, res) => {
  try {
    const [item] = await db.insert(table)
      .values(req.body)
      .returning();
    res.json(item);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});
استایل‌دهی
// استفاده از Tailwind با RTL
<div className="text-right dir-rtl">
  <h1 className="text-2xl font-bold">عنوان</h1>
</div>
// استفاده از shadcn/ui
import { Button } from "@/components/ui/button";
<Button variant="default" size="lg">
  کلیک کنید
</Button>
تبدیل به اعداد فارسی
import { toPersianDigits } from "@/lib/persian-utils";
const persianNumber = toPersianDigits("12345");
// نتیجه: "۱۲۳۴۵"
تقویم جلالی
import { format } from "date-fns-jalali";
const jalaliDate = format(new Date(), "yyyy/MM/dd");
// نتیجه: "1404/02/08"
📝 نکات مهم
امنیت
رمزهای عبور با bcrypt هش می‌شوند
Session-based authentication
تمام API ها نیاز به احراز هویت دارند (به جز login)
کنترل دسترسی سطح نقش
عملکرد
React Query برای کش کردن داده‌ها
Lazy loading برای کامپوننت‌ها
ایندکس‌گذاری دیتابیس
فشرده‌سازی فایل‌های static
مقیاس‌پذیری
معماری Monorepo
جداسازی Frontend/Backend
Database connection pooling
File cleanup scheduler
🤝 مشارکت
برای مشارکت در پروژه:

Fork کنید
یک branch جدید بسازید (git checkout -b feature/amazing-feature)
تغییرات را commit کنید (git commit -m 'Add amazing feature')
Push کنید (git push origin feature/amazing-feature)
یک Pull Request باز کنید



------------------------------------------------------------------------------------------
سامانه جامع مدیریت پروژه‌های ساختمانی با قابلیت تحلیل هوشمند با استفاده از هوش مصنوعی (AI Agent)

## ویژگی‌های اصلی

### 1. داشبورد تحلیلی هوشمند

داشبورد اصلی سیستم از ایجنت AI (Grok) برای ارائه تحلیل‌های زیر استفاده می‌کند:

#### گزارش پیشرفت پروژه‌ها
- **نمایش درصد پیشرفت ریالی و زمانی**: تحلیل پیشرفت واقعی هر پروژه نسبت به زمان‌بندی و بودجه
- **شبیه‌سازی وضعیت پروژه‌ها**: شناسایی پروژه‌هایی که طبق برنامه پیش می‌روند یا نیاز به اقدام دارند
- **پروژه‌های نیازمند توجه فوری**: فهرست پروژه‌های با پیشرفت کمتر از حد انتظار
- **پیشنهادات بهبود**: توصیه‌های عملی برای بهبود عملکرد پروژه‌ها

#### تحلیل مالی پروژه‌ها
- **مقایسه هزینه‌های واقعی با بودجه**: گزارش انحراف از بودجه برای هر پروژه
- **گزارش صورت‌وضعیت‌ها**: نمایش آخرین وضعیت مالی هر پروژه
- **تعدیل‌های قیمت**: محاسبه و گزارش تعدیل‌های قیمت بر اساس شاخص‌ها
- **مابه‌التفاوت مصالح**: محاسبه تفاوت قیمت مصالح (مانند قیر) نسبت به قیمت پیمان

#### پیش‌بینی تأخیرات
- **شناسایی پروژه‌های در معرض خطر**: تشخیص پروژه‌هایی که احتمال تأخیر در آنها بالاست
- **تحلیل علل تأخیر**: بررسی دلایل احتمالی تأخیر (کمبود منابع، مشکلات اجرایی، و...)
- **پیشنهادات تسریع**: راهکارهای عملی برای جلوگیری از تأخیر یا کاهش آن
- **اولویت‌بندی اقدامات**: مشخص کردن پروژه‌هایی که نیاز به توجه فوری دارند

#### مدیریت منابع و تخصیص
- **شناسایی نیازهای منابع**: تشخیص پروژه‌هایی که به نیروی کار، تجهیزات یا مصالح بیشتر نیاز دارند
- **بهینه‌سازی تخصیص**: پیشنهاد برای توزیع بهینه منابع بین پروژه‌ها
- **محاسبه منابع اضافی**: برآورد میزان منابع مورد نیاز برای تکمیل به موقع پروژه‌ها
- **پیشنهادات کارآمدسازی**: راهکارهایی برای استفاده بهینه از منابع موجود

#### گزارش وضعیت صورت‌وضعیت‌ها و تعدیل‌ها
- **آخرین صورت‌وضعیت‌ها**: نمایش جدیدترین صورت‌وضعیت ثبت شده برای هر پروژه
- **آخرین تعدیل‌ها**: گزارش آخرین تعدیل‌های قیمت اعمال شده
- **وضعیت تأیید**: نمایش تاریخ‌ها و وضعیت‌های جاری (در انتظار تأیید، تأیید شده، پرداخت شده)
- **آخرین مابه‌التفاوت‌ها**: گزارش جدیدترین محاسبات مابه‌التفاوت قیمت مصالح

#### هشدارهای خودکار
- **هشدار پیشرفت پایین**: اطلاع‌رسانی خودکار برای پروژه‌های با پیشرفت کمتر از ۵۰٪
- **هشدار تأخیر احتمالی**: اعلام هشدار برای پروژه‌های در معرض خطر تأخیر
- **هشدار مشکلات مالی**: شناسایی و اطلاع‌رسانی مشکلات بودجه و هزینه‌ها
- **گزارش‌دهی خودکار**: ارسال گزارش وضعیت پروژه‌ها و منابع به صورت دوره‌ای

### 2. مدیریت پروژه‌ها
- ثبت و مدیریت پروژه‌های ساختمانی
- ردیابی پیشرفت با درصد تکمیل
- مدیریت اطلاعات پیمان (شماره، تاریخ، مبلغ، کارفرما، پیمانکار)
- فیلتر و جستجوی پیشرفته پروژه‌ها

### 3. مدیریت مصالح (قیر)
- ثبت ورود و مصرف قیر برای هر پروژه
- پیگیری فاکتورها و مدارک مرتبط
- محاسبه خودکار مابه‌التفاوت قیمت
- خروجی Excel از اطلاعات

### 4. مدیریت مناقصات
- ثبت و پیگیری مناقصات
- هشدار خودکار برای مهلت‌های مناقصه
- مدیریت وضعیت و تصمیم‌گیری درباره شرکت در مناقصات

### 5. سیستم هشدارها
- هشدارهای چند سطحی (کم، متوسط، زیاد، بحرانی)
- تخصیص هشدار به کاربران
- امکان نظردهی و بحث روی هشدارها
- خروجی Excel

### 6. پیام‌رسانی داخلی
- گفتگوهای مستقیم، گروهی و مرتبط با پروژه
- ضمیمه فایل در پیام‌ها
- ردیابی خوانده/نخوانده شدن پیام‌ها

### 7. مدیریت آزمایشگاه
- ثبت برگه‌های آزمایشگاهی (کنترل کیفی، آزمایش مصالح، خاک)
- ضمیمه فایل در برگه‌ها
- گردش کار تأیید/رد

### 8. مدیریت وظایف
- تخصیص وظایف به کاربران
- سطوح اولویت (کم، متوسط، زیاد، فوری)
- یادآوری خودکار
- پیوست فایل

### 9. دستیار هوشمند AI
- پاسخ به سؤالات درباره قوانین و شرایط عمومی پیمان
- جستجو در پایگاه دانش حقوقی
- پاسخ‌های فارسی با استفاده از مدل Grok
- کش ۷ روزه برای کاهش مصرف توکن

## بهینه‌سازی مصرف توکن‌های AI

سیستم برای مصرف بهینه توکن‌های API از روش‌های زیر استفاده می‌کند:

### 1. پردازش هوشمند
- **اجتناب از تکرار**: هر داده فقط یک بار پردازش می‌شود
- **گزارش‌های خلاصه**: ارائه اطلاعات کلیدی به جای داده‌های کامل
- **پردازش انتخابی**: تحلیل فقط داده‌های مورد نیاز

### 2. کش گزارش‌ها
- ذخیره تحلیل‌های قبلی برای ۷ روز
- جلوگیری از درخواست‌های تکراری
- بروزرسانی فقط در صورت تغییر داده‌ها

### 3. پرامپت‌های بهینه
- استفاده از پرامپت‌های مختصر و هدفمند
- درخواست خروجی JSON برای پردازش سریع‌تر
- حذف اطلاعات غیرضروری از پرامپت‌ها

### 4. تحلیل دسته‌ای
- پردازش چندین پروژه در یک درخواست
- کاهش تعداد فراخوانی API
- محاسبات محلی برای داده‌های ساده

## راه‌اندازی و استقرار

### پیش‌نیازها
- Node.js 20 یا بالاتر
- PostgreSQL
- کلید API سرویس xAI (Grok)

### نصب
```bash
# نصب وابستگی‌ها
npm install

# راه‌اندازی دیتابیس
npm run db:push

# اجرای سرور در حالت توسعه
npm run dev

# وارد کردن پروژه‌های نمونه
tsx server/seed-projects.ts
```

### تنظیمات محیط
متغیرهای محیطی مورد نیاز:
- `DATABASE_URL`: آدرس اتصال به پایگاه داده PostgreSQL
- `XAI_API_KEY`: کلید API سرویس Grok برای دستیار هوشمند (اختیاری - سیستم بدون آن هم کار می‌کند)

### استقرار (Deployment)
```bash
# ساخت برای محیط تولید
npm run build

# اجرای سرور در محیط تولید
npm start
```

## ساختار پروژه

```
/client           # فرانت‌اند React
  /src
    /components   # کامپوننت‌های React
    /lib         # توابع کمکی، Context
    /pages       # صفحات اصلی
/server          # بک‌اند Express
  /routes.ts     # مسیرهای API
  /db.ts         # اتصال به دیتابیس
  /ai-assistant.ts    # سرویس دستیار هوشمند
  /multi-source-agent.ts  # مسیریابی پرس‌وجوهای AI
  /auto-alerts.ts # سیستم هشدارهای خودکار
/shared          # تایپ‌ها و اسکیمای مشترک
  /schema.ts     # تعاریف جداول Drizzle
```

## تکنولوژی‌های استفاده شده

### فرانت‌اند
- React 18 با TypeScript
- Vite (ابزار ساخت)
- Tailwind CSS (استایل‌دهی)
- TanStack Query (مدیریت state سرور)
- Radix UI + shadcn/ui (کامپوننت‌های UI)
- Recharts (نمودارها)
- Wouter (مسیریابی)

### بک‌اند
- Express.js با TypeScript
- Drizzle ORM (مدیریت دیتابیس)
- PostgreSQL (پایگاه داده)
- Grok API (هوش مصنوعی)
- Multer (آپلود فایل)
- bcrypt.js (رمزنگاری)

### ویژگی‌های محلی‌سازی
- رابط کاربری کاملاً فارسی با پشتیبانی RTL
- تقویم جلالی (شمسی) برای همه تاریخ‌ها
- فرمت ریال ایران برای مبالغ مالی
- تبدیل اعداد انگلیسی به فارسی

## امنیت

- رمزنگاری رمز عبور با bcrypt
- مدیریت نشست با PostgreSQL
- کنترل دسترسی مبتنی بر نقش (RBAC)
- مدیریت امن کلیدهای API از طریق متغیرهای محیطی

## مجوز

این پروژه تحت مجوز MIT منتشر شده است.

## توسعه‌دهندگان

سریع‌سازان البرز - سامانه مدیریت پروژه‌های ساختمانی

نسخه ۱.۰.۰ - همه حقوق محفوظ است

---

برای اطلاعات بیشتر، به فایل `replit.md` مراجعه کنید که حاوی جزئیات فنی کامل سیستم است.
